from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from waxs_cake.composite_wave_operator import (  # noqa: E402
    PreparedLayeredVectorCompositeOperator,
)
from waxs_cake.vector_debye import gauss_sine_theta_grid  # noqa: E402


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    return float(
        np.linalg.norm((candidate - reference).ravel())
        / max(np.linalg.norm(reference.ravel()), np.finfo(np.float64).tiny)
    )


def timed_samples(function, repeats: int) -> list[float]:
    function()
    samples: list[float] = []
    for _ in range(repeats):
        start = time.perf_counter()
        function()
        samples.append(time.perf_counter() - start)
    return samples


def build_channels(theta: np.ndarray, phi: np.ndarray) -> np.ndarray:
    radial = np.sin(theta)[:, None] / np.max(np.sin(theta))
    angle = phi[None, :]
    envelope = np.exp(-0.9 * radial**2)
    channels = np.zeros((6, 2, theta.size, phi.size), dtype=np.complex128)
    channels[0, 0] = envelope
    channels[1, 1] = envelope
    channels[2, 0] = envelope * np.exp(2j * angle)
    channels[3, 1] = envelope * np.exp(-3j * angle)
    channels[4, 0] = 0.64 * envelope * np.exp(4j * angle)
    channels[4, 1] = 0.31j * envelope * np.exp(4j * angle)
    aberration = np.exp(
        1j
        * (
            0.27 * radial**2 * np.cos(2.0 * angle)
            + 0.11 * radial**3 * np.sin(angle)
        )
    )
    channels[5, 0] = 0.48 * envelope * aberration
    channels[5, 1] = 0.56 * envelope * np.exp(1j * angle) * aberration
    return channels


def validate(output: Path, repeats: int) -> dict[str, object]:
    theta, theta_weights = gauss_sine_theta_grid(14, 1.0)
    phi = 0.07 + np.arange(129) * (2.0 * np.pi / 129.0)
    rho_axis = np.linspace(0.0, 0.9, 6)
    psi_axis = np.arange(24) * (2.0 * np.pi / 24.0)
    z_axis = np.linspace(-0.28, 0.32, 3)
    source_basis = build_channels(theta, phi)
    build_start = time.perf_counter()
    operator = PreparedLayeredVectorCompositeOperator.build(
        theta=theta,
        theta_weights=theta_weights,
        phi=phi,
        rho_axis=rho_axis,
        psi_axis=psi_axis,
        z_axis=z_axis,
        upper_wavenumber=6.4,
        lower_wavenumber=8.1,
        damping=0.055,
        source_height=0.47,
        lateral_displacement=(0.19, -0.13),
        source_basis=source_basis,
        channel_labels=("x0", "y0", "x+2", "y-3", "elliptic+4", "aberrated"),
        mode_padding=8,
        miller_margin=32,
    )
    setup_seconds = time.perf_counter() - build_start
    compact = operator.compact()

    coefficients = np.array(
        [
            0.73 - 0.12j,
            -0.31 + 0.27j,
            0.18 + 0.09j,
            -0.16j,
            0.11 - 0.08j,
            -0.07 + 0.13j,
        ],
        dtype=np.complex128,
    )
    materialized = compact.forward(coefficients)
    unfused = operator.reference_forward(coefficients)
    direct = operator.direct_forward(coefficients)

    rng = np.random.default_rng(2026090307)
    cotangent = rng.normal(size=operator.field_shape) + 1j * rng.normal(
        size=operator.field_shape
    )
    lhs = np.vdot(materialized, cotangent)
    rhs = np.vdot(coefficients, compact.adjoint(cotangent))
    adjoint_error = float(
        abs(lhs - rhs) / max(abs(lhs), abs(rhs), np.finfo(np.float64).tiny)
    )
    adjoint_reference_error = relative_l2(
        compact.adjoint(cotangent), operator.reference_adjoint(cotangent)
    )

    direction = np.array([0.21, -0.29])
    jvp = compact.lateral_translation_jvp(coefficients, direction)
    reference_jvp = operator.reference_lateral_translation_jvp(
        coefficients, direction
    )
    step = 1.0e-6
    finite = (
        operator.reference_translated_forward(coefficients, step * direction)
        - operator.reference_translated_forward(coefficients, -step * direction)
    ) / (2.0 * step)
    translation_gradient = compact.lateral_translation_vjp(
        coefficients, cotangent
    )
    derivative_duality_left = float(np.vdot(jvp, cotangent).real)
    derivative_duality_right = float(np.dot(direction, translation_gradient))
    derivative_duality_error = abs(
        derivative_duality_left - derivative_duality_right
    ) / max(
        abs(derivative_duality_left),
        abs(derivative_duality_right),
        np.finfo(np.float64).tiny,
    )

    weights = np.linspace(0.35, 1.65, operator.field_shape[1])[None, :]
    normal = compact.normal_matvec(coefficients, weights)
    normal_quadratic = float(np.vdot(coefficients, normal).real)
    weighted_field_norm = float(np.sum(weights * np.abs(materialized) ** 2).real)
    normal_identity_error = abs(normal_quadratic - weighted_field_norm) / max(
        weighted_field_norm, np.finfo(np.float64).tiny
    )

    materialized_samples = timed_samples(
        lambda: compact.forward(coefficients), repeats
    )
    unfused_samples = timed_samples(
        lambda: operator.reference_forward(coefficients), repeats
    )
    direct_samples = timed_samples(
        lambda: operator.direct_forward(coefficients), max(1, min(repeats, 3))
    )
    materialized_median = float(np.median(materialized_samples))
    unfused_median = float(np.median(unfused_samples))
    direct_median = float(np.median(direct_samples))

    metrics = {
        "materialized_vs_unfused_relative_l2": relative_l2(
            materialized, unfused
        ),
        "materialized_vs_direct_relative_l2": relative_l2(materialized, direct),
        "adjoint_dot_relative_error": adjoint_error,
        "adjoint_vs_unfused_relative_l2": adjoint_reference_error,
        "translation_jvp_vs_unfused_relative_l2": relative_l2(
            jvp, reference_jvp
        ),
        "translation_jvp_vs_finite_difference_relative_l2": relative_l2(
            jvp, finite
        ),
        "translation_jvp_vjp_relative_error": derivative_duality_error,
        "weighted_normal_quadratic_identity_relative_error": normal_identity_error,
    }
    tolerances = {
        "materialized_vs_unfused_relative_l2": 5.0e-13,
        "materialized_vs_direct_relative_l2": 5.0e-11,
        "adjoint_dot_relative_error": 5.0e-13,
        "adjoint_vs_unfused_relative_l2": 5.0e-13,
        "translation_jvp_vs_unfused_relative_l2": 5.0e-13,
        "translation_jvp_vs_finite_difference_relative_l2": 5.0e-8,
        "translation_jvp_vjp_relative_error": 5.0e-13,
        "weighted_normal_quadratic_identity_relative_error": 5.0e-13,
    }
    passed = bool(
        all(metrics[name] <= tolerance for name, tolerance in tolerances.items())
        and normal_quadratic >= -5.0e-13 * max(weighted_field_norm, 1.0)
        and operator.materialized_bytes < operator.reference_chain_bytes
    )
    summary = {
        "schema": "acfo-layered-vector-composite-materialization-v1",
        "passed": passed,
        "operator_expression": "A_Gamma G_layer T(d)",
        "interpretation": (
            "Constructive coefficient-space materialization on six incident "
            "channels; local implementation diagnostic, not a publication "
            "end-to-end speed claim."
        ),
        "grid": {
            "ntheta": int(theta.size),
            "nphi": int(phi.size),
            "nrho": int(rho_axis.size),
            "npsi": int(psi_axis.size),
            "nz": int(z_axis.size),
            "target_count": int(np.prod(operator.field_shape[1:])),
            "channel_count": int(operator.channel_shape[0]),
        },
        "contract": operator.contract.to_dict(),
        "restriction_contract": operator.restriction.contract.to_dict(),
        "metrics": metrics,
        "tolerances": tolerances,
        "storage": {
            "materialized_action_bytes": operator.materialized_bytes,
            "reference_chain_bytes": operator.reference_chain_bytes,
            "reference_over_materialized_ratio": (
                operator.reference_chain_bytes / operator.materialized_bytes
            ),
            "avoided_intermediate_bytes_per_hot_call": (
                operator.avoided_intermediate_bytes_per_call
            ),
            "scope": (
                "Array-storage accounting for the hot materialized action and "
                "retained audit chain; not a sampled process-peak measurement."
            ),
        },
        "timing": {
            "setup_seconds": setup_seconds,
            "materialized_hot_samples_seconds": materialized_samples,
            "unfused_hot_samples_seconds": unfused_samples,
            "direct_samples_seconds": direct_samples,
            "materialized_hot_median_seconds": materialized_median,
            "unfused_hot_median_seconds": unfused_median,
            "direct_median_seconds": direct_median,
            "unfused_over_materialized_hot_ratio": (
                unfused_median / materialized_median
            ),
            "direct_over_materialized_hot_ratio": (
                direct_median / materialized_median
            ),
            "scope": (
                "Single-machine local diagnostic without process isolation or "
                "paired resampling; ratios are not publication claims."
            ),
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "reports"
        / "acfo_layered_vector_composite_local_v1"
        / "summary.json",
    )
    parser.add_argument("--repeats", type=int, default=9)
    args = parser.parse_args()
    if args.repeats <= 0:
        raise ValueError("repeats must be positive")
    summary = validate(args.output, args.repeats)
    print(json.dumps(summary, indent=2))
    return 0 if summary["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
