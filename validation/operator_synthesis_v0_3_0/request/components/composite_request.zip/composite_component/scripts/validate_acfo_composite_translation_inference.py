from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from waxs_cake.composite_wave_operator import (  # noqa: E402
    PreparedLayeredVectorCompositeOperator,
)
from waxs_cake.vector_debye import gauss_sine_theta_grid  # noqa: E402


def source_channels(theta: np.ndarray, phi: np.ndarray) -> np.ndarray:
    radial = np.sin(theta)[:, None] / np.max(np.sin(theta))
    angle = phi[None, :]
    envelope = np.exp(-0.75 * radial**2)
    channels = np.zeros((5, 2, theta.size, phi.size), dtype=np.complex128)
    channels[0, 0] = envelope
    channels[1, 1] = envelope * np.exp(1j * angle)
    channels[2, 0] = 0.71 * envelope * np.exp(-2j * angle)
    channels[2, 1] = 0.28j * envelope * np.exp(-2j * angle)
    channels[3, 0] = 0.43 * envelope * np.exp(3j * angle)
    channels[3, 1] = 0.57 * envelope * np.exp(3j * angle)
    phase = np.exp(0.22j * radial**2 * np.cos(2.0 * angle))
    channels[4, 0] = 0.52 * envelope * phase
    channels[4, 1] = 0.34j * envelope * np.exp(-1j * angle) * phase
    return channels


def objective(field: np.ndarray, target: np.ndarray) -> float:
    residual = field - target
    return 0.5 * float(np.vdot(residual, residual).real)


def validate(output: Path, maximum_iterations: int) -> dict[str, object]:
    theta, theta_weights = gauss_sine_theta_grid(12, 0.96)
    phi = 0.04 + np.arange(97) * (2.0 * np.pi / 97.0)
    operator = PreparedLayeredVectorCompositeOperator.build(
        theta=theta,
        theta_weights=theta_weights,
        phi=phi,
        rho_axis=np.linspace(0.0, 0.82, 5),
        psi_axis=np.arange(18) * (2.0 * np.pi / 18.0),
        z_axis=np.array([-0.19, 0.0, 0.23]),
        upper_wavenumber=5.9,
        lower_wavenumber=7.6,
        damping=0.05,
        source_height=0.44,
        source_basis=source_channels(theta, phi),
        channel_labels=("x0", "y+1", "elliptic-2", "elliptic+3", "aberrated"),
        lateral_displacement=(0.12, -0.08),
        mode_padding=8,
        miller_margin=32,
    )
    coefficients = np.array(
        [0.68 - 0.13j, -0.27 + 0.19j, 0.16 + 0.07j, -0.11j, 0.09 + 0.12j]
    )
    truth = np.array([0.047, -0.036])
    target = operator.materialize_lateral_update(truth).forward(coefficients)
    estimate = np.zeros(2, dtype=np.float64)
    history: list[dict[str, object]] = []

    for iteration in range(maximum_iterations):
        action = operator.materialize_lateral_update(estimate)
        prediction = action.forward(coefficients)
        residual = prediction - target
        derivatives = np.einsum(
            "aiub,b->aiu",
            action.lateral_derivative_matrices,
            coefficients,
            optimize=True,
        )
        gradient = np.real(
            np.einsum(
                "aiu,iu->a", np.conjugate(derivatives), residual, optimize=True
            )
        )
        hessian = np.real(
            np.einsum(
                "aiu,biu->ab",
                np.conjugate(derivatives),
                derivatives,
                optimize=True,
            )
        )
        damping = 1.0e-12 * max(float(np.trace(hessian)), 1.0)
        step = -np.linalg.solve(hessian + damping * np.eye(2), gradient)
        current_loss = objective(prediction, target)
        step_scale = 1.0
        accepted = False
        for _ in range(12):
            trial = estimate + step_scale * step
            trial_field = operator.materialize_lateral_update(trial).forward(
                coefficients
            )
            trial_loss = objective(trial_field, target)
            if trial_loss <= current_loss:
                estimate = trial
                accepted = True
                break
            step_scale *= 0.5
        history.append(
            {
                "iteration": iteration,
                "loss": current_loss,
                "gradient_norm": float(np.linalg.norm(gradient)),
                "step_norm": float(np.linalg.norm(step_scale * step)),
                "step_scale": step_scale,
                "accepted": accepted,
                "estimate": estimate.tolist(),
            }
        )
        if not accepted or np.linalg.norm(step_scale * step) < 1.0e-12:
            break

    final_action = operator.materialize_lateral_update(estimate)
    final_field = final_action.forward(coefficients)
    initial_field = operator.compact().forward(coefficients)
    estimate_error = float(np.linalg.norm(estimate - truth))
    initial_relative_l2 = float(
        np.linalg.norm((initial_field - target).ravel())
        / np.linalg.norm(target.ravel())
    )
    final_relative_l2 = float(
        np.linalg.norm((final_field - target).ravel())
        / np.linalg.norm(target.ravel())
    )
    losses = [float(row["loss"]) for row in history]
    monotone = all(
        losses[index + 1] <= losses[index] * (1.0 + 1.0e-12)
        for index in range(len(losses) - 1)
    )
    passed = bool(
        estimate_error <= 2.0e-9
        and final_relative_l2 <= 2.0e-9
        and monotone
        and all(bool(row["accepted"]) for row in history)
    )
    summary = {
        "schema": "acfo-composite-translation-inference-v1",
        "passed": passed,
        "operator_expression": "A_Gamma G_layer T(d)",
        "truth_lateral_update": truth.tolist(),
        "estimated_lateral_update": estimate.tolist(),
        "translation_absolute_l2_error": estimate_error,
        "initial_field_relative_l2": initial_relative_l2,
        "final_field_relative_l2": final_relative_l2,
        "loss_monotone": monotone,
        "iterations": len(history),
        "history": history,
        "contract": operator.contract.to_dict(),
        "interpretation": (
            "Noise-free synthetic constructive-use test. It validates that the "
            "materialized composite and its derivative matrices can drive a "
            "two-parameter Gauss-Newton update; it is not experimental inference."
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "reports"
        / "acfo_composite_translation_inference_local_v1"
        / "summary.json",
    )
    parser.add_argument("--maximum-iterations", type=int, default=8)
    args = parser.parse_args()
    if args.maximum_iterations <= 0:
        raise ValueError("maximum-iterations must be positive")
    summary = validate(args.output, args.maximum_iterations)
    print(json.dumps(summary, indent=2))
    return 0 if summary["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
