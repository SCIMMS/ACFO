from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from validate_acfo_layered_vector_composite import build_channels  # noqa: E402
from waxs_cake.composite_wave_operator import (  # noqa: E402
    PreparedLayeredVectorCompositeOperator,
)
from waxs_cake.vector_debye import gauss_sine_theta_grid  # noqa: E402


def build_case() -> tuple[PreparedLayeredVectorCompositeOperator, np.ndarray]:
    theta, theta_weights = gauss_sine_theta_grid(14, 1.0)
    phi = 0.07 + np.arange(129) * (2.0 * np.pi / 129.0)
    operator = PreparedLayeredVectorCompositeOperator.build(
        theta=theta,
        theta_weights=theta_weights,
        phi=phi,
        rho_axis=np.linspace(0.0, 0.9, 6),
        psi_axis=np.arange(24) * (2.0 * np.pi / 24.0),
        z_axis=np.linspace(-0.28, 0.32, 3),
        upper_wavenumber=6.4,
        lower_wavenumber=8.1,
        damping=0.055,
        source_height=0.47,
        lateral_displacement=(0.19, -0.13),
        source_basis=build_channels(theta, phi),
        channel_labels=("x0", "y0", "x+2", "y-3", "elliptic+4", "aberrated"),
        mode_padding=8,
        miller_margin=32,
    )
    coefficients = np.array(
        [
            0.73 - 0.12j,
            -0.31 + 0.27j,
            0.18 + 0.09j,
            -0.16j,
            0.11 - 0.08j,
            -0.07 + 0.13j,
        ],
        dtype=np.complex128,
    )
    return operator, coefficients


def current_rss_bytes() -> int:
    if os.name == "posix" and Path("/proc/self/statm").is_file():
        fields = Path("/proc/self/statm").read_text(encoding="ascii").split()
        return int(fields[1]) * int(os.sysconf("SC_PAGE_SIZE"))
    try:
        import psutil

        return int(psutil.Process().memory_info().rss)
    except Exception:
        return 0


class RssMonitor:
    def __init__(self) -> None:
        self.maximum = current_rss_bytes()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self) -> None:
        while not self._stop.is_set():
            self.maximum = max(self.maximum, current_rss_bytes())
            time.sleep(0.0005)

    def __enter__(self) -> "RssMonitor":
        self._thread.start()
        return self

    def __exit__(self, *_args: object) -> None:
        self._stop.set()
        self._thread.join()
        self.maximum = max(self.maximum, current_rss_bytes())


def worker(arm: str, output: Path, warmup: int, repeats: int) -> dict[str, object]:
    setup_start = time.perf_counter()
    operator, coefficients = build_case()
    if arm == "materialized":
        action = operator.compact()
        function = lambda: action.forward(coefficients)
        prepared_array_bytes = action.cache_bytes
    elif arm == "unfused":
        function = lambda: operator.reference_forward(coefficients)
        prepared_array_bytes = operator.reference_chain_bytes
    else:
        raise ValueError("arm must be materialized or unfused")
    setup_seconds = time.perf_counter() - setup_start
    for _ in range(warmup):
        function()
    baseline_rss = current_rss_bytes()
    samples: list[float] = []
    prediction = function()
    with RssMonitor() as monitor:
        for _ in range(repeats):
            start = time.perf_counter()
            prediction = function()
            samples.append(time.perf_counter() - start)
    result = {
        "schema": "acfo-layered-vector-composite-worker-v1",
        "arm": arm,
        "setup_seconds": setup_seconds,
        "warmup": warmup,
        "repeats": repeats,
        "samples_seconds": samples,
        "median_seconds": float(np.median(samples)),
        "prepared_array_bytes": int(prepared_array_bytes),
        "baseline_rss_bytes": int(baseline_rss),
        "application_peak_rss_bytes": int(monitor.maximum),
        "application_incremental_peak_bytes": int(
            max(0, monitor.maximum - baseline_rss)
        ),
        "prediction_shape": list(prediction.shape),
        "prediction_real": prediction.real.tolist(),
        "prediction_imag": prediction.imag.tolist(),
        "contract": operator.contract.to_dict(),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    return float(
        np.linalg.norm((candidate - reference).ravel())
        / max(np.linalg.norm(reference.ravel()), np.finfo(np.float64).tiny)
    )


def prediction(row: dict[str, object]) -> np.ndarray:
    return np.asarray(row["prediction_real"]) + 1j * np.asarray(
        row["prediction_imag"]
    )


def bootstrap_interval(values: np.ndarray, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, values.size, size=(5000, values.size))
    medians = np.median(values[draws], axis=1)
    low, high = np.quantile(medians, (0.025, 0.975))
    return float(low), float(high)


def controller(output: Path, work: Path, warmup: int, repeats: int) -> dict[str, object]:
    sequence = ("materialized", "unfused", "unfused", "materialized")
    rows: list[dict[str, object]] = []
    work.mkdir(parents=True, exist_ok=True)
    for index, arm in enumerate(sequence):
        worker_output = work / f"worker_{index}_{arm}.json"
        command = [
            sys.executable,
            str(Path(__file__).resolve()),
            "--worker-arm",
            arm,
            "--output",
            str(worker_output),
            "--warmup",
            str(warmup),
            "--repeats",
            str(repeats),
        ]
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout).strip()
            raise RuntimeError(
                f"worker {index} failed with {completed.returncode}: {detail[-2000:]}"
            )
        rows.append(json.loads(worker_output.read_text(encoding="utf-8")))

    reference = prediction(rows[0])
    parity = [relative_l2(prediction(row), reference) for row in rows]
    materialized_rows = [row for row in rows if row["arm"] == "materialized"]
    unfused_rows = [row for row in rows if row["arm"] == "unfused"]
    paired_ratios: list[float] = []
    for materialized_row, unfused_row in zip(materialized_rows, unfused_rows):
        materialized_samples = np.asarray(materialized_row["samples_seconds"])
        unfused_samples = np.asarray(unfused_row["samples_seconds"])
        paired_ratios.extend((unfused_samples / materialized_samples).tolist())
    ratio_values = np.asarray(paired_ratios, dtype=np.float64)
    ratio_median = float(np.median(ratio_values))
    ratio_interval = bootstrap_interval(ratio_values, 20260903)
    materialized_peak = float(
        np.median(
            [row["application_incremental_peak_bytes"] for row in materialized_rows]
        )
    )
    unfused_peak = float(
        np.median(
            [row["application_incremental_peak_bytes"] for row in unfused_rows]
        )
    )
    peak_ratio = (
        unfused_peak / materialized_peak
        if materialized_peak > 0.0
        else (float("inf") if unfused_peak > 0.0 else 1.0)
    )
    gates = {
        "all_worker_predictions_match": max(parity) <= 5.0e-13,
        "speed_interval_lower_bound_gt_one": ratio_interval[0] > 1.0,
        "materialized_prepared_arrays_smaller": all(
            int(row["prepared_array_bytes"])
            < int(unfused_rows[0]["prepared_array_bytes"])
            for row in materialized_rows
        ),
    }
    result = {
        "schema": "acfo-layered-vector-composite-isolated-abba-v1",
        "passed": bool(all(gates.values())),
        "sequence": list(sequence),
        "warmup": warmup,
        "repeats_per_worker": repeats,
        "gates": gates,
        "prediction_relative_l2": parity,
        "performance": {
            "unfused_over_materialized_paired_median": ratio_median,
            "paired_bootstrap_95_interval": list(ratio_interval),
            "materialized_incremental_peak_bytes_median": materialized_peak,
            "unfused_incremental_peak_bytes_median": unfused_peak,
            "unfused_over_materialized_incremental_peak_ratio": peak_ratio,
            "memory_note": (
                "Sub-millisecond CPU calls can evade RSS sampling; exact prepared "
                "array bytes remain the authoritative storage comparison."
            ),
        },
        "workers": rows,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker-arm", choices=("materialized", "unfused"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--work", type=Path)
    parser.add_argument("--warmup", type=int, default=3)
    parser.add_argument("--repeats", type=int, default=31)
    args = parser.parse_args()
    if args.warmup < 0 or args.repeats <= 0:
        raise ValueError("warmup must be non-negative and repeats positive")
    if args.worker_arm:
        result = worker(args.worker_arm, args.output, args.warmup, args.repeats)
        printable = {
            "schema": result["schema"],
            "arm": result["arm"],
            "median_seconds": result["median_seconds"],
            "prepared_array_bytes": result["prepared_array_bytes"],
            "application_incremental_peak_bytes": result[
                "application_incremental_peak_bytes"
            ],
            "output": str(args.output),
        }
    else:
        work = args.work or args.output.parent / "workers"
        result = controller(args.output, work, args.warmup, args.repeats)
        printable = {
            "schema": result["schema"],
            "passed": result["passed"],
            "gates": result["gates"],
            "performance": result["performance"],
            "output": str(args.output),
        }
    print(json.dumps(printable, indent=2))
    return 0 if result.get("passed", True) else 2


if __name__ == "__main__":
    raise SystemExit(main())
