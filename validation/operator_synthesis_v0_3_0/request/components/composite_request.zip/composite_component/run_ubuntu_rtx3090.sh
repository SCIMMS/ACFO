#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
mkdir -p outputs .cache
export PYTHONPATH="$ROOT/src"

MANIFEST_AUDIT_TMP="$(mktemp)"
python scripts/verify_request_package_manifest.py \
  --root "$ROOT" --manifest MANIFEST.json --require-exact \
  2>&1 | tee "$MANIFEST_AUDIT_TMP"
MANIFEST_STATUS=${PIPESTATUS[0]}
mv "$MANIFEST_AUDIT_TMP" outputs/manifest_audit.log

python - <<'PY' > outputs/environment.json
import json, os, platform
import numpy, scipy

gpu = None
torch_version = None
try:
    import torch
    torch_version = torch.__version__
    if torch.cuda.is_available():
        gpu = torch.cuda.get_device_name(0)
except Exception as exc:
    torch_version = f"unavailable: {exc}"

print(json.dumps({
    "python": platform.python_version(),
    "platform": platform.platform(),
    "processor": platform.processor(),
    "logical_cpu_count": os.cpu_count(),
    "numpy": numpy.__version__,
    "scipy": scipy.__version__,
    "torch": torch_version,
    "gpu": gpu,
}, indent=2))
PY
ENVIRONMENT_STATUS=$?

python -m py_compile \
  src/waxs_cake/composite_wave_operator.py \
  src/waxs_cake/vector_debye.py \
  src/waxs_cake/layered_dyadic_green.py \
  scripts/validate_acfo_layered_vector_composite.py \
  scripts/validate_acfo_composite_translation_inference.py \
  scripts/benchmark_acfo_layered_vector_composite_external.py
COMPILE_STATUS=$?

python -m pytest tests/test_composite_wave_operator.py -q \
  2>&1 | tee outputs/pytest.log
PYTEST_STATUS=${PIPESTATUS[0]}

python scripts/validate_acfo_layered_vector_composite.py \
  --output outputs/numerical_validation.json --repeats 7 \
  2>&1 | tee outputs/numerical_validation.log
NUMERICAL_STATUS=${PIPESTATUS[0]}

python scripts/validate_acfo_composite_translation_inference.py \
  --output outputs/translation_inference.json --maximum-iterations 8 \
  2>&1 | tee outputs/translation_inference.log
INFERENCE_STATUS=${PIPESTATUS[0]}

python scripts/benchmark_acfo_layered_vector_composite_external.py \
  --output outputs/isolated_abba.json \
  --work outputs/isolated_workers --warmup 3 --repeats 31 \
  2>&1 | tee outputs/isolated_abba.log
BENCHMARK_STATUS=${PIPESTATUS[0]}

export MANIFEST_STATUS ENVIRONMENT_STATUS COMPILE_STATUS PYTEST_STATUS
export NUMERICAL_STATUS INFERENCE_STATUS BENCHMARK_STATUS
python - <<'PY'
import hashlib, json, os, pathlib, zipfile

root = pathlib.Path.cwd()
outputs = root / "outputs"

def load(name):
    path = outputs / name
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None

statuses = {
    "manifest": int(os.environ["MANIFEST_STATUS"]),
    "environment": int(os.environ["ENVIRONMENT_STATUS"]),
    "compile": int(os.environ["COMPILE_STATUS"]),
    "pytest": int(os.environ["PYTEST_STATUS"]),
    "numerical_validation": int(os.environ["NUMERICAL_STATUS"]),
    "translation_inference": int(os.environ["INFERENCE_STATUS"]),
    "isolated_abba": int(os.environ["BENCHMARK_STATUS"]),
}
numerical = load("numerical_validation.json")
inference = load("translation_inference.json")
benchmark = load("isolated_abba.json")
passed = bool(
    all(value == 0 for value in statuses.values())
    and numerical is not None and numerical.get("passed") is True
    and inference is not None and inference.get("passed") is True
    and benchmark is not None and benchmark.get("passed") is True
)
summary = {
    "schema": "acfo-layered-vector-composite-external-summary-v1",
    "status": "PASS" if passed else "FAIL",
    "validation_scope": (
        "independent execution of the frozen A_Gamma G_layer T(d) "
        "materialization contract"
    ),
    "statuses": statuses,
    "numerical_gates": numerical.get("gates") if numerical else None,
    "translation_inference": {
        "translation_l2_error": inference.get("translation_l2_error"),
        "initial_field_relative_l2": inference.get("initial_field_relative_l2"),
        "final_field_relative_l2": inference.get("final_field_relative_l2"),
        "accepted_iterations": inference.get("accepted_iterations"),
    } if inference else None,
    "isolated_abba_gates": benchmark.get("gates") if benchmark else None,
    "isolated_abba_performance": benchmark.get("performance") if benchmark else None,
    "environment": load("environment.json"),
    "protocol_sha256": hashlib.sha256(
        (root / "PROTOCOL.json").read_bytes()
    ).hexdigest(),
}
(outputs / "summary.json").write_text(
    json.dumps(summary, indent=2) + "\n", encoding="utf-8"
)

request_files = [root / "MANIFEST.json", root / "PROTOCOL.json"]
return_files = sorted(path for path in outputs.rglob("*") if path.is_file())
return_manifest = {
    "schema": "acfo-layered-vector-composite-return-manifest-v1",
    "files": {
        path.relative_to(root).as_posix(): {
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in return_files + request_files
    },
}
(outputs / "RETURN_MANIFEST.json").write_text(
    json.dumps(return_manifest, indent=2) + "\n", encoding="utf-8"
)
return_files = sorted(path for path in outputs.rglob("*") if path.is_file())
archive_path = root / "acfo_layered_vector_composite_external_return.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in return_files + request_files:
        archive.write(path, path.relative_to(root).as_posix())
(root / "acfo_layered_vector_composite_external_return.zip.sha256").write_text(
    hashlib.sha256(archive_path.read_bytes()).hexdigest()
    + "  " + archive_path.name + "\n",
    encoding="utf-8",
)
print(json.dumps(summary, indent=2))
raise SystemExit(0 if passed else 2)
PY
FINALIZE_STATUS=$?

if [ "$MANIFEST_STATUS" -ne 0 ] || [ "$ENVIRONMENT_STATUS" -ne 0 ] \
   || [ "$COMPILE_STATUS" -ne 0 ] || [ "$PYTEST_STATUS" -ne 0 ] \
   || [ "$NUMERICAL_STATUS" -ne 0 ] || [ "$INFERENCE_STATUS" -ne 0 ] \
   || [ "$BENCHMARK_STATUS" -ne 0 ] || [ "$FINALIZE_STATUS" -ne 0 ]; then
  exit 2
fi
