from __future__ import annotations

import numpy as np

from waxs_cake.composite_wave_operator import (
    PreparedLayeredVectorCompositeOperator,
    layered_reflected_jones_green_mixing,
)
from waxs_cake.layered_dyadic_green import PreparedLayeredDyadicGreenOperator
from waxs_cake.vector_debye import gauss_sine_theta_grid


def _relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    return float(
        np.linalg.norm((candidate - reference).ravel())
        / max(np.linalg.norm(reference.ravel()), np.finfo(np.float64).tiny)
    )


def _source_basis(theta: np.ndarray, phi: np.ndarray) -> np.ndarray:
    radial = np.sin(theta)[:, None] / np.max(np.sin(theta))
    angle = phi[None, :]
    envelope = np.exp(-0.8 * radial**2)
    basis = np.zeros((4, 2, theta.size, phi.size), dtype=np.complex128)
    basis[0, 0] = envelope
    basis[1, 1] = envelope * (0.6 + 0.4 * radial) * np.exp(2j * angle)
    basis[2, 0] = 0.7 * envelope * np.exp(-3j * angle)
    basis[2, 1] = 0.35j * envelope * np.exp(-3j * angle)
    phase = np.exp(1j * (0.24 * radial**2 * np.cos(2.0 * angle)))
    basis[3, 0] = 0.45 * envelope * phase
    basis[3, 1] = 0.52 * envelope * np.exp(1j * angle) * phase
    return basis


def _operator() -> PreparedLayeredVectorCompositeOperator:
    theta, weights = gauss_sine_theta_grid(9, 0.92)
    phi = 0.09 + np.arange(65) * (2.0 * np.pi / 65.0)
    return PreparedLayeredVectorCompositeOperator.build(
        theta=theta,
        theta_weights=weights,
        phi=phi,
        rho_axis=np.linspace(0.0, 0.65, 4),
        psi_axis=np.arange(11) * (2.0 * np.pi / 11.0),
        z_axis=np.array([-0.18, 0.22]),
        upper_wavenumber=5.2,
        lower_wavenumber=7.1,
        damping=0.06,
        source_height=0.43,
        lateral_displacement=(0.17, -0.11),
        source_basis=_source_basis(theta, phi),
        channel_labels=("x0", "y+2", "elliptic-3", "aberrated+1"),
        mode_padding=6,
        miller_margin=32,
    )


def test_layered_green_mixing_has_expected_shape_and_homogeneous_zero_limit() -> None:
    theta, _ = gauss_sine_theta_grid(7, 0.8)
    phi = np.arange(33) * (2.0 * np.pi / 33.0)
    mixing = layered_reflected_jones_green_mixing(
        theta,
        phi,
        upper_wavenumber=4.0,
        lower_wavenumber=4.0,
        damping=0.08,
        source_height=0.5,
    )
    assert mixing.shape == (3, 2, theta.size, phi.size)
    assert np.max(np.abs(mixing)) == 0.0


def test_materialized_composite_matches_unfused_chain_and_direct_quadrature() -> None:
    operator = _operator()
    coefficients = np.array(
        [0.7 - 0.2j, -0.31 + 0.14j, 0.18 + 0.23j, -0.09j]
    )
    materialized = operator.forward(coefficients)
    unfused = operator.reference_forward(coefficients)
    direct = operator.direct_forward(coefficients)
    assert _relative_l2(materialized, unfused) < 3.0e-14
    assert _relative_l2(materialized, direct) < 4.0e-12
    assert operator.contract.channel_data_cutoff <= operator.contract.active_harmonic_cutoff
    assert operator.contract.miller_margin == 32


def test_composite_matches_independent_layered_dyadic_green_quadrature() -> None:
    theta, theta_weights = gauss_sine_theta_grid(24, 1.05)
    phi = 0.03 + np.arange(129) * (2.0 * np.pi / 129.0)
    rho_axis = np.array([0.0, 0.19, 0.42])
    psi_axis = np.arange(7) * (2.0 * np.pi / 7.0)
    basis = np.zeros((2, 2, theta.size, phi.size), dtype=np.complex128)
    basis[0, 0] = 1.0
    basis[1, 1] = 1.0
    upper = 4.7
    lower = 6.3
    damping = 0.07
    height = 0.58
    composite = PreparedLayeredVectorCompositeOperator.build(
        theta=theta,
        theta_weights=theta_weights,
        phi=phi,
        rho_axis=rho_axis,
        psi_axis=psi_axis,
        z_axis=np.array([0.0]),
        upper_wavenumber=upper,
        lower_wavenumber=lower,
        damping=damping,
        source_height=height,
        source_basis=basis,
        mode_padding=8,
        miller_margin=32,
    )
    rr, pp = np.meshgrid(rho_axis, psi_axis, indexing="ij")
    radial = upper * np.sin(theta)
    radial_weights = (
        upper * np.cos(theta) / np.sin(theta) * theta_weights
    )
    green = PreparedLayeredDyadicGreenOperator.build(
        radial_wavenumbers=radial,
        quadrature_weights=radial_weights,
        phi=phi,
        x=(rr * np.cos(pp)).ravel(),
        y=(rr * np.sin(pp)).ravel(),
        height=np.full(rr.size, height),
        upper_wavenumber=upper,
        lower_wavenumber=lower,
        damping=damping,
        mode_padding=8,
        miller_margin=32,
    )
    coefficients = np.array([0.37 - 0.14j, -0.22 + 0.31j])
    source = np.array([coefficients[0], coefficients[1], 0.0j])
    assert _relative_l2(composite.forward(coefficients), green.apply(source)) < 4.0e-12


def test_materialized_composite_adjoint_and_normal_action() -> None:
    operator = _operator()
    rng = np.random.default_rng(2026090305)
    coefficients = rng.normal(size=operator.channel_shape) + 1j * rng.normal(
        size=operator.channel_shape
    )
    cotangent = rng.normal(size=operator.field_shape) + 1j * rng.normal(
        size=operator.field_shape
    )
    left = np.vdot(operator.forward(coefficients), cotangent)
    right = np.vdot(coefficients, operator.adjoint(cotangent))
    assert abs(left - right) / max(abs(left), abs(right), 1.0) < 3.0e-14
    np.testing.assert_allclose(
        operator.adjoint(cotangent),
        operator.reference_adjoint(cotangent),
        rtol=3.0e-14,
        atol=3.0e-14,
    )
    weights = np.linspace(0.4, 1.6, operator.field_shape[1])[None, :]
    normal = operator.normal_matvec(coefficients, weights)
    quadratic = float(np.vdot(coefficients, normal).real)
    expected = float(
        np.sum(weights * np.abs(operator.forward(coefficients)) ** 2).real
    )
    assert quadratic >= -2.0e-13 * max(expected, 1.0)
    assert abs(quadratic - expected) / max(expected, 1.0) < 3.0e-14


def test_materialized_lateral_translation_jvp_vjp_and_finite_difference() -> None:
    operator = _operator()
    coefficients = np.array(
        [0.44 + 0.08j, -0.21j, 0.17 - 0.13j, 0.25 + 0.19j]
    )
    direction = np.array([0.23, -0.31])
    materialized = operator.lateral_translation_jvp(coefficients, direction)
    unfused = operator.reference_lateral_translation_jvp(coefficients, direction)
    assert _relative_l2(materialized, unfused) < 4.0e-14

    step = 1.0e-6
    plus = operator.reference_translated_forward(coefficients, step * direction)
    minus = operator.reference_translated_forward(coefficients, -step * direction)
    finite = (plus - minus) / (2.0 * step)
    assert _relative_l2(materialized, finite) < 3.0e-9

    rng = np.random.default_rng(2026090306)
    cotangent = rng.normal(size=operator.field_shape) + 1j * rng.normal(
        size=operator.field_shape
    )
    gradient = operator.lateral_translation_vjp(coefficients, cotangent)
    left = float(np.vdot(materialized, cotangent).real)
    right = float(np.dot(direction, gradient))
    assert abs(left - right) / max(abs(left), abs(right), 1.0) < 4.0e-14


def test_channel_materialization_reduces_hot_state_for_low_dimensional_task() -> None:
    operator = _operator()
    compact = operator.compact()
    coefficients = np.array([0.2j, 0.3 - 0.1j, -0.4, 0.12 + 0.08j])
    np.testing.assert_array_equal(compact.forward(coefficients), operator.forward(coefficients))
    assert compact.cache_bytes == operator.materialized_bytes
    assert operator.materialized_bytes < operator.reference_chain_bytes
    assert operator.avoided_intermediate_bytes_per_call > 0


def test_finite_lateral_update_rematerializes_exact_composite_action() -> None:
    operator = _operator()
    coefficients = np.array([0.18 + 0.04j, -0.12j, 0.23 - 0.09j, 0.07])
    displacement = np.array([0.035, -0.022])
    updated = operator.materialize_lateral_update(displacement)
    reference = operator.reference_translated_forward(coefficients, displacement)
    assert _relative_l2(updated.forward(coefficients), reference) < 4.0e-14
    expected_anchor = np.asarray(operator.contract.lateral_displacement) + displacement
    np.testing.assert_allclose(updated.contract.lateral_displacement, expected_anchor)
