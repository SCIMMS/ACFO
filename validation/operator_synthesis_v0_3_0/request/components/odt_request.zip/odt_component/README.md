# ODT Toeplitz SI RTX 3090 validation request v1

This package provides a reviewer-facing matched comparison on one Cartesian
ODT state:

1. reusable cuFINUFFT type-2/type-1 explicit normal,
2. a conventional FINUFFT-built cached Toeplitz normal,
3. an optional all-GPU cuFINUFFT-built Toeplitz normal, and
4. an ACFO-derived symmetry-aware Toeplitz compiler.

It reports method setup, hot normal apply, device-residency and allocator
memory, fixed-operator amortization, and weight-update amortization.  Separate
complex128 exact, Hermitian/PSD, structured-weight, and CG-trajectory gates
establish correctness.  The all-GPU 512^3 generic setup is allowed to exhaust
memory; such a failure is retained as memory evidence and does not suppress
the remaining return.

Prerequisites are an Ubuntu Python >=3.11 environment with NumPy, SciPy,
FINUFFT, CUDA PyTorch, CuPy, and cuFINUFFT already installed.  The requested
publication machine is an RTX 3090 with approximately 24 GiB VRAM and at least
12 GiB free disk.

Run:

```bash
chmod +x ./run_ubuntu_rtx3090.sh
./run_ubuntu_rtx3090.sh
```

The runner always attempts to create these two sibling files even when a
scientific or performance gate is unfavorable:

- `odt_toeplitz_si_external_return.zip`
- `odt_toeplitz_si_external_return.zip.sha256`

Return both files without editing them.  A nonzero runner exit status does not
mean that the return ZIP is unusable; inspect and return the two artifacts.

Package plumbing smoke on a non-publication CUDA host is available with:

```bash
PYTHONPATH="$PWD/src:$PWD/scripts" python3   scripts/run_odt_toeplitz_si_external_validation.py   --mode smoke --allow-non-rtx3090
```
