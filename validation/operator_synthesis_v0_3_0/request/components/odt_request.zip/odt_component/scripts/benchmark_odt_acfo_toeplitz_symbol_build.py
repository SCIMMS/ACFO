#!/usr/bin/env python3
"""Benchmark an angularly contracted build of the physical ODT Toeplitz symbol.

This is a standalone feasibility experiment.  It does not modify or call the
production cylindrical solver.  For the frozen production detector geometry
and unit data weights, the Cartesian normal PSF factorizes as

    K(d) = D(d) I(d),

because the q samples are the Cartesian product of detector and illumination
directions.  Uniform detector and illumination azimuth combs reduce to J0 plus
aliases whose first orders are 128/256 and 120, respectively.  On the finite
Cartesian difference grid their maximum Bessel argument is only about 45, so
the aliases are far below double precision.

The prototype constructs D and I on unique integer lateral radii, contracts
the detector radial coordinate with the axial coordinate by GEMM, gathers the
signed-difference PSF, and performs the same 2N circulant embedding and FFT as
the existing FINUFFT reference.  The resulting centered kernel and symbol are
gated against a full production-q FINUFFT type-1 build in complex128.
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import fft as scipy_fft
from scipy import special


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_banded_detector import VARIANTS  # noqa: E402
from benchmark_odt_cartesian_toeplitz_exact_gate import (  # noqa: E402
    cartesian_spacing,
    centered_modes_to_embedded_kernel,
    create_finufft_plan,
    production_q_geometry,
    scaled_finufft_coordinates,
)
from benchmark_odt_ewald_cap_operator import detector_radial_nodes  # noqa: E402


DEFAULT_OUTPUT = (
    ROOT
    / "benchmark_results"
    / "odt_acfo_toeplitz_symbol_build_20260805.json"
)
DEFAULT_SUMMARY = (
    ROOT
    / "benchmark_results"
    / "odt_acfo_toeplitz_symbol_build_20260805_ko.md"
)
DEFAULT_PRODUCTION_RECEIPT = (
    ROOT
    / "benchmark_results"
    / "odt_cartesian_toeplitz_exact_gate_20260805.json"
)


def timed(callback: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = callback()
    return value, float(time.perf_counter() - start)


def parse_sizes(text: str) -> list[int]:
    values = [int(part.strip()) for part in text.split(",") if part.strip()]
    if not values or any(value <= 0 for value in values):
        raise ValueError("sizes must be positive comma-separated integers")
    return values


def fmt(value: Any, digits: int = 3) -> str:
    value_f = float(value)
    if value_f == 0.0:
        return "0"
    if abs(value_f) < 1e-3 or abs(value_f) >= 1e3:
        return f"{value_f:.{digits}e}"
    return f"{value_f:.{digits}f}"


def relative_l2_chunked(
    candidate: np.ndarray,
    reference: np.ndarray,
    *,
    chunk_elements: int = 1 << 20,
) -> float:
    if candidate.shape != reference.shape:
        raise ValueError("relative-L2 operands have different shapes")
    candidate_flat = candidate.reshape(-1)
    reference_flat = reference.reshape(-1)
    numerator = 0.0
    denominator = 0.0
    for start in range(0, reference_flat.size, chunk_elements):
        stop = min(start + chunk_elements, reference_flat.size)
        reference_part = reference_flat[start:stop]
        difference = candidate_flat[start:stop] - reference_part
        numerator += float(np.vdot(difference, difference).real)
        denominator += float(np.vdot(reference_part, reference_part).real)
    return float(math.sqrt(numerator / max(denominator, np.finfo(float).tiny)))


def max_abs_error_chunked(
    candidate: np.ndarray,
    reference: np.ndarray,
    *,
    chunk_elements: int = 1 << 20,
) -> float:
    candidate_flat = candidate.reshape(-1)
    reference_flat = reference.reshape(-1)
    maximum = 0.0
    for start in range(0, reference_flat.size, chunk_elements):
        stop = min(start + chunk_elements, reference_flat.size)
        maximum = max(
            maximum,
            float(
                np.max(
                    np.abs(candidate_flat[start:stop] - reference_flat[start:stop])
                )
            ),
        )
    return maximum


def analytic_detector_geometry(args: argparse.Namespace) -> dict[str, Any]:
    if args.variant not in VARIANTS:
        raise ValueError(f"unknown detector variant {args.variant!r}")
    start = time.perf_counter()
    radial_parts: list[np.ndarray] = []
    multiplicity_parts: list[np.ndarray] = []
    bands: list[dict[str, Any]] = []
    for specification in VARIANTS[args.variant]:
        radial = detector_radial_nodes(
            detector_na=float(args.detector_na),
            cap_radial=int(specification["cap_radial"]),
            sampling=str(specification["sampling"]),
            outer_power=float(specification["outer_power"]),
            min_fraction=float(specification["min_fraction"]),
            max_fraction=float(specification["max_fraction"]),
        )
        cap_phi = int(specification["cap_phi"])
        radial_parts.append(radial)
        multiplicity_parts.append(
            np.full(radial.shape, float(cap_phi), dtype=np.float64)
        )
        bands.append(
            {
                "name": str(specification["name"]),
                "cap_radial": int(radial.size),
                "cap_phi": cap_phi,
                "radial_min": float(radial.min()),
                "radial_max": float(radial.max()),
            }
        )
    radial = np.ascontiguousarray(np.concatenate(radial_parts), dtype=np.float64)
    multiplicity = np.ascontiguousarray(
        np.concatenate(multiplicity_parts), dtype=np.float64
    )
    axial = np.sqrt(np.maximum(1.0 - radial * radial, 0.0))
    return {
        "radial": radial,
        "axial": np.ascontiguousarray(axial),
        "multiplicity": multiplicity,
        "bands": bands,
        "setup_s": float(time.perf_counter() - start),
    }


def unique_lateral_radii(n: int, spacing_xy: float) -> dict[str, Any]:
    differences = np.arange(-(n - 1), n, dtype=np.int64)
    squared = differences[:, None] ** 2 + differences[None, :] ** 2
    unique_squared, inverse = np.unique(squared, return_inverse=True)
    radii = float(spacing_xy) * np.sqrt(unique_squared.astype(np.float64))
    return {
        "differences": differences,
        "unique_squared": unique_squared,
        "radii": np.ascontiguousarray(radii),
        "inverse": np.ascontiguousarray(inverse.reshape(squared.shape)),
    }


def build_acfo_centered_kernel(
    args: argparse.Namespace,
    detector: dict[str, Any],
    n: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    spacing = cartesian_spacing(args, n)
    if not math.isclose(spacing[0], spacing[1], rel_tol=0.0, abs_tol=0.0):
        raise ValueError("unique-radius contraction requires equal x/y spacing")

    radii_data, radius_setup_s = timed(
        lambda: unique_lateral_radii(n, spacing[0])
    )
    differences = radii_data["differences"]
    radii = radii_data["radii"]
    inverse = radii_data["inverse"]
    z = np.ascontiguousarray(differences.astype(np.float64) * spacing[2])

    k = float(args.k)
    ring_na = math.sin(math.radians(float(args.illumination_angle_deg)))
    ring_sz = math.sqrt(max(1.0 - ring_na * ring_na, 0.0))
    detector_radial = detector["radial"]
    detector_axial = detector["axial"]
    detector_multiplicity = detector["multiplicity"]

    def make_tables() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        detector_j0 = special.j0(
            k * radii[:, None] * detector_radial[None, :]
        )
        detector_j0 *= detector_multiplicity[None, :]
        detector_z = np.exp(1j * k * detector_axial[:, None] * z[None, :])
        illumination_j0 = special.j0(k * ring_na * radii)
        return (
            np.ascontiguousarray(detector_j0),
            np.ascontiguousarray(detector_z),
            np.ascontiguousarray(illumination_j0),
        )

    (detector_j0, detector_z, illumination_j0), table_setup_s = timed(make_tables)

    detector_sum, detector_contraction_s = timed(lambda: detector_j0 @ detector_z)
    del detector_j0, detector_z
    illumination_sum = (
        float(args.ring_illum)
        * illumination_j0[:, None]
        * np.exp(-1j * k * ring_sz * z)[None, :]
        + np.exp(-1j * k * z)[None, :]
    )
    psf_table, product_s = timed(lambda: detector_sum * illumination_sum)
    del detector_sum, illumination_sum, illumination_j0

    side = 2 * n - 1

    def gather() -> np.ndarray:
        signed = psf_table[inverse.reshape(-1), :].reshape(side, side, side)
        centered = np.zeros((2 * n, 2 * n, 2 * n), dtype=np.complex128)
        centered[1:, 1:, 1:] = signed
        return np.ascontiguousarray(centered)

    centered, gather_s = timed(gather)
    center_value = centered[n, n, n]
    del psf_table
    gc.collect()
    return centered, {
        "spacing_um": list(spacing),
        "signed_lateral_point_count": int(side * side),
        "unique_lateral_radius_count": int(radii.size),
        "radius_reuse_factor": float((side * side) / radii.size),
        "signed_z_count": int(side),
        "detector_radial_count": int(detector_radial.size),
        "contraction_complex_mac_count": int(radii.size * detector_radial.size * side),
        "center_value_real": float(center_value.real),
        "center_value_imag": float(center_value.imag),
        "timing_s": {
            "unique_radius_setup": radius_setup_s,
            "bessel_and_axial_tables": table_setup_s,
            "radial_axial_gemm": detector_contraction_s,
            "detector_illumination_product": product_s,
            "signed_difference_gather": gather_s,
        },
    }


def build_finufft_reference(
    args: argparse.Namespace,
    q: dict[str, Any],
    n: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    import finufft

    spacing = cartesian_spacing(args, n)

    def scale_coordinates() -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
        return scaled_finufft_coordinates(q, spacing, real_dtype=np.dtype(np.float64))

    (qx, qy, qz, coordinate_max), coordinate_s = timed(scale_coordinates)
    coordinates = (qx, qy, qz)
    plan, plan_setup_s = create_finufft_plan(
        finufft,
        1,
        (2 * n, 2 * n, 2 * n),
        coordinates,
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    strengths = np.ones(int(q["metadata"]["q_count"]), dtype=np.complex128)
    centered, execute_s = timed(lambda: plan.execute(strengths))
    del plan, strengths, qx, qy, qz
    centered = np.ascontiguousarray(centered, dtype=np.complex128)
    centered[0, :, :] = 0
    centered[:, 0, :] = 0
    centered[:, :, 0] = 0
    embedded, embedding_s = timed(lambda: np.fft.ifftshift(centered))
    symbol, symbol_fft_s = timed(
        lambda: scipy_fft.fftn(embedded, workers=int(args.fft_workers))
    )
    del embedded
    gc.collect()
    timing = {
        "coordinate_scaling": coordinate_s,
        "type1_plan_setup": plan_setup_s,
        "type1_execute": execute_s,
        "signed_difference_embedding": embedding_s,
        "symbol_fft": symbol_fft_s,
    }
    return centered, np.ascontiguousarray(symbol), {
        "spacing_um": list(spacing),
        "scaled_q_coordinate_max_abs": coordinate_max,
        "finufft_eps": float(args.finufft_eps),
        "timing_s": timing,
        "kernel_build_s": float(coordinate_s + plan_setup_s + execute_s),
        "symbol_total_s": float(sum(timing.values())),
    }


def add_acfo_symbol(
    args: argparse.Namespace,
    centered: np.ndarray,
    metadata: dict[str, Any],
) -> tuple[np.ndarray, dict[str, Any]]:
    embedded, embedding_s = timed(
        lambda: centered_modes_to_embedded_kernel(centered, centered.shape[0] // 2)
    )
    symbol, fft_s = timed(
        lambda: scipy_fft.fftn(embedded, workers=int(args.fft_workers))
    )
    del embedded
    metadata["timing_s"]["signed_difference_embedding"] = embedding_s
    metadata["timing_s"]["symbol_fft"] = fft_s
    kernel_keys = (
        "unique_radius_setup",
        "bessel_and_axial_tables",
        "radial_axial_gemm",
        "detector_illumination_product",
        "signed_difference_gather",
    )
    metadata["kernel_build_s"] = float(
        sum(metadata["timing_s"][key] for key in kernel_keys)
    )
    metadata["symbol_total_s"] = float(sum(metadata["timing_s"].values()))
    return np.ascontiguousarray(symbol), metadata


def log_bessel_series_bound(order: int, argument: float) -> float:
    """Log of a simple absolute-series upper bound for |J_order(argument)|."""

    if order < 0 or argument < 0.0:
        raise ValueError("order and argument must be non-negative")
    if argument == 0.0:
        return 0.0 if order == 0 else -math.inf
    return (
        order * math.log(argument / 2.0)
        - math.lgamma(order + 1.0)
        + argument * argument / (4.0 * (order + 1.0))
    )


def angular_comb_alias_metrics(period: int, argument_max: float) -> dict[str, Any]:
    # S_P/P = J0 + sum_{t != 0} i^(tP) J_(tP) exp(i tP beta).
    # All production periods are multiples of four.  The absolute-series bound
    # below is independent of beta and includes both signs of every alias.
    first_log_bound = log_bessel_series_bound(period, argument_max)
    first_bound = 0.0 if first_log_bound < -745.0 else math.exp(first_log_bound)
    # For B_n(a)=(a/2)^n/n!*exp(a^2/(4(n+1))), the ratio from n=tP
    # to n=(t+1)P is at most (a/(2(P+1)))^P: the factorial denominator
    # only grows and the exponential factor decreases.  Thus the infinite
    # alias tail is bounded by a geometric series starting at B_P.
    ratio = (
        0.0
        if argument_max == 0.0
        else math.exp(period * math.log(argument_max / (2.0 * (period + 1.0))))
    )
    if ratio >= 1.0:
        raise ValueError("angular alias bound requires argument < 2(P+1)")
    rigorous_bound = 2.0 * first_bound / (1.0 - ratio)
    leading = 2.0 * abs(float(special.jv(period, argument_max)))
    return {
        "period": int(period),
        "argument_max": float(argument_max),
        "leading_plus_minus_alias_abs": leading,
        "absolute_series_alias_bound": rigorous_bound,
        "first_surviving_angular_orders": [-int(period), int(period)],
    }


def alias_report(
    args: argparse.Namespace,
    detector: dict[str, Any],
    n: int,
) -> dict[str, Any]:
    spacing = cartesian_spacing(args, n)
    maximum_difference = (n - 1) * spacing[0] * math.sqrt(2.0)
    ring_na = math.sin(math.radians(float(args.illumination_angle_deg)))
    detector_by_period: dict[int, float] = {}
    for band in detector["bands"]:
        period = int(band["cap_phi"])
        detector_by_period[period] = max(
            detector_by_period.get(period, 0.0), float(band["radial_max"])
        )
    illumination = angular_comb_alias_metrics(
        int(args.ring_illum),
        float(args.k) * ring_na * maximum_difference,
    )
    detector = [
        angular_comb_alias_metrics(
            period, float(args.k) * radial_max * maximum_difference
        )
        for period, radial_max in sorted(detector_by_period.items())
    ]
    common_symmetry = math.gcd(
        int(args.ring_illum),
        math.gcd(*(int(row["period"]) for row in detector)),
    )
    inner_detector = next(row for row in detector if int(row["period"]) == 128)
    lowest_mode_indicator = (
        inner_detector["leading_plus_minus_alias_abs"]
        * illumination["leading_plus_minus_alias_abs"]
        / 2.0
    )
    return {
        "maximum_lateral_difference_um": float(maximum_difference),
        "illumination": illumination,
        "detector": detector,
        "combined_exact_rotational_symmetry": f"C{common_symmetry}",
        "lowest_nonzero_combined_mode": int(common_symmetry),
        "lowest_mode_construction": "128 - 120 = 8",
        "leading_plus_minus_m8_indicator": float(lowest_mode_indicator),
        "interpretation": (
            "bounds apply to the normalized comb S_P/P minus J0; production "
            "periods are multiples of four"
        ),
    }


def load_production_setup(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    for case in payload.get("gpu_cases", []):
        if int(case.get("n", -1)) == 256:
            comparison = case.get("comparison", {})
            build = case.get("kernel_build", {})
            return {
                "source": str(path.resolve()),
                "n": 256,
                "generic_symbol_total_build_s": comparison.get(
                    "generic_symbol_total_build_s"
                ),
                "type1_execute_s": build.get("type1_execute_s"),
                "symbol_gpu_build_s": build.get("symbol_gpu_build_s"),
                "dtype": case.get("dtype"),
            }
    return None


def projected_work(args: argparse.Namespace, detector: dict[str, Any], n: int) -> dict[str, Any]:
    spacing = cartesian_spacing(args, n)
    radius_count = int(unique_lateral_radii(n, spacing[0])["radii"].size)
    side = 2 * n - 1
    return {
        "n": int(n),
        "signed_lateral_point_count": int(side * side),
        "unique_lateral_radius_count": radius_count,
        "radius_reuse_factor": float((side * side) / radius_count),
        "signed_z_count": int(side),
        "detector_radial_count": int(detector["radial"].size),
        "contraction_complex_mac_count": int(
            radius_count * int(detector["radial"].size) * side
        ),
    }


def run_case(
    args: argparse.Namespace,
    q: dict[str, Any],
    detector: dict[str, Any],
    n: int,
) -> dict[str, Any]:
    reference_centered, reference_symbol, reference = build_finufft_reference(
        args, q, n
    )
    acfo_centered, acfo = build_acfo_centered_kernel(args, detector, n)
    acfo_symbol, acfo = add_acfo_symbol(args, acfo_centered, acfo)

    kernel_error, kernel_gate_s = timed(
        lambda: relative_l2_chunked(acfo_centered, reference_centered)
    )
    symbol_error, symbol_gate_s = timed(
        lambda: relative_l2_chunked(acfo_symbol, reference_symbol)
    )
    kernel_max_abs = max_abs_error_chunked(acfo_centered, reference_centered)
    expected_center = int(q["metadata"]["q_count"])
    center_relative_error = abs(acfo_centered[n, n, n] - expected_center) / expected_center
    passed = bool(
        kernel_error <= float(args.relative_l2_tolerance)
        and symbol_error <= float(args.relative_l2_tolerance)
        and center_relative_error <= float(args.relative_l2_tolerance)
    )
    result = {
        "n": int(n),
        "shape": [n, n, n],
        "padded_shape": [2 * n, 2 * n, 2 * n],
        "dtype": "complex128",
        "reference": reference,
        "acfo": acfo,
        "alias": alias_report(args, detector, n),
        "metrics": {
            "centered_kernel_relative_l2": kernel_error,
            "symbol_relative_l2": symbol_error,
            "centered_kernel_max_abs_error": kernel_max_abs,
            "center_value_expected": expected_center,
            "center_value_relative_error": float(center_relative_error),
        },
        "comparison": {
            "kernel_build_speedup": float(
                reference["kernel_build_s"] / acfo["kernel_build_s"]
            ),
            "symbol_total_speedup": float(
                reference["symbol_total_s"] / acfo["symbol_total_s"]
            ),
            "gate_evaluation_s": float(kernel_gate_s + symbol_gate_s),
        },
        "gate": {
            "relative_l2_tolerance": float(args.relative_l2_tolerance),
            "passed": passed,
        },
    }
    del reference_centered, reference_symbol, acfo_centered, acfo_symbol
    gc.collect()
    return result


def render_markdown(result: dict[str, Any]) -> str:
    lines = [
        "# ODT physical Toeplitz symbol ACFO build 실험",
        "",
        f"- 판정: **{'PASS' if result['passed'] else 'FAIL'}**",
        f"- production q 수: {result['geometry']['q_count']:,}",
        "- 원본 solver 변경: 없음 (독립 complex128 Cartesian gate)",
        "",
        "## 결과",
        "",
        "| N | unique r² / xy | kernel rel-L2 | symbol rel-L2 | FINUFFT setup (s) | ACFO setup (s) | speedup |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for case in result["cases"]:
        acfo = case["acfo"]
        lines.append(
            "| "
            f"{case['n']} | "
            f"{acfo['unique_lateral_radius_count']:,} / {acfo['signed_lateral_point_count']:,} | "
            f"{fmt(case['metrics']['centered_kernel_relative_l2'])} | "
            f"{fmt(case['metrics']['symbol_relative_l2'])} | "
            f"{fmt(case['reference']['symbol_total_s'])} | "
            f"{fmt(acfo['symbol_total_s'])} | "
            f"{fmt(case['comparison']['symbol_total_speedup'])}x |"
        )

    lines.extend(
        [
            "",
            "## 사용한 contraction",
            "",
            "production q 집합이 detector 방향과 illumination 방향의 완전한 Cartesian product이므로, unit weight에서 signed-difference PSF는 정확히",
            "",
            "```text",
            "K(d) = sum_{s_d,s_i} exp(+i k (s_d-s_i)·d) = D(d) I(d)",
            "D(r,z) = sum_b P_b sum_u J0(k rho_{b,u} r) exp(+i k s_{z,b,u} z)",
            "I(r,z) = 120 J0(k rho_i r) exp(-i k s_{z,i} z) + exp(-i k z)",
            "```",
            "",
            "로 줄어든다. 두 번째와 세 번째 식은 uniform angular comb의 0차 mode이다. finite comb의 정확한 전개는 `S_P/P = Σ_t i^(tP) J_(tP)(a) exp(i tP beta)`이며, 이 격자에서는 첫 alias order가 argument보다 훨씬 크다.",
            "",
            "정확한 discrete symmetry는 `gcd(120,128,256)=8`, 즉 C8이다. 그러나 가장 낮은 m=8은 `128-120` alias의 곱으로만 생기며, 아래 개별 alias보다도 훨씬 작다. 따라서 이 finite grid와 double precision에서는 사실상 m=0만 남는다.",
            "",
            "## finite angular comb 확인",
            "",
            "| N | comb | max argument | leading ±alias | rigorous absolute-series bound |",
            "|---:|---:|---:|---:|---:|",
        ]
    )
    for case in result["cases"]:
        alias_rows = [case["alias"]["illumination"], *case["alias"]["detector"]]
        for row in alias_rows:
            lines.append(
                f"| {case['n']} | P={row['period']} | "
                f"{fmt(row['argument_max'])} | "
                f"{fmt(row['leading_plus_minus_alias_abs'])} | "
                f"{fmt(row['absolute_series_alias_bound'])} |"
            )

    production = result.get("production_reference")
    lines.extend(["", "## production N=256 판단", ""])
    if production is not None:
        lines.append(
            f"기존 receipt의 generic complex64 symbol setup은 {fmt(production['generic_symbol_total_build_s'])} s "
            f"(type-1 execute {fmt(production['type1_execute_s'])} s, GPU symbol FFT {fmt(production['symbol_gpu_build_s'])} s)였다."
        )
        lines.append("")
    projected = result["projected_n256"]
    lines.extend(
        [
            f"N=256에서는 xy {projected['signed_lateral_point_count']:,}개가 unique r² {projected['unique_lateral_radius_count']:,}개로 줄어들어 {projected['radius_reuse_factor']:.2f}배 재사용된다. radial-z contraction은 {projected['contraction_complex_mac_count']:,} complex MAC이다.",
            "",
            "작은 gate가 통과하면 ACFO는 3,469,312-point type-1 NUFFT를 Bessel table + dense contraction으로 대체할 근거가 있다. 다만 N=256의 512³ complex64 gather, host/device transfer, GPU FFT를 포함한 end-to-end 시간은 아직 측정하지 않았으므로 여기서는 외삽 속도를 주장하지 않는다.",
            "",
            "## 적용 경계",
            "",
            "- 이 결과는 fixed geometry, uniform azimuth, W=I인 Cartesian-state normal symbol에 한정된다.",
            "- detector/illumination별 비균일 weight나 missing azimuth가 있으면 `D·I` 또는 순수 J0 축약이 깨지고 angular FFT/mode correction이 필요하다.",
            "- 현재 production cylindrical coefficient solver와의 등가는 별도 문제다.",
        ]
    )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> dict[str, Any]:
    sizes = parse_sizes(args.sizes)
    if args.variant != "banded_inner96_outer64":
        raise ValueError("this frozen gate targets banded_inner96_outer64")
    if args.ring_illum <= 0:
        raise ValueError("ring-illum must be positive")

    detector = analytic_detector_geometry(args)
    q = production_q_geometry(args)
    cases = [run_case(args, q, detector, n) for n in sizes]
    result = {
        "schema": "odt-acfo-toeplitz-symbol-build-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": bool(all(case["gate"]["passed"] for case in cases)),
        "geometry": q["metadata"],
        "analytic_geometry": {
            "bands": detector["bands"],
            "detector_radial_count": int(detector["radial"].size),
            "setup_s": float(detector["setup_s"]),
        },
        "factorization": {
            "identity": "K(d)=D(d)I(d) for the detector x illumination Cartesian product",
            "detector": "sum_b P_b sum_u J0(k*rho_bu*r) exp(+i*k*sz_bu*z)",
            "illumination": "I_ring*J0(k*rho_i*r)exp(-i*k*sz_i*z)+exp(-i*k*z)",
            "finite_comb": "S_P/P=sum_t i^(tP) J_(tP)(a) exp(i*tP*beta)",
        },
        "cases": cases,
        "production_reference": load_production_setup(args.production_receipt),
        "projected_n256": projected_work(args, detector, 256),
        "scope": [
            "fixed production detector and ring-plus-axis illumination geometry",
            "uniform azimuth sampling and unit diagonal data weights W=I",
            "uniform Cartesian reconstruction state and exact 2N Toeplitz embedding",
            "standalone feasibility benchmark; original solver is unchanged",
        ],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "finufft": __import__("finufft").__version__,
            "platform": platform.platform(),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--sizes", default="64,128")
    p.add_argument("--finufft-eps", type=float, default=1e-12)
    p.add_argument("--finufft-threads", type=int, default=0)
    p.add_argument("--fft-workers", type=int, default=-1)
    p.add_argument("--relative-l2-tolerance", type=float, default=1e-10)
    p.add_argument("--production-receipt", type=Path, default=DEFAULT_PRODUCTION_RECEIPT)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--summary", type=Path, default=DEFAULT_SUMMARY)
    return p


if __name__ == "__main__":
    arguments = parser().parse_args()
    payload = run(arguments)
    for case in payload["cases"]:
        print(
            f"N={case['n']} pass={case['gate']['passed']} "
            f"kernel_rel_l2={case['metrics']['centered_kernel_relative_l2']:.3e} "
            f"symbol_rel_l2={case['metrics']['symbol_relative_l2']:.3e} "
            f"setup_speedup={case['comparison']['symbol_total_speedup']:.2f}x"
        )
    print(f"wrote {arguments.output}")
    print(f"wrote {arguments.summary}")
