#!/usr/bin/env python3
"""Benchmark one isolated GPU backend for the ODT Toeplitz SI comparison.

Each invocation runs exactly one backend in a fresh process so CUDA allocator
and plan memory are not contaminated by another method.  All backends use the
same Cartesian state, production q cloud, deterministic object, complex64
precision, and W=I normal operator.
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_acfo_toeplitz_symbol_build import (  # noqa: E402
    analytic_detector_geometry,
)
from benchmark_odt_acfo_toeplitz_symbol_gpu import (  # noqa: E402
    build_acfo_centered_complex64,
    gpu_symbol_from_centered,
)
from benchmark_odt_cartesian_toeplitz_exact_gate import (  # noqa: E402
    build_centered_kernel_complex64,
    cartesian_spacing,
    production_q_geometry,
    scaled_finufft_coordinates,
    timing_summary,
)
from benchmark_odt_cufinufft_gpu_baseline import (  # noqa: E402
    import_cufinufft_modules,
    synchronize_cupy,
)


DEFAULT_OUTPUT = ROOT / "benchmark_results" / "odt_toeplitz_si_gpu_backend.json"


def timed(callback: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = callback()
    return value, float(time.perf_counter() - start)


def process_rss_mib() -> float | None:
    try:
        import psutil

        return float(psutil.Process().memory_info().rss / 1024**2)
    except (ImportError, OSError):
        return None


def process_peak_rss_mib() -> float | None:
    try:
        import resource

        value = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if sys.platform == "darwin":
            return value / 1024**2
        return value / 1024.0
    except (ImportError, OSError, ValueError):
        return process_rss_mib()


def deterministic_object(n: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(int(seed) + 17 * int(n))
    real = rng.standard_normal((n, n, n), dtype=np.float32)
    imag = rng.standard_normal((n, n, n), dtype=np.float32)
    return np.ascontiguousarray((real + 1j * imag).astype(np.complex64))


def sample_indices(size: int, count: int, seed: int) -> np.ndarray:
    if size <= 0 or count <= 0:
        raise ValueError("sample size/count must be positive")
    rng = np.random.default_rng(int(seed) + 9107)
    count = min(int(count), int(size))
    return np.sort(rng.choice(size, size=count, replace=False).astype(np.int64))


def signature_from_numpy(
    output: np.ndarray, obj: np.ndarray, indices: np.ndarray
) -> dict[str, Any]:
    flat = np.asarray(output).reshape(-1)
    sampled = flat[indices].astype(np.complex128, copy=False)
    energy = np.vdot(obj.reshape(-1), flat)
    return {
        "sample_indices": [int(value) for value in indices],
        "sample_values_real_imag": [
            [float(value.real), float(value.imag)] for value in sampled
        ],
        "output_norm": float(np.linalg.norm(flat)),
        "output_mean": [float(flat.mean().real), float(flat.mean().imag)],
        "rayleigh_real": float(energy.real),
        "rayleigh_imag_over_abs": float(
            abs(energy.imag) / max(abs(energy), np.finfo(float).tiny)
        ),
        "rayleigh_nonnegative": bool(energy.real >= 0.0),
    }


def base_receipt(
    args: argparse.Namespace, q: dict[str, Any], geometry_build_s: float
) -> dict[str, Any]:
    return {
        "schema": "odt-toeplitz-si-gpu-backend-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "backend": args.backend,
        "passed": False,
        "geometry": q["metadata"],
        "configuration": {
            "n": int(args.n),
            "shape": [int(args.n)] * 3,
            "padded_shape": [2 * int(args.n)] * 3,
            "dtype": "complex64",
            "data_weights": "W=I",
            "seed": int(args.seed),
            "warmups": int(args.warmups),
            "repeats": int(args.repeats),
            "sample_count": int(args.sample_count),
            "cufinufft_eps": float(args.cufinufft_eps),
            "generic_finufft_eps": float(args.generic_finufft_eps),
        },
        "common_geometry_build_s": float(geometry_build_s),
        "scope": [
            "same uniform Cartesian state and production ring-plus-axis q samples",
            "fixed geometry and W=I normal A*WA",
            "one backend per fresh process for allocator isolation",
            "hot timing excludes common geometry and method setup",
        ],
    }


def torch_hot_apply(
    args: argparse.Namespace,
    symbol: Any,
    obj_np: np.ndarray,
) -> tuple[dict[str, Any], dict[str, Any]]:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device(args.device)
    torch.cuda.synchronize(device)
    upload_start = time.perf_counter()
    obj = torch.from_numpy(obj_np).to(device=device)
    torch.cuda.synchronize(device)
    upload_s = float(time.perf_counter() - upload_start)

    def apply() -> Any:
        padded = torch.zeros(
            symbol.shape, dtype=torch.complex64, device=device
        )
        padded[: args.n, : args.n, : args.n].copy_(obj)
        spectrum = torch.fft.fftn(padded)
        spectrum.mul_(symbol)
        del padded
        convolved = torch.fft.ifftn(spectrum)
        output = convolved[: args.n, : args.n, : args.n].clone()
        del spectrum, convolved
        return output

    with torch.inference_mode():
        for _ in range(int(args.warmups)):
            output = apply()
            torch.cuda.synchronize(device)
            del output
        baseline_allocated = int(torch.cuda.memory_allocated(device))
        baseline_reserved = int(torch.cuda.memory_reserved(device))
        free_before_hot, total = torch.cuda.mem_get_info(device)
        torch.cuda.reset_peak_memory_stats(device)
        samples: list[float] = []
        output = None
        for _ in range(int(args.repeats)):
            torch.cuda.synchronize(device)
            start = time.perf_counter()
            output = apply()
            torch.cuda.synchronize(device)
            samples.append(float(time.perf_counter() - start))
        if output is None:
            raise RuntimeError("no timed output")
        peak_allocated = int(torch.cuda.max_memory_allocated(device))
        peak_reserved = int(torch.cuda.max_memory_reserved(device))
        free_after_hot, _ = torch.cuda.mem_get_info(device)
        indices = sample_indices(obj_np.size, int(args.sample_count), int(args.seed))
        output_np = output.detach().cpu().numpy()
    signature = signature_from_numpy(output_np, obj_np, indices)
    timing = timing_summary(samples)
    memory = {
        "allocator": "torch plus device mem_get_info",
        "object_plus_cached_symbol_allocated_mib": float(
            baseline_allocated / 1024**2
        ),
        "object_plus_cached_symbol_reserved_mib": float(
            baseline_reserved / 1024**2
        ),
        "hot_peak_allocated_mib": float(peak_allocated / 1024**2),
        "hot_peak_reserved_mib": float(peak_reserved / 1024**2),
        "hot_incremental_allocated_mib": float(
            (peak_allocated - baseline_allocated) / 1024**2
        ),
        "device_total_mib": float(total / 1024**2),
        "device_free_before_hot_mib": float(free_before_hot / 1024**2),
        "device_free_after_hot_mib": float(free_after_hot / 1024**2),
        "process_peak_rss_mib": process_peak_rss_mib(),
    }
    del output_np, output, obj
    gc.collect()
    torch.cuda.empty_cache()
    return {
        "state_upload_s": upload_s,
        "hot_apply_timing": timing,
        "output_signature": signature,
    }, memory


def run_generic_toeplitz(
    args: argparse.Namespace,
    q: dict[str, Any],
    obj_np: np.ndarray,
) -> dict[str, Any]:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device(args.device)
    centered, kernel = build_centered_kernel_complex64(args, q, int(args.n))
    centered[0, :, :] = 0
    centered[:, 0, :] = 0
    centered[:, :, 0] = 0
    symbol, gpu_setup = gpu_symbol_from_centered(torch, centered, device)
    del centered
    gc.collect()
    hot, memory = torch_hot_apply(args, symbol, obj_np)
    memory["device_free_before_backend_mib"] = float(
        gpu_setup["free_before_mib"]
    )
    memory["resident_delta_after_hot_mib"] = float(
        max(
            0.0,
            gpu_setup["free_before_mib"]
            - memory["device_free_after_hot_mib"],
        )
    )
    method_setup_s = float(
        kernel["type1_plan_setup_s"]
        + kernel["type1_execute_s"]
        + gpu_setup["gpu_setup_s"]
    )
    result = {
        "implementation": "FINUFFT CPU type-1 kernel build plus cached torch 2N FFT symbol",
        "method_setup_s": method_setup_s,
        "first_ready_s": float(method_setup_s + hot["state_upload_s"]),
        "kernel_build": kernel,
        "gpu_symbol_setup": gpu_setup,
        **hot,
        "memory": memory,
    }
    del symbol
    gc.collect()
    torch.cuda.empty_cache()
    return result


def run_acfo_toeplitz(
    args: argparse.Namespace,
    q: dict[str, Any],
    obj_np: np.ndarray,
) -> dict[str, Any]:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device(args.device)
    detector = analytic_detector_geometry(args)
    centered, kernel = build_acfo_centered_complex64(args, detector, int(args.n))
    symbol, gpu_setup = gpu_symbol_from_centered(torch, centered, device)
    del centered
    gc.collect()
    hot, memory = torch_hot_apply(args, symbol, obj_np)
    memory["device_free_before_backend_mib"] = float(
        gpu_setup["free_before_mib"]
    )
    memory["resident_delta_after_hot_mib"] = float(
        max(
            0.0,
            gpu_setup["free_before_mib"]
            - memory["device_free_after_hot_mib"],
        )
    )
    method_setup_s = float(
        detector["setup_s"] + kernel["cpu_kernel_build_s"] + gpu_setup["gpu_setup_s"]
    )
    result = {
        "implementation": "ACFO-derived detector x illumination kernel compiler plus cached torch 2N FFT symbol",
        "method_setup_s": method_setup_s,
        "first_ready_s": float(method_setup_s + hot["state_upload_s"]),
        "analytic_geometry_setup_s": float(detector["setup_s"]),
        "kernel_build": kernel,
        "gpu_symbol_setup": gpu_setup,
        **hot,
        "memory": memory,
    }
    del symbol
    gc.collect()
    torch.cuda.empty_cache()
    return result


def run_cufinufft_normal(
    args: argparse.Namespace,
    q: dict[str, Any],
    obj_np: np.ndarray,
) -> dict[str, Any]:
    cp, cufinufft = import_cufinufft_modules()
    try:
        cp.get_default_memory_pool().free_all_blocks()
        cp.get_default_pinned_memory_pool().free_all_blocks()
    except Exception:
        pass
    synchronize_cupy(cp)
    free_before, total = cp.cuda.runtime.memGetInfo()
    rss_before = process_rss_mib()
    spacing = cartesian_spacing(args, int(args.n))
    (qx, qy, qz, coordinate_max), coordinate_s = timed(
        lambda: scaled_finufft_coordinates(
            q, spacing, real_dtype=np.dtype(np.float32)
        )
    )
    setup_start = time.perf_counter()
    qx_gpu = cp.asarray(qx)
    qy_gpu = cp.asarray(qy)
    qz_gpu = cp.asarray(qz)
    del qx, qy, qz
    forward_plan = cufinufft.Plan(
        2,
        (int(args.n),) * 3,
        eps=float(args.cufinufft_eps),
        isign=-1,
        dtype="complex64",
        modeord=0,
    )
    forward_plan.setpts(qx_gpu, qy_gpu, qz_gpu)
    adjoint_plan = cufinufft.Plan(
        1,
        (int(args.n),) * 3,
        eps=float(args.cufinufft_eps),
        isign=+1,
        dtype="complex64",
        modeord=0,
    )
    adjoint_plan.setpts(qx_gpu, qy_gpu, qz_gpu)
    obj_gpu = cp.asarray(obj_np)
    measurement = cp.empty(int(q["metadata"]["q_count"]), dtype=cp.complex64)
    normal = cp.empty((int(args.n),) * 3, dtype=cp.complex64)
    synchronize_cupy(cp)
    plan_and_state_setup_s = float(time.perf_counter() - setup_start)
    free_after_setup, _ = cp.cuda.runtime.memGetInfo()

    def apply() -> Any:
        forward_plan.execute(obj_gpu, out=measurement)
        adjoint_plan.execute(measurement, out=normal)
        return normal

    for _ in range(int(args.warmups)):
        apply()
        synchronize_cupy(cp)
    free_before_hot, _ = cp.cuda.runtime.memGetInfo()
    samples: list[float] = []
    for _ in range(int(args.repeats)):
        synchronize_cupy(cp)
        start = time.perf_counter()
        apply()
        synchronize_cupy(cp)
        samples.append(float(time.perf_counter() - start))
    free_after_hot, _ = cp.cuda.runtime.memGetInfo()
    indices = sample_indices(obj_np.size, int(args.sample_count), int(args.seed))
    output_np = cp.asnumpy(normal)
    signature = signature_from_numpy(output_np, obj_np, indices)
    pool = cp.get_default_memory_pool()
    memory = {
        "allocator": "CuPy pool plus device mem_get_info; includes cuFINUFFT plan residency in device delta",
        "cupy_pool_used_mib": float(pool.used_bytes() / 1024**2),
        "cupy_pool_total_mib": float(pool.total_bytes() / 1024**2),
        "device_total_mib": float(total / 1024**2),
        "device_free_before_backend_mib": float(free_before / 1024**2),
        "device_free_after_setup_mib": float(free_after_setup / 1024**2),
        "device_free_before_hot_mib": float(free_before_hot / 1024**2),
        "device_free_after_hot_mib": float(free_after_hot / 1024**2),
        "resident_delta_after_setup_mib": float(
            max(0, free_before - free_after_setup) / 1024**2
        ),
        "resident_delta_after_hot_mib": float(
            max(0, free_before - free_after_hot) / 1024**2
        ),
        "process_rss_before_mib": rss_before,
        "process_peak_rss_mib": process_peak_rss_mib(),
    }
    return {
        "implementation": "cuFINUFFT reusable type-2 forward plus type-1 adjoint plans",
        "method_setup_s": float(coordinate_s + plan_and_state_setup_s),
        "first_ready_s": float(coordinate_s + plan_and_state_setup_s),
        "coordinate_scaling_s": coordinate_s,
        "plan_q_state_setup_s": plan_and_state_setup_s,
        "scaled_q_coordinate_max_abs": coordinate_max,
        "hot_apply_timing": timing_summary(samples),
        "output_signature": signature,
        "memory": memory,
        "versions": {
            "cupy": getattr(cp, "__version__", None),
            "cufinufft": getattr(cufinufft, "__version__", None),
        },
    }


def run_cufinufft_toeplitz(
    args: argparse.Namespace,
    q: dict[str, Any],
    obj_np: np.ndarray,
) -> dict[str, Any]:
    """Build and apply the generic Toeplitz symbol entirely on CUDA."""

    cp, cufinufft = import_cufinufft_modules()
    try:
        cp.get_default_memory_pool().free_all_blocks()
        cp.get_default_pinned_memory_pool().free_all_blocks()
    except Exception:
        pass
    synchronize_cupy(cp)
    free_before, total = cp.cuda.runtime.memGetInfo()
    rss_before = process_rss_mib()
    spacing = cartesian_spacing(args, int(args.n))
    (qx, qy, qz, coordinate_max), coordinate_s = timed(
        lambda: scaled_finufft_coordinates(
            q, spacing, real_dtype=np.dtype(np.float32)
        )
    )
    checkpoints = [int(free_before)]
    setup_start = time.perf_counter()
    qx_gpu = cp.asarray(qx)
    qy_gpu = cp.asarray(qy)
    qz_gpu = cp.asarray(qz)
    strengths = cp.ones(int(q["metadata"]["q_count"]), dtype=cp.complex64)
    del qx, qy, qz
    plan = cufinufft.Plan(
        1,
        (2 * int(args.n),) * 3,
        eps=float(args.cufinufft_eps),
        isign=+1,
        dtype="complex64",
        modeord=0,
    )
    plan.setpts(qx_gpu, qy_gpu, qz_gpu)
    synchronize_cupy(cp)
    checkpoints.append(int(cp.cuda.runtime.memGetInfo()[0]))
    centered = plan.execute(strengths)
    synchronize_cupy(cp)
    checkpoints.append(int(cp.cuda.runtime.memGetInfo()[0]))
    centered[0, :, :] = 0
    centered[:, 0, :] = 0
    centered[:, :, 0] = 0
    del plan, strengths, qx_gpu, qy_gpu, qz_gpu
    gc.collect()
    try:
        cp.get_default_memory_pool().free_all_blocks()
    except Exception:
        pass
    synchronize_cupy(cp)
    checkpoints.append(int(cp.cuda.runtime.memGetInfo()[0]))
    embedded = cp.fft.ifftshift(centered)
    del centered
    synchronize_cupy(cp)
    checkpoints.append(int(cp.cuda.runtime.memGetInfo()[0]))
    symbol = cp.fft.fftn(embedded)
    del embedded
    synchronize_cupy(cp)
    checkpoints.append(int(cp.cuda.runtime.memGetInfo()[0]))
    symbol_setup_s = float(time.perf_counter() - setup_start)
    try:
        cp.get_default_memory_pool().free_all_blocks()
    except Exception:
        pass

    obj_gpu = cp.asarray(obj_np)

    def apply() -> Any:
        padded = cp.zeros(symbol.shape, dtype=cp.complex64)
        padded[: args.n, : args.n, : args.n] = obj_gpu
        spectrum = cp.fft.fftn(padded)
        spectrum *= symbol
        del padded
        convolved = cp.fft.ifftn(spectrum)
        output = convolved[: args.n, : args.n, : args.n].copy()
        del spectrum, convolved
        return output

    for _ in range(int(args.warmups)):
        output = apply()
        synchronize_cupy(cp)
        del output
    free_before_hot, _ = cp.cuda.runtime.memGetInfo()
    pool = cp.get_default_memory_pool()
    baseline_pool_used = int(pool.used_bytes())
    baseline_pool_total = int(pool.total_bytes())
    samples: list[float] = []
    output = None
    for _ in range(int(args.repeats)):
        synchronize_cupy(cp)
        start = time.perf_counter()
        output = apply()
        synchronize_cupy(cp)
        samples.append(float(time.perf_counter() - start))
    if output is None:
        raise RuntimeError("no timed output")
    free_after_hot, _ = cp.cuda.runtime.memGetInfo()
    checkpoints.append(int(free_after_hot))
    indices = sample_indices(obj_np.size, int(args.sample_count), int(args.seed))
    output_np = cp.asnumpy(output)
    signature = signature_from_numpy(output_np, obj_np, indices)
    pool_used_after = int(pool.used_bytes())
    pool_total_after = int(pool.total_bytes())
    memory = {
        "allocator": "CuPy pool plus device mem_get_info",
        "device_total_mib": float(total / 1024**2),
        "device_free_before_backend_mib": float(free_before / 1024**2),
        "device_free_before_hot_mib": float(free_before_hot / 1024**2),
        "device_free_after_hot_mib": float(free_after_hot / 1024**2),
        "resident_delta_after_hot_mib": float(
            max(0, free_before - free_after_hot) / 1024**2
        ),
        "setup_observed_peak_resident_delta_mib": float(
            max(0, free_before - min(checkpoints)) / 1024**2
        ),
        "object_plus_cached_symbol_pool_used_mib": float(
            baseline_pool_used / 1024**2
        ),
        "object_plus_cached_symbol_pool_total_mib": float(
            baseline_pool_total / 1024**2
        ),
        "hot_pool_used_mib": float(pool_used_after / 1024**2),
        "hot_pool_total_mib": float(pool_total_after / 1024**2),
        "process_rss_before_mib": rss_before,
        "process_peak_rss_mib": process_peak_rss_mib(),
    }
    return {
        "implementation": "cuFINUFFT GPU type-1 kernel build plus cached CuPy 2N FFT symbol",
        "method_setup_s": float(coordinate_s + symbol_setup_s),
        "first_ready_s": float(coordinate_s + symbol_setup_s),
        "coordinate_scaling_s": coordinate_s,
        "gpu_kernel_and_symbol_setup_s": symbol_setup_s,
        "scaled_q_coordinate_max_abs": coordinate_max,
        "hot_apply_timing": timing_summary(samples),
        "output_signature": signature,
        "memory": memory,
        "versions": {
            "cupy": getattr(cp, "__version__", None),
            "cufinufft": getattr(cufinufft, "__version__", None),
        },
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    if args.n <= 0 or args.warmups < 0 or args.repeats <= 0:
        raise ValueError("n/repeats must be positive and warmups non-negative")
    if args.backend not in {
        "cufinufft-normal",
        "cufinufft-toeplitz",
        "generic-toeplitz",
        "acfo-toeplitz",
    }:
        raise ValueError(f"unknown backend {args.backend!r}")
    q, geometry_build_s = timed(lambda: production_q_geometry(args))
    receipt = base_receipt(args, q, geometry_build_s)
    obj_np = deterministic_object(int(args.n), int(args.seed))
    if args.backend == "cufinufft-normal":
        backend = run_cufinufft_normal(args, q, obj_np)
    elif args.backend == "cufinufft-toeplitz":
        backend = run_cufinufft_toeplitz(args, q, obj_np)
    elif args.backend == "generic-toeplitz":
        backend = run_generic_toeplitz(args, q, obj_np)
    else:
        backend = run_acfo_toeplitz(args, q, obj_np)
    signature = backend["output_signature"]
    gates = {
        "finite_timing": bool(
            math.isfinite(float(backend["method_setup_s"]))
            and float(backend["method_setup_s"]) >= 0.0
            and math.isfinite(float(backend["hot_apply_timing"]["median_s"]))
            and float(backend["hot_apply_timing"]["median_s"]) > 0.0
        ),
        "finite_signature": bool(
            math.isfinite(float(signature["output_norm"]))
            and float(signature["output_norm"]) > 0.0
        ),
        "rayleigh_psd_probe": bool(
            signature["rayleigh_nonnegative"]
            and signature["rayleigh_imag_over_abs"]
            <= float(args.rayleigh_imag_tolerance)
        ),
    }
    receipt.update(
        {
            "passed": bool(all(gates.values())),
            "backend_result": backend,
            "gates": gates,
            "environment": {
                "python": platform.python_version(),
                "numpy": np.__version__,
                "platform": platform.platform(),
                "pid": os.getpid(),
            },
        }
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return receipt


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--backend",
        required=True,
        choices=[
            "cufinufft-normal",
            "cufinufft-toeplitz",
            "generic-toeplitz",
            "acfo-toeplitz",
        ],
    )
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--n", type=int, default=256)
    p.add_argument("--seed", type=int, default=20260806)
    p.add_argument("--device", default="cuda")
    p.add_argument("--warmups", type=int, default=3)
    p.add_argument("--repeats", type=int, default=20)
    p.add_argument("--sample-count", type=int, default=1024)
    p.add_argument("--cufinufft-eps", type=float, default=1e-5)
    p.add_argument("--generic-finufft-eps", type=float, default=1e-5)
    p.add_argument("--gpu-finufft-eps", type=float, default=1e-5)
    p.add_argument("--finufft-threads", type=int, default=4)
    p.add_argument("--gather-chunk-x", type=int, default=8)
    p.add_argument("--rayleigh-imag-tolerance", type=float, default=2e-5)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return p


def main() -> None:
    args = parser().parse_args()
    result = run(args)
    backend = result["backend_result"]
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "backend": result["backend"],
                "n": result["configuration"]["n"],
                "q_count": result["geometry"]["q_count"],
                "setup_s": backend["method_setup_s"],
                "hot_median_ms": 1000.0
                * backend["hot_apply_timing"]["median_s"],
                "output": str(args.output),
            },
            indent=2,
        )
    )
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
