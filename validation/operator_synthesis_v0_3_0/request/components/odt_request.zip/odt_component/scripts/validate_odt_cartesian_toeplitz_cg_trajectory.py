#!/usr/bin/env python3
"""Compare FINUFFT and cached-Toeplitz Cartesian ODT CG trajectories.

The experiment uses the complete production ``banded_inner96_outer64``
ring-plus-axis q set and unit data weights.  A smooth synthetic truth on a
uniform Cartesian lattice generates noiseless complex data with a FINUFFT
type-2 transform.  One common RHS is formed with the matching type-1 adjoint.

Two independent complex-CG solves then use

    (A* A / M + lambda I) x = A* y / M

with either a direct FINUFFT type-2/type-1 normal or the exact finite-grid
signed-difference Toeplitz normal.  The common Tikhonov term makes the
missing-cone system positive definite and keeps this experiment focused on
backend equivalence rather than identifiability.  Every iterate, recurrence
residual, common-system residual, object error, alpha, and beta is compared.

This is a small complex128 mathematical gate.  It does not use CUDA and does
not modify the production cylindrical solver.
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import fft as scipy_fft


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_cartesian_toeplitz_exact_gate import (  # noqa: E402
    cartesian_spacing,
    centered_modes_to_embedded_kernel,
    create_finufft_plan,
    production_q_geometry,
    random_complex,
    relative_l2,
    scaled_finufft_coordinates,
)


def scalar_relative_error(candidate: float, reference: float) -> float:
    denominator = max(abs(reference), np.finfo(np.float64).tiny)
    return float(abs(candidate - reference) / denominator)


def complex_scalar_relative_error(candidate: complex, reference: complex) -> float:
    denominator = max(abs(reference), np.finfo(np.float64).tiny)
    return float(abs(candidate - reference) / denominator)


def timing_summary(values: list[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    return {
        "count": int(array.size),
        "total_s": float(array.sum()),
        "median_s": float(np.median(array)),
        "mean_s": float(array.mean()),
        "min_s": float(array.min()),
        "max_s": float(array.max()),
        "samples_s": array.tolist(),
    }


def smooth_cartesian_truth(
    shape: tuple[int, int, int],
    spacing: tuple[float, float, float],
) -> np.ndarray:
    axes = [
        (np.arange(n, dtype=np.float64) - n // 2) * step
        for n, step in zip(shape, spacing, strict=True)
    ]
    xx, yy, zz = np.meshgrid(*axes, indexing="ij")
    beads = (
        (-0.34, 0.19, -0.25, 0.16, 1.00 + 0.15j),
        (0.29, -0.31, 0.20, 0.13, 0.72 - 0.24j),
        (0.10, 0.38, 0.39, 0.11, 0.48 + 0.33j),
        (-0.08, -0.07, -0.03, 0.24, 0.31 + 0.06j),
    )
    truth = np.zeros(shape, dtype=np.complex128)
    for cx, cy, cz, sigma, amplitude in beads:
        distance2 = (xx - cx) ** 2 + (yy - cy) ** 2 + (zz - cz) ** 2
        truth += amplitude * np.exp(-0.5 * distance2 / sigma**2)
    # A smooth compact taper avoids making the trajectory comparison hinge on
    # high-frequency boundary discontinuities.
    lateral_radius = np.sqrt(xx**2 + yy**2)
    taper_r = np.clip((0.95 - lateral_radius) / 0.10, 0.0, 1.0)
    taper_z = np.clip((0.76 - np.abs(zz)) / 0.08, 0.0, 1.0)
    truth *= taper_r * taper_z
    norm = float(np.linalg.norm(truth.ravel()))
    if norm == 0.0:
        raise RuntimeError("synthetic Cartesian truth is zero")
    truth /= norm
    return np.ascontiguousarray(truth)


def apply_toeplitz(
    values: np.ndarray,
    symbol: np.ndarray,
    n: int,
    workers: int,
) -> np.ndarray:
    padded = np.zeros(symbol.shape, dtype=np.complex128)
    padded[:n, :n, :n] = values
    spectrum = scipy_fft.fftn(padded, workers=workers)
    convolved = scipy_fft.ifftn(spectrum * symbol, workers=workers)
    return np.ascontiguousarray(convolved[:n, :n, :n])


def run_complex_cg(
    *,
    apply: Callable[[np.ndarray], np.ndarray],
    rhs: np.ndarray,
    truth: np.ndarray,
    iterations: int,
    label: str,
) -> dict[str, Any]:
    x = np.zeros_like(rhs)
    residual = rhs.copy()
    direction = residual.copy()
    residual_norm2 = float(np.vdot(residual, residual).real)
    rhs_norm = max(float(np.linalg.norm(rhs.ravel())), np.finfo(float).tiny)
    states: list[dict[str, Any]] = [
        {
            "iteration": 0,
            "x": x.copy(),
            "residual": residual.copy(),
            "relative_residual": float(math.sqrt(residual_norm2) / rhs_norm),
            "object_relative_l2": relative_l2(x, truth),
            "alpha": None,
            "beta": None,
            "denominator_imag_over_abs": None,
        }
    ]
    apply_times: list[float] = []
    start_total = time.perf_counter()
    for iteration in range(1, iterations + 1):
        start = time.perf_counter()
        applied = apply(direction)
        apply_times.append(float(time.perf_counter() - start))
        denominator = np.vdot(direction, applied)
        denominator_imag = float(
            abs(denominator.imag)
            / max(abs(denominator), np.finfo(float).tiny)
        )
        denominator_real = float(denominator.real)
        if not np.isfinite(denominator_real) or denominator_real <= 0.0:
            raise RuntimeError(
                f"{label} CG lost positive definiteness at iteration {iteration}: "
                f"p*Ap={denominator}"
            )
        alpha = float(residual_norm2 / denominator_real)
        x = x + alpha * direction
        residual = residual - alpha * applied
        next_norm2 = float(np.vdot(residual, residual).real)
        beta = float(next_norm2 / max(residual_norm2, np.finfo(float).tiny))
        direction = residual + beta * direction
        residual_norm2 = next_norm2
        states.append(
            {
                "iteration": iteration,
                "x": x.copy(),
                "residual": residual.copy(),
                "relative_residual": float(math.sqrt(residual_norm2) / rhs_norm),
                "object_relative_l2": relative_l2(x, truth),
                "alpha": alpha,
                "beta": beta,
                "denominator_imag_over_abs": denominator_imag,
            }
        )
    return {
        "label": label,
        "states": states,
        "apply_timing": timing_summary(apply_times),
        "total_s": float(time.perf_counter() - start_total),
    }


def trajectory_relative_l2(
    candidate_states: list[dict[str, Any]],
    reference_states: list[dict[str, Any]],
) -> float:
    numerator = 0.0
    denominator = 0.0
    for candidate, reference in zip(
        candidate_states[1:], reference_states[1:], strict=True
    ):
        difference = candidate["x"] - reference["x"]
        numerator += float(np.vdot(difference, difference).real)
        denominator += float(np.vdot(reference["x"], reference["x"]).real)
    return float(
        math.sqrt(numerator / max(denominator, np.finfo(float).tiny))
    )


def render_markdown(result: dict[str, Any]) -> str:
    configuration = result["configuration"]
    summary = result["trajectory_summary"]
    lines = [
        "# ODT Cartesian Toeplitz CG trajectory gate",
        "",
        f"- 판정: **{'PASS' if result['passed'] else 'FAIL'}**",
        f"- geometry: production `banded_inner96_outer64`, q `{result['geometry']['q_count']:,}`개, `W=I`",
        f"- Cartesian grid: `{configuration['shape']}`, complex128",
        f"- solver: independent complex-CG `{configuration['iterations']}` iterations",
        f"- common system: `A* A / M + {configuration['tikhonov_relative']:.3e} I`",
        "",
        "## 요약",
        "",
        f"- Toeplitz RHS vs direct RHS rel-L2: `{summary['toeplitz_rhs_vs_direct_rhs_relative_l2']:.3e}`",
        f"- random-probe normal rel-L2: `{summary['toeplitz_vs_direct_normal_probe_relative_l2']:.3e}`",
        f"- stacked solver-trajectory rel-L2: `{summary['stacked_iterate_trajectory_relative_l2']:.3e}`",
        f"- maximum per-iteration iterate rel-L2: `{summary['maximum_iterate_relative_l2']:.3e}`",
        f"- maximum residual-norm / object-error scalar disagreement: `{summary['maximum_relative_residual_scalar_error']:.3e}` / `{summary['maximum_object_error_scalar_relative_error']:.3e}`",
        f"- final solution rel-L2: `{summary['final_solution_relative_l2']:.3e}`",
        f"- maximum alpha / beta relative error: `{summary['maximum_alpha_relative_error']:.3e}` / `{summary['maximum_beta_relative_error']:.3e}`",
        f"- final common-direct residual-vector rel-L2: `{summary['final_common_direct_residual_vector_relative_l2']:.3e}`",
        f"- final predicted-data rel-L2: `{summary['final_predicted_data_relative_l2']:.3e}`",
        "",
        "## Iteration trajectory",
        "",
        "| iter | direct residual | Toeplitz residual | direct object err | Toeplitz object err | iterate rel-L2 | residual-vector rel-L2 | alpha rel | beta rel |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in result["iterations"]:
        alpha = "n/a" if row["alpha_relative_error"] is None else f"{row['alpha_relative_error']:.3e}"
        beta = "n/a" if row["beta_relative_error"] is None else f"{row['beta_relative_error']:.3e}"
        lines.append(
            f"| {row['iteration']} | {row['direct_relative_residual']:.3e} | "
            f"{row['toeplitz_relative_residual']:.3e} | "
            f"{row['direct_object_relative_l2']:.3e} | "
            f"{row['toeplitz_object_relative_l2']:.3e} | "
            f"{row['iterate_relative_l2']:.3e} | "
            f"{row['recurrence_residual_vector_relative_l2']:.3e} | "
            f"{alpha} | {beta} |"
        )
    lines.extend(
        [
            "",
            "## 해석 경계",
            "",
            "두 solver는 FINUFFT로 한 번 만든 완전히 동일한 RHS에서 시작한다. Toeplitz solver는 data를 다시 만들지 않으며 cached finite-grid symbol만 사용한다. Tikhonov 항은 두 backend에 동일하게 더했다.",
            "",
            "이 실험은 uniform Cartesian state 내부의 solver trajectory 동등성을 검증한다. 현재 production unknown인 half-cell cylindrical coefficient와는 discretization, quadrature weight, boundary가 다르며 원래 cylindrical solver를 변경하지 않는다. Noiseless small-grid complex128 수치 gate이므로 physical missing-cone recovery나 full-scale reconstruction latency 주장이 아니다.",
        ]
    )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> dict[str, Any]:
    import finufft

    if args.n <= 0 or args.iterations <= 0:
        raise ValueError("n and iterations must be positive")
    if args.tikhonov_relative <= 0.0:
        raise ValueError("tikhonov-relative must be positive")

    q = production_q_geometry(args)
    n = int(args.n)
    shape = (n, n, n)
    spacing = cartesian_spacing(args, n)
    qx, qy, qz, coordinate_max = scaled_finufft_coordinates(
        q, spacing, real_dtype=np.dtype(np.float64)
    )
    coordinates = (qx, qy, qz)
    q_count = int(q["metadata"]["q_count"])
    normal_scale = 1.0 / float(q_count)

    type2, type2_setup_s = create_finufft_plan(
        finufft,
        2,
        shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=-1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    type1, type1_setup_s = create_finufft_plan(
        finufft,
        1,
        shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )

    truth = smooth_cartesian_truth(shape, spacing)
    start = time.perf_counter()
    data = type2.execute(truth)
    data_build_s = float(time.perf_counter() - start)
    start = time.perf_counter()
    rhs = np.ascontiguousarray(type1.execute(data) * normal_scale)
    rhs_build_s = float(time.perf_counter() - start)

    padded_shape = (2 * n, 2 * n, 2 * n)
    kernel_plan, kernel_plan_setup_s = create_finufft_plan(
        finufft,
        1,
        padded_shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    strengths = np.full(q_count, normal_scale, dtype=np.complex128)
    start = time.perf_counter()
    centered_kernel = kernel_plan.execute(strengths)
    kernel_execute_s = float(time.perf_counter() - start)
    del kernel_plan, strengths
    embedded_kernel = centered_modes_to_embedded_kernel(centered_kernel, n)
    del centered_kernel
    start = time.perf_counter()
    symbol = scipy_fft.fftn(embedded_kernel, workers=int(args.fft_workers))
    symbol_fft_s = float(time.perf_counter() - start)

    tikhonov = float(args.tikhonov_relative)
    direct_apply_times: list[float] = []
    toeplitz_apply_times: list[float] = []

    def direct_unregularized(values: np.ndarray) -> np.ndarray:
        return np.ascontiguousarray(type1.execute(type2.execute(values)) * normal_scale)

    def direct_system(values: np.ndarray) -> np.ndarray:
        start_local = time.perf_counter()
        output = direct_unregularized(values) + tikhonov * values
        direct_apply_times.append(float(time.perf_counter() - start_local))
        return output

    def toeplitz_unregularized(values: np.ndarray) -> np.ndarray:
        return apply_toeplitz(values, symbol, n, int(args.fft_workers))

    def toeplitz_system(values: np.ndarray) -> np.ndarray:
        start_local = time.perf_counter()
        output = toeplitz_unregularized(values) + tikhonov * values
        toeplitz_apply_times.append(float(time.perf_counter() - start_local))
        return output

    toeplitz_rhs = toeplitz_unregularized(truth)
    rng = np.random.default_rng(int(args.seed) + 991)
    probe = random_complex(rng, shape, np.dtype(np.complex128))
    direct_probe = direct_unregularized(probe)
    toeplitz_probe = toeplitz_unregularized(probe)

    direct_cg = run_complex_cg(
        apply=direct_system,
        rhs=rhs,
        truth=truth,
        iterations=int(args.iterations),
        label="FINUFFT-direct",
    )
    toeplitz_cg = run_complex_cg(
        apply=toeplitz_system,
        rhs=rhs,
        truth=truth,
        iterations=int(args.iterations),
        label="cached-Toeplitz",
    )

    direct_states = direct_cg["states"]
    toeplitz_states = toeplitz_cg["states"]
    iteration_rows: list[dict[str, Any]] = []
    for direct_state, toeplitz_state in zip(
        direct_states, toeplitz_states, strict=True
    ):
        common_direct_residual = rhs - toeplitz_system(direct_state["x"])
        common_toeplitz_residual = rhs - toeplitz_system(toeplitz_state["x"])
        alpha_direct = direct_state["alpha"]
        alpha_toeplitz = toeplitz_state["alpha"]
        beta_direct = direct_state["beta"]
        beta_toeplitz = toeplitz_state["beta"]
        iteration_rows.append(
            {
                "iteration": int(direct_state["iteration"]),
                "direct_relative_residual": float(
                    direct_state["relative_residual"]
                ),
                "toeplitz_relative_residual": float(
                    toeplitz_state["relative_residual"]
                ),
                "relative_residual_scalar_error": scalar_relative_error(
                    float(toeplitz_state["relative_residual"]),
                    float(direct_state["relative_residual"]),
                ),
                "direct_object_relative_l2": float(
                    direct_state["object_relative_l2"]
                ),
                "toeplitz_object_relative_l2": float(
                    toeplitz_state["object_relative_l2"]
                ),
                "object_error_scalar_relative_error": scalar_relative_error(
                    float(toeplitz_state["object_relative_l2"]),
                    float(direct_state["object_relative_l2"]),
                ),
                "iterate_relative_l2": relative_l2(
                    toeplitz_state["x"], direct_state["x"]
                ),
                "recurrence_residual_vector_relative_l2": relative_l2(
                    toeplitz_state["residual"], direct_state["residual"]
                ),
                "common_toeplitz_system_direct_iterate_relative_residual": float(
                    np.linalg.norm(common_direct_residual.ravel())
                    / max(np.linalg.norm(rhs.ravel()), np.finfo(float).tiny)
                ),
                "common_toeplitz_system_toeplitz_iterate_relative_residual": float(
                    np.linalg.norm(common_toeplitz_residual.ravel())
                    / max(np.linalg.norm(rhs.ravel()), np.finfo(float).tiny)
                ),
                "common_toeplitz_residual_vector_relative_l2": relative_l2(
                    common_toeplitz_residual, common_direct_residual
                ),
                "alpha_direct": alpha_direct,
                "alpha_toeplitz": alpha_toeplitz,
                "alpha_relative_error": (
                    None
                    if alpha_direct is None or alpha_toeplitz is None
                    else scalar_relative_error(
                        float(alpha_toeplitz), float(alpha_direct)
                    )
                ),
                "beta_direct": beta_direct,
                "beta_toeplitz": beta_toeplitz,
                "beta_relative_error": (
                    None
                    if beta_direct is None or beta_toeplitz is None
                    else scalar_relative_error(float(beta_toeplitz), float(beta_direct))
                ),
                "direct_denominator_imag_over_abs": direct_state[
                    "denominator_imag_over_abs"
                ],
                "toeplitz_denominator_imag_over_abs": toeplitz_state[
                    "denominator_imag_over_abs"
                ],
            }
        )

    final_direct = direct_states[-1]["x"]
    final_toeplitz = toeplitz_states[-1]["x"]
    final_direct_residual_on_direct = rhs - direct_system(final_direct)
    final_toeplitz_residual_on_direct = rhs - direct_system(final_toeplitz)
    final_direct_data = type2.execute(final_direct)
    final_toeplitz_data = type2.execute(final_toeplitz)
    final_direct_data_residual = relative_l2(final_direct_data, data)
    final_toeplitz_data_residual = relative_l2(final_toeplitz_data, data)

    noninitial_rows = iteration_rows[1:]
    alpha_errors = [
        float(row["alpha_relative_error"])
        for row in noninitial_rows
        if row["alpha_relative_error"] is not None
    ]
    beta_errors = [
        float(row["beta_relative_error"])
        for row in noninitial_rows
        if row["beta_relative_error"] is not None
    ]
    trajectory_summary = {
        "toeplitz_rhs_vs_direct_rhs_relative_l2": relative_l2(
            toeplitz_rhs, rhs
        ),
        "toeplitz_vs_direct_normal_probe_relative_l2": relative_l2(
            toeplitz_probe, direct_probe
        ),
        "stacked_iterate_trajectory_relative_l2": trajectory_relative_l2(
            toeplitz_states, direct_states
        ),
        "maximum_iterate_relative_l2": max(
            float(row["iterate_relative_l2"]) for row in noninitial_rows
        ),
        "maximum_recurrence_residual_vector_relative_l2": max(
            float(row["recurrence_residual_vector_relative_l2"])
            for row in noninitial_rows
        ),
        "maximum_common_toeplitz_residual_vector_relative_l2": max(
            float(row["common_toeplitz_residual_vector_relative_l2"])
            for row in noninitial_rows
        ),
        "maximum_relative_residual_scalar_error": max(
            float(row["relative_residual_scalar_error"])
            for row in noninitial_rows
        ),
        "maximum_object_error_scalar_relative_error": max(
            float(row["object_error_scalar_relative_error"])
            for row in noninitial_rows
        ),
        "maximum_alpha_relative_error": max(alpha_errors),
        "maximum_beta_relative_error": max(beta_errors),
        "final_solution_relative_l2": relative_l2(
            final_toeplitz, final_direct
        ),
        "final_object_error_direct": relative_l2(final_direct, truth),
        "final_object_error_toeplitz": relative_l2(final_toeplitz, truth),
        "final_common_direct_residual_vector_relative_l2": relative_l2(
            final_toeplitz_residual_on_direct,
            final_direct_residual_on_direct,
        ),
        "final_direct_system_relative_residual_direct_iterate": float(
            np.linalg.norm(final_direct_residual_on_direct.ravel())
            / max(np.linalg.norm(rhs.ravel()), np.finfo(float).tiny)
        ),
        "final_direct_system_relative_residual_toeplitz_iterate": float(
            np.linalg.norm(final_toeplitz_residual_on_direct.ravel())
            / max(np.linalg.norm(rhs.ravel()), np.finfo(float).tiny)
        ),
        "final_predicted_data_relative_l2": relative_l2(
            final_toeplitz_data, final_direct_data
        ),
        "final_data_residual_direct": final_direct_data_residual,
        "final_data_residual_toeplitz": final_toeplitz_data_residual,
        "final_data_residual_scalar_relative_error": scalar_relative_error(
            final_toeplitz_data_residual, final_direct_data_residual
        ),
    }
    gates = {
        "rhs": bool(
            trajectory_summary["toeplitz_rhs_vs_direct_rhs_relative_l2"]
            <= float(args.operator_tolerance)
        ),
        "normal_probe": bool(
            trajectory_summary["toeplitz_vs_direct_normal_probe_relative_l2"]
            <= float(args.operator_tolerance)
        ),
        "trajectory": bool(
            trajectory_summary["stacked_iterate_trajectory_relative_l2"]
            <= float(args.trajectory_tolerance)
            and trajectory_summary["maximum_iterate_relative_l2"]
            <= float(args.trajectory_tolerance)
        ),
        "steps": bool(
            trajectory_summary["maximum_alpha_relative_error"]
            <= float(args.step_tolerance)
            and trajectory_summary["maximum_beta_relative_error"]
            <= float(args.step_tolerance)
        ),
        "residual_trajectory": bool(
            trajectory_summary[
                "maximum_recurrence_residual_vector_relative_l2"
            ]
            <= float(args.residual_vector_tolerance)
            and trajectory_summary[
                "maximum_common_toeplitz_residual_vector_relative_l2"
            ]
            <= float(args.residual_vector_tolerance)
            and trajectory_summary[
                "maximum_relative_residual_scalar_error"
            ]
            <= float(args.step_tolerance)
        ),
        "object_error_trajectory": bool(
            trajectory_summary["maximum_object_error_scalar_relative_error"]
            <= float(args.step_tolerance)
        ),
        "final_solution": bool(
            trajectory_summary["final_solution_relative_l2"]
            <= float(args.trajectory_tolerance)
        ),
        "final_data": bool(
            trajectory_summary["final_predicted_data_relative_l2"]
            <= float(args.trajectory_tolerance)
        ),
    }

    result = {
        "schema": "odt-cartesian-toeplitz-cg-trajectory-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": bool(all(gates.values())),
        "geometry": q["metadata"],
        "configuration": {
            "shape": list(shape),
            "padded_shape": list(padded_shape),
            "spacing_um": list(spacing),
            "scaled_q_coordinate_max_abs": coordinate_max,
            "dtype": "complex128",
            "data_weights": "W=I",
            "normal_scaling": f"1/M with M={q_count}; scalar scaling only",
            "tikhonov_relative": tikhonov,
            "iterations": int(args.iterations),
            "finufft_eps": float(args.finufft_eps),
            "seed": int(args.seed),
            "noise": "none",
            "initialization": "zero",
            "rhs": "one shared FINUFFT type-1 adjoint of the synthetic type-2 data",
        },
        "trajectory_summary": trajectory_summary,
        "iterations": iteration_rows,
        "gates": gates,
        "timing_s": {
            "type2_plan_setup": type2_setup_s,
            "type1_plan_setup": type1_setup_s,
            "data_build": data_build_s,
            "rhs_build": rhs_build_s,
            "kernel_type1_plan_setup": kernel_plan_setup_s,
            "kernel_type1_execute": kernel_execute_s,
            "symbol_fft": symbol_fft_s,
            "direct_cg_total": direct_cg["total_s"],
            "toeplitz_cg_total": toeplitz_cg["total_s"],
            "all_direct_system_applies": timing_summary(direct_apply_times),
            "all_toeplitz_system_applies": timing_summary(toeplitz_apply_times),
        },
        "scope": [
            "Uniform Cartesian complex128 state with the complete production ring+axis q set and W=I.",
            "Noiseless synthetic data and one shared RHS; independent CG scalar recurrences thereafter.",
            "The common positive Tikhonov term isolates backend trajectory equivalence from missing-cone identifiability.",
            "Not the current half-cell cylindrical coefficient state and does not modify the production solver.",
            "CPU mathematical gate only; no full-scale GPU timing claim.",
        ],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "finufft": getattr(finufft, "__version__", None),
            "platform": platform.platform(),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--n", type=int, default=32)
    p.add_argument("--iterations", type=int, default=15)
    p.add_argument("--tikhonov-relative", type=float, default=1e-3)
    p.add_argument("--seed", type=int, default=20260805)
    p.add_argument("--finufft-eps", type=float, default=1e-12)
    p.add_argument("--finufft-threads", type=int, default=0)
    p.add_argument("--fft-workers", type=int, default=-1)
    p.add_argument("--operator-tolerance", type=float, default=1e-10)
    p.add_argument("--trajectory-tolerance", type=float, default=1e-8)
    p.add_argument("--step-tolerance", type=float, default=1e-7)
    p.add_argument("--residual-vector-tolerance", type=float, default=2e-5)
    p.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "benchmark_results"
        / "odt_cartesian_toeplitz_cg_trajectory_20260805.json",
    )
    p.add_argument(
        "--summary",
        type=Path,
        default=ROOT
        / "benchmark_results"
        / "odt_cartesian_toeplitz_cg_trajectory_20260805_ko.md",
    )
    return p


def main() -> None:
    args = parser().parse_args()
    result = run(args)
    summary = result["trajectory_summary"]
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "q_count": result["geometry"]["q_count"],
                "shape": result["configuration"]["shape"],
                "iterations": result["configuration"]["iterations"],
                "operator_rel_l2": summary[
                    "toeplitz_vs_direct_normal_probe_relative_l2"
                ],
                "trajectory_rel_l2": summary[
                    "stacked_iterate_trajectory_relative_l2"
                ],
                "final_solution_rel_l2": summary["final_solution_relative_l2"],
                "output": str(args.output),
                "summary": str(args.summary),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
