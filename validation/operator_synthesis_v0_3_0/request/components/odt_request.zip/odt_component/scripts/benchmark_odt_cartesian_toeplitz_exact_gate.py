#!/usr/bin/env python3
"""Exact Cartesian Toeplitz gate for the production banded ODT geometry.

This experiment intentionally changes the reconstruction state.  The current
production operator acts on weighted cylindrical ``(rho, beta, z)``
coefficients; this script instead places the unknown on a uniform Cartesian
lattice.  For that lattice and fixed diagonal data weights, the finite-grid
normal is block Toeplitz:

    A[q, n] = exp(-i q . r_n)
    K[d] = sum_q w_q exp(+i q . d)
    A* W A x = K *_Toeplitz x.

The reference normal is evaluated with a FINUFFT type-2/type-1 pair.  The same
physical q samples and weights are compiled into all signed differences with a
type-1 transform on a ``2N`` grid, converted to an FFT symbol, and applied by
zero-pad / FFT / multiply / inverse FFT / crop.  A same-size periodic FFT is
never used.

The small complex128 gate checks equivalence, adjointness, Hermitian symmetry,
positive semidefiniteness, and the normal-energy identity.  Optional large
complex64 CUDA cases measure physical-symbol hot application and memory; they
do not alter or call the cylindrical solver.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import fft as scipy_fft


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_banded_detector import VARIANTS  # noqa: E402
from benchmark_odt_cone_illumination import (  # noqa: E402
    cone_illumination_directions,
    cone_q_samples,
)


DEFAULT_BASELINE = (
    ROOT
    / "benchmark_results"
    / "odt_fused_modal_normal_experiment_20260805.json"
)


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    denominator = max(
        float(np.linalg.norm(reference.ravel())), np.finfo(np.float64).tiny
    )
    return float(np.linalg.norm((candidate - reference).ravel()) / denominator)


def relative_scalar_error(candidate: complex, reference: complex) -> float:
    denominator = max(abs(reference), np.finfo(np.float64).tiny)
    return float(abs(candidate - reference) / denominator)


def bilinear_relative_error(left: complex, right: complex) -> float:
    denominator = max(abs(left) + abs(right), np.finfo(np.float64).tiny)
    return float(abs(left - right) / denominator)


def timing_summary(values: list[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    return {
        "count": int(array.size),
        "median_s": float(np.median(array)),
        "mean_s": float(array.mean()),
        "p05_s": float(np.percentile(array, 5)),
        "p95_s": float(np.percentile(array, 95)),
        "min_s": float(array.min()),
        "max_s": float(array.max()),
        "samples_s": array.tolist(),
    }


def timed(callback: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = callback()
    return value, float(time.perf_counter() - start)


def random_complex(
    rng: np.random.Generator, shape: tuple[int, ...], dtype: np.dtype[Any]
) -> np.ndarray:
    real_dtype = np.float32 if dtype == np.dtype(np.complex64) else np.float64
    output = np.empty(shape, dtype=dtype)
    output.real = rng.standard_normal(shape, dtype=real_dtype)
    output.imag = rng.standard_normal(shape, dtype=real_dtype)
    output *= 1.0 / math.sqrt(2.0)
    return np.ascontiguousarray(output)


def parse_sizes(text: str) -> list[int]:
    values = [int(part.strip()) for part in text.split(",") if part.strip()]
    if any(value <= 0 for value in values):
        raise ValueError("grid sizes must be positive")
    return values


def array_sha256(arrays: list[np.ndarray]) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array, dtype="<f8")
        digest.update(memoryview(contiguous).cast("B"))
    return digest.hexdigest()


def production_q_geometry(args: argparse.Namespace) -> dict[str, Any]:
    """Generate the exact production ring+axis q samples without a full plan."""

    if args.variant != "banded_inner96_outer64":
        raise ValueError(
            "this frozen gate currently supports only banded_inner96_outer64"
        )
    ring_na = math.sin(math.radians(float(args.illumination_angle_deg)))
    ring_illumination, _ = cone_illumination_directions(
        n_illum=int(args.ring_illum), illumination_na=ring_na
    )
    axis_illumination, _ = cone_illumination_directions(
        n_illum=1, illumination_na=0.0
    )

    qx_parts: list[np.ndarray] = []
    qy_parts: list[np.ndarray] = []
    qz_parts: list[np.ndarray] = []
    blocks: list[dict[str, Any]] = []
    start = time.perf_counter()
    for specification in VARIANTS[args.variant]:
        for illumination_name, illumination in (
            ("ring", ring_illumination),
            ("axis", axis_illumination),
        ):
            flat_q, _ = cone_q_samples(
                k=float(args.k),
                detector_na=float(args.detector_na),
                cap_radial=int(specification["cap_radial"]),
                cap_phi=int(specification["cap_phi"]),
                illumination=illumination,
                radial_sampling=str(specification["sampling"]),
                radial_outer_power=float(specification["outer_power"]),
                radial_min_fraction=float(specification["min_fraction"]),
                radial_max_fraction=float(specification["max_fraction"]),
            )
            qx_parts.append(np.ascontiguousarray(flat_q.qx, dtype=np.float64))
            qy_parts.append(np.ascontiguousarray(flat_q.qy, dtype=np.float64))
            qz_parts.append(np.ascontiguousarray(flat_q.qz, dtype=np.float64))
            expected = int(
                illumination.shape[0]
                * int(specification["cap_radial"])
                * int(specification["cap_phi"])
            )
            if flat_q.count != expected:
                raise RuntimeError(
                    f"{specification['name']}/{illumination_name} q count "
                    f"{flat_q.count} != {expected}"
                )
            blocks.append(
                {
                    "band": str(specification["name"]),
                    "illumination": illumination_name,
                    "illumination_count": int(illumination.shape[0]),
                    "cap_radial": int(specification["cap_radial"]),
                    "cap_phi": int(specification["cap_phi"]),
                    "radial_min_fraction": float(specification["min_fraction"]),
                    "radial_max_fraction": float(specification["max_fraction"]),
                    "radial_sampling": str(specification["sampling"]),
                    "radial_outer_power": float(specification["outer_power"]),
                    "q_count": int(flat_q.count),
                }
            )
            del flat_q

    qx = np.ascontiguousarray(np.concatenate(qx_parts), dtype=np.float64)
    qy = np.ascontiguousarray(np.concatenate(qy_parts), dtype=np.float64)
    qz = np.ascontiguousarray(np.concatenate(qz_parts), dtype=np.float64)
    del qx_parts, qy_parts, qz_parts
    expected_total = sum(int(block["q_count"]) for block in blocks)
    if qx.size != expected_total or qy.size != expected_total or qz.size != expected_total:
        raise RuntimeError("concatenated production q count mismatch")

    return {
        "qx": qx,
        "qy": qy,
        "qz": qz,
        "metadata": {
            "variant": args.variant,
            "k_rad_per_um": float(args.k),
            "detector_na": float(args.detector_na),
            "illumination_angle_deg": float(args.illumination_angle_deg),
            "ring_illumination_na": float(ring_na),
            "ring_illumination_count": int(args.ring_illum),
            "axis_illumination_count": 1,
            "blocks": blocks,
            "q_count": int(qx.size),
            "q_sha256_qx_qy_qz_float64": array_sha256([qx, qy, qz]),
            "q_component_min": [float(qx.min()), float(qy.min()), float(qz.min())],
            "q_component_max": [float(qx.max()), float(qy.max()), float(qz.max())],
            "q_build_s": float(time.perf_counter() - start),
            "data_weights": "W=I; every production detector sample has weight 1",
        },
    }


def cartesian_spacing(args: argparse.Namespace, n: int) -> tuple[float, float, float]:
    return (
        2.0 * float(args.r_max) / float(n),
        2.0 * float(args.r_max) / float(n),
        2.0 * float(args.z_max) / float(n),
    )


def scaled_finufft_coordinates(
    q: dict[str, Any],
    spacing: tuple[float, float, float],
    *,
    real_dtype: np.dtype[Any],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    coordinates = tuple(
        np.ascontiguousarray(q[key] * step, dtype=real_dtype)
        for key, step in zip(("qx", "qy", "qz"), spacing, strict=True)
    )
    maximum = max(float(np.max(np.abs(value))) for value in coordinates)
    if maximum >= np.pi:
        raise ValueError(
            f"scaled FINUFFT coordinate {maximum:.6g} reaches pi; "
            "the proposed Cartesian spacing aliases the production q support"
        )
    return coordinates[0], coordinates[1], coordinates[2], maximum


def create_finufft_plan(
    finufft: Any,
    nufft_type: int,
    shape: tuple[int, int, int],
    coordinates: tuple[np.ndarray, np.ndarray, np.ndarray],
    *,
    eps: float,
    isign: int,
    dtype: str,
    nthreads: int,
) -> tuple[Any, float]:
    options: dict[str, Any] = {}
    if nthreads > 0:
        options["nthreads"] = int(nthreads)
    start = time.perf_counter()
    plan = finufft.Plan(
        nufft_type,
        shape,
        eps=float(eps),
        isign=int(isign),
        dtype=dtype,
        **options,
    )
    plan.setpts(*coordinates)
    return plan, float(time.perf_counter() - start)


def centered_modes_to_embedded_kernel(centered: np.ndarray, n: int) -> np.ndarray:
    expected = (2 * n, 2 * n, 2 * n)
    if centered.shape != expected:
        raise ValueError(f"centered kernel shape {centered.shape} != {expected}")
    centered = np.array(centered, copy=True, order="C")
    # FINUFFT mode-order zero stores d=-N at index zero.  A finite N-grid
    # Toeplitz matrix only uses d in [-(N-1), N-1], so all -N hyperplanes are
    # deliberately absent from the circulant embedding.
    centered[0, :, :] = 0
    centered[:, 0, :] = 0
    centered[:, :, 0] = 0
    return np.ascontiguousarray(np.fft.ifftshift(centered))


def embedded_kernel_hermitian_error(kernel: np.ndarray) -> float:
    indices = [(-np.arange(size, dtype=np.int64)) % size for size in kernel.shape]
    reflected = np.conj(kernel[np.ix_(*indices)])
    denominator = max(float(np.linalg.norm(kernel.ravel())), np.finfo(float).tiny)
    return float(np.linalg.norm((kernel - reflected).ravel()) / denominator)


def apply_toeplitz_cpu(
    values: np.ndarray, symbol: np.ndarray, n: int, workers: int
) -> np.ndarray:
    padded = np.zeros(symbol.shape, dtype=values.dtype)
    padded[:n, :n, :n] = values
    spectrum = scipy_fft.fftn(padded, workers=workers)
    convolved = scipy_fft.ifftn(spectrum * symbol, workers=workers)
    return np.ascontiguousarray(convolved[:n, :n, :n])


def run_exact_gate(
    args: argparse.Namespace, q: dict[str, Any]
) -> dict[str, Any]:
    import finufft

    n = int(args.exact_n)
    shape = (n, n, n)
    spacing = cartesian_spacing(args, n)
    qx, qy, qz, coordinate_max = scaled_finufft_coordinates(
        q, spacing, real_dtype=np.dtype(np.float64)
    )
    coordinates = (qx, qy, qz)
    rng = np.random.default_rng(int(args.seed))
    x = random_complex(rng, shape, np.dtype(np.complex128))
    y = random_complex(rng, shape, np.dtype(np.complex128))

    type2, type2_setup_s = create_finufft_plan(
        finufft,
        2,
        shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=-1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    ax, ax_s = timed(lambda: type2.execute(x))
    ay, ay_s = timed(lambda: type2.execute(y))
    del type2
    gc.collect()

    type1, type1_setup_s = create_finufft_plan(
        finufft,
        1,
        shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    normal_x, normal_x_s = timed(lambda: type1.execute(ax))
    normal_y, normal_y_s = timed(lambda: type1.execute(ay))

    measurement_probe = random_complex(
        rng, (int(q["metadata"]["q_count"]),), np.dtype(np.complex128)
    )
    adjoint_probe, adjoint_probe_s = timed(lambda: type1.execute(measurement_probe))
    dot_left = np.vdot(ax, measurement_probe)
    dot_right = np.vdot(x, adjoint_probe)
    dot_error = bilinear_relative_error(dot_left, dot_right)
    del measurement_probe, adjoint_probe, type1
    gc.collect()

    strengths = np.ones(int(q["metadata"]["q_count"]), dtype=np.complex128)
    padded_shape = (2 * n, 2 * n, 2 * n)
    kernel_plan, kernel_plan_setup_s = create_finufft_plan(
        finufft,
        1,
        padded_shape,
        coordinates,
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    centered_kernel, kernel_execute_s = timed(lambda: kernel_plan.execute(strengths))
    del kernel_plan, strengths
    embedded_kernel, embedding_s = timed(
        lambda: centered_modes_to_embedded_kernel(centered_kernel, n)
    )
    del centered_kernel
    symbol, symbol_fft_s = timed(
        lambda: scipy_fft.fftn(embedded_kernel, workers=int(args.fft_workers))
    )
    toeplitz_x, toeplitz_x_s = timed(
        lambda: apply_toeplitz_cpu(x, symbol, n, int(args.fft_workers))
    )
    toeplitz_y, toeplitz_y_s = timed(
        lambda: apply_toeplitz_cpu(y, symbol, n, int(args.fft_workers))
    )

    direct_energy = np.vdot(x, normal_x)
    data_energy = np.vdot(ax, ax)
    direct_hermitian_left = np.vdot(y, normal_x)
    direct_hermitian_right = np.vdot(normal_y, x)
    toeplitz_hermitian_left = np.vdot(y, toeplitz_x)
    toeplitz_hermitian_right = np.vdot(toeplitz_y, x)
    psf_hermitian_error = embedded_kernel_hermitian_error(embedded_kernel)

    metrics = {
        "toeplitz_vs_finufft_normal_x_relative_l2": relative_l2(
            toeplitz_x, normal_x
        ),
        "toeplitz_vs_finufft_normal_y_relative_l2": relative_l2(
            toeplitz_y, normal_y
        ),
        "finufft_forward_adjoint_dot_relative_error": dot_error,
        "finufft_normal_hermitian_bilinear_relative_error": (
            bilinear_relative_error(direct_hermitian_left, direct_hermitian_right)
        ),
        "toeplitz_normal_hermitian_bilinear_relative_error": (
            bilinear_relative_error(
                toeplitz_hermitian_left, toeplitz_hermitian_right
            )
        ),
        "embedded_psf_hermitian_relative_l2": psf_hermitian_error,
        "normal_energy_vs_forward_norm2_relative_error": relative_scalar_error(
            direct_energy, data_energy
        ),
        "normal_energy_real": float(direct_energy.real),
        "normal_energy_imag_over_abs": float(
            abs(direct_energy.imag)
            / max(abs(direct_energy), np.finfo(float).tiny)
        ),
        "normal_energy_nonnegative": bool(direct_energy.real >= 0.0),
    }
    gates = {
        "toeplitz_vs_finufft_l2": bool(
            max(
                metrics["toeplitz_vs_finufft_normal_x_relative_l2"],
                metrics["toeplitz_vs_finufft_normal_y_relative_l2"],
            )
            <= float(args.exact_l2_tolerance)
        ),
        "forward_adjoint_dot": bool(
            metrics["finufft_forward_adjoint_dot_relative_error"]
            <= float(args.identity_tolerance)
        ),
        "hermitian": bool(
            max(
                metrics["finufft_normal_hermitian_bilinear_relative_error"],
                metrics["toeplitz_normal_hermitian_bilinear_relative_error"],
                metrics["embedded_psf_hermitian_relative_l2"],
            )
            <= float(args.identity_tolerance)
        ),
        "positive_semidefinite": bool(
            metrics["normal_energy_nonnegative"]
            and metrics["normal_energy_imag_over_abs"]
            <= float(args.identity_tolerance)
        ),
        "normal_energy_identity": bool(
            metrics["normal_energy_vs_forward_norm2_relative_error"]
            <= float(args.identity_tolerance)
        ),
    }
    return {
        "shape": list(shape),
        "padded_shape": list(padded_shape),
        "spacing_um": list(spacing),
        "cartesian_axes": (
            "FINUFFT centered integer modes times spacing; a common half-cell "
            "origin shift would cancel from A*WA"
        ),
        "scaled_q_coordinate_max_abs": coordinate_max,
        "dtype": "complex128",
        "finufft_version": getattr(finufft, "__version__", None),
        "finufft_eps": float(args.finufft_eps),
        "metrics": metrics,
        "gates": gates,
        "passed": bool(all(gates.values())),
        "timing_s": {
            "type2_plan_setup": type2_setup_s,
            "type1_plan_setup": type1_setup_s,
            "kernel_type1_plan_setup": kernel_plan_setup_s,
            "type2_x": ax_s,
            "type2_y": ay_s,
            "type1_normal_x": normal_x_s,
            "type1_normal_y": normal_y_s,
            "type1_adjoint_probe": adjoint_probe_s,
            "kernel_type1_execute": kernel_execute_s,
            "signed_difference_embedding": embedding_s,
            "symbol_fft": symbol_fft_s,
            "toeplitz_apply_x": toeplitz_x_s,
            "toeplitz_apply_y": toeplitz_y_s,
        },
        "storage_mib": {
            "object": float(x.nbytes / 1024**2),
            "one_measurement_vector": float(ax.nbytes / 1024**2),
            "embedded_kernel": float(embedded_kernel.nbytes / 1024**2),
            "symbol": float(symbol.nbytes / 1024**2),
        },
    }


def read_current_fused_baseline(path: Path, n: int) -> float | None:
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    for case in payload.get("cases", []):
        if int(case.get("selected_n_z", -1)) == n:
            # A selected-z cylindrical case keeps the two lateral dimensions at
            # 256.  It is a shape-matched timing reference only for N=256, not
            # for a genuinely smaller N^3 Cartesian feasibility case.
            object_shape = case.get("object_shape")
            if object_shape is not None and list(object_shape) != [n, n, n]:
                continue
            timing = case.get("fused_timing") or case.get("baseline_timing")
            if isinstance(timing, dict) and timing.get("median_s") is not None:
                return float(timing["median_s"])
    return None


def build_centered_kernel_complex64(
    args: argparse.Namespace,
    q: dict[str, Any],
    n: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    import finufft

    spacing = cartesian_spacing(args, n)
    qx, qy, qz, coordinate_max = scaled_finufft_coordinates(
        q, spacing, real_dtype=np.dtype(np.float32)
    )
    coordinates = (qx, qy, qz)
    plan, plan_setup_s = create_finufft_plan(
        finufft,
        1,
        (2 * n, 2 * n, 2 * n),
        coordinates,
        eps=float(args.gpu_finufft_eps),
        isign=+1,
        dtype="complex64",
        nthreads=int(args.finufft_threads),
    )
    strengths = np.ones(int(q["metadata"]["q_count"]), dtype=np.complex64)
    centered, execute_s = timed(lambda: plan.execute(strengths))
    del plan, strengths, qx, qy, qz
    gc.collect()
    return np.ascontiguousarray(centered, dtype=np.complex64), {
        "spacing_um": list(spacing),
        "scaled_q_coordinate_max_abs": coordinate_max,
        "finufft_eps": float(args.gpu_finufft_eps),
        "type1_plan_setup_s": plan_setup_s,
        "type1_execute_s": execute_s,
    }


def run_gpu_case(
    args: argparse.Namespace,
    q: dict[str, Any],
    n: int,
) -> dict[str, Any]:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for non-skipped GPU cases")
    device = torch.device(args.device)
    gc.collect()
    torch.cuda.empty_cache()
    free_before, total_before = torch.cuda.mem_get_info(device)
    centered, kernel_metadata = build_centered_kernel_complex64(args, q, n)

    torch.cuda.reset_peak_memory_stats(device)
    setup_start = time.perf_counter()
    centered_gpu = torch.from_numpy(centered).to(device=device)
    del centered
    centered_gpu[0, :, :] = 0
    centered_gpu[:, 0, :] = 0
    centered_gpu[:, :, 0] = 0
    embedded_gpu = torch.fft.ifftshift(centered_gpu, dim=(0, 1, 2))
    del centered_gpu
    symbol = torch.fft.fftn(embedded_gpu)
    del embedded_gpu
    torch.cuda.synchronize(device)
    symbol_gpu_build_s = float(time.perf_counter() - setup_start)
    symbol_setup_peak = int(torch.cuda.max_memory_allocated(device))

    generator = torch.Generator(device=device)
    generator.manual_seed(int(args.seed) + n)
    real = torch.randn((n, n, n), dtype=torch.float32, device=device, generator=generator)
    imag = torch.randn((n, n, n), dtype=torch.float32, device=device, generator=generator)
    obj = torch.complex(real, imag)
    del real, imag

    def apply() -> Any:
        padded = torch.zeros(
            (2 * n, 2 * n, 2 * n), dtype=torch.complex64, device=device
        )
        padded[:n, :n, :n].copy_(obj)
        spectrum = torch.fft.fftn(padded)
        spectrum.mul_(symbol)
        del padded
        convolved = torch.fft.ifftn(spectrum)
        output = convolved[:n, :n, :n].clone()
        del spectrum, convolved
        return output

    with torch.inference_mode():
        for _ in range(int(args.gpu_warmups)):
            value = apply()
            torch.cuda.synchronize(device)
            del value
        baseline_allocated = int(torch.cuda.memory_allocated(device))
        torch.cuda.reset_peak_memory_stats(device)
        samples: list[float] = []
        value = None
        for _ in range(int(args.gpu_repeats)):
            torch.cuda.synchronize(device)
            start = time.perf_counter()
            value = apply()
            torch.cuda.synchronize(device)
            samples.append(float(time.perf_counter() - start))
        peak_allocated = int(torch.cuda.max_memory_allocated(device))
        checksum = float(torch.linalg.vector_norm(value).item()) if value is not None else None
    timing = timing_summary(samples)
    baseline = read_current_fused_baseline(args.baseline_json, n)
    speedup = None if baseline is None else float(baseline / timing["median_s"])
    build_s = float(
        kernel_metadata["type1_plan_setup_s"]
        + kernel_metadata["type1_execute_s"]
        + symbol_gpu_build_s
    )
    saved_per_apply_s = (
        None if baseline is None else float(baseline - timing["median_s"])
    )
    amortization_iterations = (
        None
        if saved_per_apply_s is None or saved_per_apply_s <= 0.0
        else float(build_s / saved_per_apply_s)
    )
    total_memory = int(torch.cuda.get_device_properties(device).total_memory)
    result = {
        "n": n,
        "object_shape": [n, n, n],
        "padded_shape": [2 * n, 2 * n, 2 * n],
        "dtype": "complex64",
        "device": {
            "name": torch.cuda.get_device_name(device),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "free_before_case_mib": float(free_before / 1024**2),
            "total_before_case_mib": float(total_before / 1024**2),
        },
        "symbol": "physical W=I production-q signed-difference Toeplitz symbol",
        "kernel_build": {
            **kernel_metadata,
            "symbol_gpu_build_s": symbol_gpu_build_s,
            "symbol_setup_peak_allocated_mib": float(symbol_setup_peak / 1024**2),
        },
        "hot_apply_timing": timing,
        "output_norm_checksum": checksum,
        "memory": {
            "object_plus_cached_symbol_mib": float(baseline_allocated / 1024**2),
            "hot_peak_allocated_mib": float(peak_allocated / 1024**2),
            "hot_incremental_peak_mib": float(
                (peak_allocated - baseline_allocated) / 1024**2
            ),
            "device_total_mib": float(total_memory / 1024**2),
        },
        "comparison": {
            "baseline_json": str(args.baseline_json),
            "current_fused_normal_median_s": baseline,
            "hot_apply_speedup": speedup,
            "generic_symbol_total_build_s": build_s,
            "generic_build_amortization_iterations": amortization_iterations,
        },
        "gates": {
            "hot_apply_1p5x": bool(speedup is not None and speedup >= 1.5),
            "memory_within_budget": bool(
                peak_allocated <= float(args.max_memory_fraction) * total_memory
            ),
        },
    }
    del value, obj, symbol
    gc.collect()
    torch.cuda.empty_cache()
    return result


def reusable_gpu_cases(
    args: argparse.Namespace, geometry: dict[str, Any]
) -> dict[int, dict[str, Any]]:
    """Load completed large cases so a safe 128 then 256 run can be merged."""

    if not args.reuse_existing_gpu_cases or not args.output.exists():
        return {}
    try:
        payload = json.loads(args.output.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if payload.get("schema") != "odt-cartesian-toeplitz-exact-gate-v1":
        return {}
    old_geometry = payload.get("geometry", {})
    if old_geometry.get("q_sha256_qx_qy_qz_float64") != geometry["metadata"].get(
        "q_sha256_qx_qy_qz_float64"
    ):
        return {}
    cases: dict[int, dict[str, Any]] = {}
    for case in payload.get("gpu_cases", []):
        if not isinstance(case, dict) or case.get("n") is None:
            continue
        comparison = case.setdefault("comparison", {})
        kernel = case.get("kernel_build", {})
        build_s = float(
            kernel.get("type1_plan_setup_s", 0.0)
            + kernel.get("type1_execute_s", 0.0)
            + kernel.get("symbol_gpu_build_s", 0.0)
        )
        comparison.setdefault("generic_symbol_total_build_s", build_s)
        baseline = comparison.get("current_fused_normal_median_s")
        hot = case.get("hot_apply_timing", {}).get("median_s")
        if baseline is not None and hot is not None and float(baseline) > float(hot):
            comparison.setdefault(
                "generic_build_amortization_iterations",
                float(build_s / (float(baseline) - float(hot))),
            )
        else:
            comparison.setdefault("generic_build_amortization_iterations", None)
        cases[int(case["n"])] = case
    return cases


def render_markdown(result: dict[str, Any]) -> str:
    geometry = result["geometry"]
    exact = result["exact_gate"]
    metrics = exact["metrics"]
    lines = [
        "# Production ODT Cartesian Toeplitz exact gate",
        "",
        f"- exact gate: **{'PASS' if exact['passed'] else 'FAIL'}**",
        f"- geometry: `banded_inner96_outer64`, actual ring+axis q count `{geometry['q_count']:,}`",
        "- reference: FINUFFT type-2 followed by its type-1 adjoint, with `W=I`",
        "- candidate: signed-difference `(2N)^3` Toeplitz symbol and cropped FFT convolution",
        "",
        "## Production q contract",
        "",
        "| band | illumination | views | detector | q samples |",
        "|---|---|---:|---:|---:|",
    ]
    for block in geometry["blocks"]:
        lines.append(
            f"| {block['band']} | {block['illumination']} | "
            f"{block['illumination_count']} | "
            f"{block['cap_radial']}x{block['cap_phi']} | "
            f"{block['q_count']:,} |"
        )
    lines.extend(
        [
            "",
            "## Complex128 exactness",
            "",
            f"- Cartesian / padded shape: `{exact['shape']}` / `{exact['padded_shape']}`",
            f"- spacing: `{exact['spacing_um']}` micrometres",
            f"- Toeplitz vs FINUFFT normal rel-L2: `"
            f"{metrics['toeplitz_vs_finufft_normal_x_relative_l2']:.3e}` / `"
            f"{metrics['toeplitz_vs_finufft_normal_y_relative_l2']:.3e}`",
            f"- forward/adjoint dot error: `"
            f"{metrics['finufft_forward_adjoint_dot_relative_error']:.3e}`",
            f"- FINUFFT / Toeplitz Hermitian error: `"
            f"{metrics['finufft_normal_hermitian_bilinear_relative_error']:.3e}` / `"
            f"{metrics['toeplitz_normal_hermitian_bilinear_relative_error']:.3e}`",
            f"- PSF Hermitian rel-L2: `"
            f"{metrics['embedded_psf_hermitian_relative_l2']:.3e}`",
            f"- `<x,Nx>` vs `||Ax||^2` error: `"
            f"{metrics['normal_energy_vs_forward_norm2_relative_error']:.3e}`",
            f"- PSD energy imaginary fraction / nonnegative: `"
            f"{metrics['normal_energy_imag_over_abs']:.3e}` / `"
            f"{metrics['normal_energy_nonnegative']}`",
        ]
    )
    gpu_cases = result.get("gpu_cases", [])
    if gpu_cases:
        lines.extend(
            [
                "",
                "## Physical-symbol CUDA hot apply",
                "",
                "| N | padded | generic build s | median ms | p05--p95 ms | peak MiB | current speedup | build amortization |",
                "|---:|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for case in gpu_cases:
            timing = case["hot_apply_timing"]
            speedup = case["comparison"]["hot_apply_speedup"]
            speedup_text = "n/a" if speedup is None else f"{speedup:.3f}x"
            amortization = case["comparison"].get(
                "generic_build_amortization_iterations"
            )
            amortization_text = (
                "n/a" if amortization is None else f"{amortization:.0f} iter"
            )
            lines.append(
                f"| {case['n']} | {2 * case['n']}^3 | "
                f"{case['comparison']['generic_symbol_total_build_s']:.3f} | "
                f"{1000.0 * timing['median_s']:.3f} | "
                f"{1000.0 * timing['p05_s']:.3f}--{1000.0 * timing['p95_s']:.3f} | "
                f"{case['memory']['hot_peak_allocated_mib']:.1f} | {speedup_text} | "
                f"{amortization_text} |"
            )
    else:
        lines.extend(
            [
                "",
                "## CUDA status",
                "",
                "GPU cases were explicitly skipped in this run. The script keeps physical-symbol 128^3/256^3 CUDA cases available for a separately scheduled run.",
            ]
        )
    lines.extend(
        [
            "",
            "## Boundary",
            "",
            "This is an exact normal for a new uniform Cartesian reconstruction state. The current production solver uses half-cell radial nodes, beta samples, cylindrical volume weights, and a different unknown vector. Therefore this result does not establish coefficient-by-coefficient equivalence to the cylindrical solver, and the original solver is not modified. A fair integration test must rebuild the Cartesian data right-hand side and compare reconstruction trajectories in the same Cartesian discretization.",
            "",
            "The Toeplitz/FINUFFT comparison uses the complete production ring+axis q set and identical unit data weights. Symbol construction is setup work; hot apply excludes q generation, FINUFFT symbol build, data RHS construction, host transfer, regularization, and a converged reconstruction.",
        ]
    )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> dict[str, Any]:
    if args.exact_n <= 0:
        raise ValueError("exact-n must be positive")
    if args.gpu_warmups < 0 or args.gpu_repeats <= 0:
        raise ValueError("gpu warmups/repeats must be non-negative/positive")
    geometry = production_q_geometry(args)
    exact = run_exact_gate(args, geometry)
    gpu_by_n: dict[int, dict[str, Any]] = {}
    if not args.skip_gpu:
        gpu_by_n.update(reusable_gpu_cases(args, geometry))
        for n in parse_sizes(args.gpu_sizes):
            gpu_by_n[n] = run_gpu_case(args, geometry, n)
    gpu_cases = [gpu_by_n[n] for n in sorted(gpu_by_n)]

    result = {
        "schema": "odt-cartesian-toeplitz-exact-gate-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": bool(exact["passed"]),
        "geometry": geometry["metadata"],
        "cartesian_state": {
            "lateral_extent_um": [-float(args.r_max), float(args.r_max)],
            "axial_extent_um": [-float(args.z_max), float(args.z_max)],
            "finite_grid_boundary": "zero-extended; exact 2N circulant embedding then crop",
            "discretization_boundary": (
                "uniform Cartesian state; not the production half-cell cylindrical "
                "coefficient state"
            ),
        },
        "exact_gate": exact,
        "gpu_cases": gpu_cases,
        "decision_rule": {
            "exact_complex128": "rel-L2 <= 1e-10 plus dot/Hermitian/PSD identities",
            "production_complex64": (
                "candidate follow-up requires rel-L2 <= 2e-6 in the same Cartesian "
                "state and hot normal <= current/1.5"
            ),
        },
        "scope": [
            "Linear fixed-geometry Born/Rytov-field normal with diagonal W=I only.",
            "Uses all actual production banded ring+axis q samples; no q gridding or detector subsampling.",
            "Changes the reconstruction state from cylindrical coefficients to uniform Cartesian voxels.",
            "Does not modify or integrate with the original cylindrical solver.",
            "GPU rows, when requested, time a cached physical symbol apply only; symbol and data-RHS builds are separate setup costs.",
        ],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "platform": platform.platform(),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--exact-n", type=int, default=32)
    p.add_argument("--seed", type=int, default=20260805)
    p.add_argument("--finufft-eps", type=float, default=1e-12)
    p.add_argument("--gpu-finufft-eps", type=float, default=1e-5)
    p.add_argument("--finufft-threads", type=int, default=0)
    p.add_argument("--fft-workers", type=int, default=-1)
    p.add_argument("--exact-l2-tolerance", type=float, default=1e-10)
    p.add_argument("--identity-tolerance", type=float, default=1e-10)
    p.add_argument("--skip-gpu", action="store_true")
    p.add_argument("--gpu-sizes", default="128,256")
    p.add_argument(
        "--reuse-existing-gpu-cases",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Merge already completed sizes from the output receipt.",
    )
    p.add_argument("--device", default="cuda")
    p.add_argument("--gpu-warmups", type=int, default=2)
    p.add_argument("--gpu-repeats", type=int, default=10)
    p.add_argument("--max-memory-fraction", type=float, default=0.80)
    p.add_argument("--baseline-json", type=Path, default=DEFAULT_BASELINE)
    p.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "benchmark_results"
        / "odt_cartesian_toeplitz_exact_gate_20260805.json",
    )
    p.add_argument(
        "--summary",
        type=Path,
        default=ROOT
        / "benchmark_results"
        / "odt_cartesian_toeplitz_exact_gate_20260805_ko.md",
    )
    return p


def main() -> None:
    args = parser().parse_args()
    result = run(args)
    exact = result["exact_gate"]
    compact = {
        "passed": result["passed"],
        "q_count": result["geometry"]["q_count"],
        "exact_shape": exact["shape"],
        "toeplitz_rel_l2": exact["metrics"][
            "toeplitz_vs_finufft_normal_x_relative_l2"
        ],
        "dot_error": exact["metrics"][
            "finufft_forward_adjoint_dot_relative_error"
        ],
        "gpu_cases": [
            {
                "n": case["n"],
                "median_ms": 1000.0 * case["hot_apply_timing"]["median_s"],
                "peak_mib": case["memory"]["hot_peak_allocated_mib"],
                "speedup": case["comparison"]["hot_apply_speedup"],
            }
            for case in result["gpu_cases"]
        ],
        "output": str(args.output),
        "summary": str(args.summary),
    }
    print(json.dumps(compact, ensure_ascii=False, indent=2))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
