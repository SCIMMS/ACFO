#!/usr/bin/env python3
"""Verify an ODT Toeplitz SI external return ZIP and recompute its verdict."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
RETURN_ROOT_NAME = "odt_toeplitz_si_external_return"
PROTOCOL_NAME = "ODT_TOEPLITZ_SI_RTX3090_PROTOCOL.json"
MANIFEST_NAME = "PACKAGE_MANIFEST.json"
PROVENANCE_NAME = "REQUEST_PROVENANCE.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError(f"JSON root is not an object: {path}")
    return payload


def safe_member(info: zipfile.ZipInfo) -> str | None:
    name = info.filename
    pure = PurePosixPath(name)
    if not name or pure.is_absolute() or ".." in pure.parts or "\\" in name:
        return "unsafe path"
    if info.flag_bits & 0x1:
        return "encrypted member"
    mode = (info.external_attr >> 16) & 0xFFFF
    if mode and stat.S_ISLNK(mode):
        return "symlink-like member"
    return None


def parse_sidecar(path: Path) -> str:
    words = path.read_text(encoding="utf-8").strip().split()
    if not words or len(words[0]) != 64:
        raise ValueError("invalid SHA-256 sidecar")
    int(words[0], 16)
    return words[0].lower()


def nested_close(left: Any, right: Any, *, rel: float = 1e-12, abs_: float = 1e-12) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return left is right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        if not (math.isfinite(float(left)) and math.isfinite(float(right))):
            return left == right
        return math.isclose(float(left), float(right), rel_tol=rel, abs_tol=abs_)
    if isinstance(left, dict) and isinstance(right, dict):
        return set(left) == set(right) and all(
            nested_close(left[key], right[key], rel=rel, abs_=abs_)
            for key in left
        )
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(
            nested_close(a, b, rel=rel, abs_=abs_)
            for a, b in zip(left, right, strict=True)
        )
    return left == right


def validate_zip(
    archive_path: Path, sidecar: Path | None, expected_sha256: str | None
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "archive": str(archive_path),
        "archive_sha256": sha256(archive_path),
        "errors": [],
        "passed": False,
    }
    if sidecar is not None:
        try:
            result["sidecar_sha256"] = parse_sidecar(sidecar)
            if result["sidecar_sha256"] != result["archive_sha256"]:
                result["errors"].append("archive digest differs from sidecar")
        except Exception as error:
            result["errors"].append(f"sidecar: {type(error).__name__}: {error}")
    if expected_sha256 is not None:
        normalized = expected_sha256.strip().lower()
        result["expected_sha256"] = normalized
        if normalized != result["archive_sha256"]:
            result["errors"].append("archive digest differs from expected digest")
    with zipfile.ZipFile(archive_path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        duplicates = sorted({name for name in names if names.count(name) > 1})
        if duplicates:
            result["errors"].append(f"duplicate members: {duplicates}")
        unsafe = [
            {"name": info.filename, "error": error}
            for info in infos
            if (error := safe_member(info)) is not None
        ]
        if unsafe:
            result["errors"].append(f"unsafe members: {unsafe}")
        roots = {PurePosixPath(name).parts[0] for name in names if name}
        result["root_prefixes"] = sorted(roots)
        if roots != {RETURN_ROOT_NAME}:
            result["errors"].append(f"unexpected root prefixes: {sorted(roots)}")
        bad = archive.testzip()
        result["crc_bad_member"] = bad
        if bad is not None:
            result["errors"].append(f"CRC failed at {bad}")
        result["member_count"] = len(infos)
    result["passed"] = not result["errors"]
    return result


def validate_manifest(return_root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"errors": [], "passed": False}
    manifest_path = return_root / "RETURN_MANIFEST.json"
    try:
        manifest = load_json(manifest_path)
        result["schema"] = manifest.get("schema")
        if manifest.get("schema") != "odt-toeplitz-si-return-manifest-v1":
            result["errors"].append("return manifest schema mismatch")
        records = manifest.get("files")
        if not isinstance(records, dict):
            raise TypeError("return manifest files is not an object")
        expected = set(records) | {"RETURN_MANIFEST.json"}
        observed = {
            path.relative_to(return_root).as_posix()
            for path in return_root.rglob("*")
            if path.is_file()
        }
        result["missing"] = sorted(expected - observed)
        result["unexpected"] = sorted(observed - expected)
        mismatched = []
        for relative in sorted(set(records) & observed):
            path = return_root / Path(*PurePosixPath(relative).parts)
            expected_row = records[relative]
            observed_row = {
                "bytes": int(path.stat().st_size),
                "sha256": sha256(path),
            }
            if observed_row != expected_row:
                mismatched.append(
                    {
                        "path": relative,
                        "expected": expected_row,
                        "observed": observed_row,
                    }
                )
        result["mismatched"] = mismatched
        result["manifest_sha256"] = sha256(manifest_path)
        result["manifested_file_count"] = len(records)
        result["passed"] = bool(
            manifest.get("schema") == "odt-toeplitz-si-return-manifest-v1"
            and not result["missing"]
            and not result["unexpected"]
            and not mismatched
        )
    except Exception as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
    return result


def validate_request_anchor(return_root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"errors": [], "passed": False}
    try:
        anchor = load_json(return_root / "REQUEST_ANCHOR.json")
        evidence = return_root / "request_evidence"
        protocol_path = evidence / PROTOCOL_NAME
        manifest_path = evidence / MANIFEST_NAME
        provenance_path = evidence / PROVENANCE_NAME
        protocol = load_json(protocol_path)
        manifest = load_json(manifest_path)
        provenance = load_json(provenance_path)
        checks = {
            "anchor_schema": anchor.get("schema")
            == "odt-toeplitz-si-request-anchor-v1",
            "protocol_schema": protocol.get("schema")
            == "odt-toeplitz-si-rtx3090-protocol-v1",
            "manifest_schema": manifest.get("schema")
            == "odt-toeplitz-si-request-manifest-v1",
            "provenance_schema": provenance.get("schema")
            == "odt-toeplitz-si-request-provenance-v1",
            "manifest_hash": anchor.get("request_manifest_sha256")
            == sha256(manifest_path),
            "protocol_hash": anchor.get("protocol_sha256")
            == sha256(protocol_path),
            "provenance_hash": anchor.get("provenance_sha256")
            == sha256(provenance_path),
            "manifest_protocol_anchor": manifest.get("protocol_sha256")
            == sha256(protocol_path),
            "manifest_provenance_anchor": manifest.get("provenance_sha256")
            == sha256(provenance_path),
            "runner_hash": anchor.get("runner_sha256")
            == manifest.get("files", {})
            .get("scripts/run_odt_toeplitz_si_external_validation.py", {})
            .get("sha256"),
        }
        result["checks"] = checks
        result["required_files"] = protocol["return_contract"]["required_files"]
        result["required_files_present"] = {
            relative: (return_root / relative).is_file()
            for relative in result["required_files"]
        }
        result["passed"] = bool(
            all(checks.values()) and all(result["required_files_present"].values())
        )
    except Exception as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
    return result


def recompute_aggregate(return_root: Path, temp_root: Path) -> dict[str, Any]:
    import argparse as argparse_module
    import sys

    scripts = ROOT / "scripts"
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    from aggregate_odt_toeplitz_si import run as aggregate_run

    receipts = return_root / "receipts"
    optional = receipts / "stage5_cufinufft_toeplitz.json"
    namespace = argparse_module.Namespace(
        exact=receipts / "stage1_exact_complex128.json",
        weighted=receipts / "stage2_weighted_updates.json",
        cg=receipts / "stage3_cg_trajectory.json",
        cufinufft=receipts / "stage4_cufinufft_normal.json",
        cufinufft_toeplitz=optional if optional.is_file() else None,
        generic=receipts / "stage6_cpu_generic_toeplitz.json",
        acfo=receipts / "stage7_acfo_toeplitz.json",
        gpu_sample_tolerance=2e-4,
        gpu_norm_tolerance=2e-4,
        apply_counts="1,10,100,1000",
        rebuild_intervals="1,10,100,1000",
        output=temp_root / "recomputed.json",
        summary=temp_root / "recomputed.md",
    )
    return aggregate_run(namespace)


def validate_science(return_root: Path, temp_root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"errors": [], "passed": False}
    try:
        outer = load_json(return_root / "AGGREGATE_RESULT.json")
        reported = load_json(
            return_root / "aggregate" / "ODT_TOEPLITZ_SI_AGGREGATE.json"
        )
        recomputed = recompute_aggregate(return_root, temp_root)
        compared_keys = [
            "scientific_correctness",
            "research_disposition",
            "configuration",
            "correctness_gates",
            "accuracy",
            "methods",
            "method_order",
            "performance",
            "amortization",
            "supporting_gates",
            "claim_boundary",
        ]
        comparisons = {
            key: nested_close(reported.get(key), recomputed.get(key))
            for key in compared_keys
        }
        comparisons["optional_gpu_generic"] = nested_close(
            {
                key: reported.get("optional_gpu_generic", {}).get(key)
                for key in ("requested", "available", "reason")
            },
            {
                key: recomputed.get("optional_gpu_generic", {}).get(key)
                for key in ("requested", "available", "reason")
            },
        )
        outer_checks = {
            "schema": outer.get("schema")
            == "odt-toeplitz-si-external-run-result-v1",
            "request_integrity": outer.get("request_integrity") is True,
            "inner_present": isinstance(outer.get("aggregate"), dict),
            "inner_science_matches": outer.get("scientific_correctness")
            is reported.get("scientific_correctness"),
            "inner_performance_matches": outer.get("performance_compelling")
            is bool(
                reported.get("performance", {}).get("toeplitz_hot_advantage")
                and reported.get("performance", {}).get("acfo_setup_advantage")
            ),
            "embedded_aggregate_matches": nested_close(
                outer.get("aggregate"), reported
            ),
        }
        result["reported_scientific_correctness"] = reported.get(
            "scientific_correctness"
        )
        result["reported_research_disposition"] = reported.get(
            "research_disposition"
        )
        result["comparisons"] = comparisons
        result["outer_checks"] = outer_checks
        result["recomputed_performance"] = recomputed.get("performance")
        result["recomputed_accuracy"] = recomputed.get("accuracy")
        result["passed"] = bool(
            all(comparisons.values()) and all(outer_checks.values())
        )
    except Exception as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
    return result


def verify(args: argparse.Namespace) -> dict[str, Any]:
    archive_path = args.archive.resolve()
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)
    zip_check = validate_zip(
        archive_path,
        None if args.sha256_sidecar is None else args.sha256_sidecar.resolve(),
        args.expected_sha256,
    )
    with tempfile.TemporaryDirectory(prefix="odt_toeplitz_si_verify_") as temp:
        temp_root = Path(temp)
        if zip_check["passed"]:
            with zipfile.ZipFile(archive_path) as archive:
                archive.extractall(temp_root)
        return_root = temp_root / RETURN_ROOT_NAME
        manifest = validate_manifest(return_root) if return_root.is_dir() else {
            "passed": False,
            "errors": ["return root missing"],
        }
        anchor = validate_request_anchor(return_root) if manifest["passed"] else {
            "passed": False,
            "errors": ["manifest validation failed"],
        }
        science = validate_science(return_root, temp_root) if anchor["passed"] else {
            "passed": False,
            "errors": ["request anchor validation failed"],
        }
        result = {
            "schema": "odt-toeplitz-si-return-verification-v1",
            "archive": str(archive_path),
            "integrity_passed": bool(
                zip_check["passed"] and manifest["passed"] and anchor["passed"]
            ),
            "independent_audit_passed": bool(science["passed"]),
            "passed": bool(
                zip_check["passed"]
                and manifest["passed"]
                and anchor["passed"]
                and science["passed"]
            ),
            "zip": zip_check,
            "manifest": manifest,
            "request_anchor": anchor,
            "science": science,
        }
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("archive", type=Path)
    p.add_argument("--sha256-sidecar", type=Path)
    p.add_argument("--expected-sha256")
    p.add_argument("--output", type=Path)
    return p


def main() -> None:
    result = verify(parser().parse_args())
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "integrity_passed": result["integrity_passed"],
                "independent_audit_passed": result["independent_audit_passed"],
                "archive": result["archive"],
            },
            indent=2,
        )
    )
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
