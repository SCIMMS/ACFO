#!/usr/bin/env python3
"""Build the N=256 physical ODT Toeplitz symbol by ACFO and time it on GPU.

The full production-q FINUFFT build is deliberately not repeated.  The CPU
side uses the detector x illumination factorization validated by
``benchmark_odt_acfo_toeplitz_symbol_build.py``: unique integer lateral radii,
J0/axial tables, and one radial-z contraction produce the centered 2N kernel.
The centered complex64 kernel is transferred to CUDA, embedded by ifftshift,
and transformed to the cached Toeplitz symbol.  Hot application is byte-for-
byte the same workflow and RNG seed convention as the existing generic-symbol
receipt.

Accuracy evidence combines the saved N=128 complex128 full FINUFFT gate with
fresh N=256 direct sums over all 3,469,312 q points at random signed-difference
locations.  This script is standalone and does not modify the original solver.
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import special


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_acfo_toeplitz_symbol_build import (  # noqa: E402
    analytic_detector_geometry,
    alias_report,
    fmt,
    unique_lateral_radii,
)
from benchmark_odt_cartesian_toeplitz_exact_gate import (  # noqa: E402
    cartesian_spacing,
    production_q_geometry,
    timing_summary,
)


DEFAULT_OUTPUT = (
    ROOT
    / "benchmark_results"
    / "odt_acfo_toeplitz_symbol_gpu_20260805.json"
)
DEFAULT_SUMMARY = (
    ROOT
    / "benchmark_results"
    / "odt_acfo_toeplitz_symbol_gpu_20260805_ko.md"
)
DEFAULT_EXACT_RECEIPT = (
    ROOT
    / "benchmark_results"
    / "odt_acfo_toeplitz_symbol_build_20260805.json"
)
DEFAULT_GENERIC_RECEIPT = (
    ROOT
    / "benchmark_results"
    / "odt_cartesian_toeplitz_exact_gate_20260805.json"
)


def timed(callback: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = callback()
    return value, float(time.perf_counter() - start)


def process_rss_bytes() -> int | None:
    try:
        import psutil

        return int(psutil.Process().memory_info().rss)
    except (ImportError, OSError):
        return None


def update_observed_rss(state: dict[str, int | None]) -> None:
    rss = process_rss_bytes()
    if rss is None:
        return
    previous = state.get("maximum")
    state["maximum"] = rss if previous is None else max(int(previous), rss)
    state["current"] = rss


def build_acfo_centered_complex64(
    args: argparse.Namespace,
    detector: dict[str, Any],
    n: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    spacing = cartesian_spacing(args, n)
    rss_state: dict[str, int | None] = {"start": process_rss_bytes(), "maximum": None}
    update_observed_rss(rss_state)

    radii_data, radius_setup_s = timed(
        lambda: unique_lateral_radii(n, spacing[0])
    )
    differences = radii_data["differences"]
    radii = radii_data["radii"]
    inverse = radii_data["inverse"]
    z = np.ascontiguousarray(differences.astype(np.float64) * spacing[2])
    update_observed_rss(rss_state)

    k = float(args.k)
    ring_na = math.sin(math.radians(float(args.illumination_angle_deg)))
    ring_sz = math.sqrt(max(1.0 - ring_na * ring_na, 0.0))
    detector_radial = detector["radial"]
    detector_axial = detector["axial"]
    detector_multiplicity = detector["multiplicity"]

    def make_tables() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        detector_j0 = special.j0(
            k * radii[:, None] * detector_radial[None, :]
        ).astype(np.float32)
        detector_j0 *= detector_multiplicity.astype(np.float32)[None, :]
        detector_z = np.exp(
            1j * k * detector_axial[:, None] * z[None, :]
        ).astype(np.complex64)
        illumination_j0 = special.j0(k * ring_na * radii).astype(np.float32)
        return (
            np.ascontiguousarray(detector_j0),
            np.ascontiguousarray(detector_z),
            np.ascontiguousarray(illumination_j0),
        )

    (detector_j0, detector_z, illumination_j0), table_setup_s = timed(make_tables)
    update_observed_rss(rss_state)
    detector_sum, detector_contraction_s = timed(lambda: detector_j0 @ detector_z)
    del detector_j0, detector_z
    gc.collect()
    update_observed_rss(rss_state)

    ring_phase = np.exp(-1j * k * ring_sz * z).astype(np.complex64)
    axis_phase = np.exp(-1j * k * z).astype(np.complex64)
    illumination_sum = (
        np.float32(args.ring_illum)
        * illumination_j0[:, None]
        * ring_phase[None, :]
        + axis_phase[None, :]
    ).astype(np.complex64, copy=False)
    psf_table, product_s = timed(
        lambda: np.multiply(detector_sum, illumination_sum, dtype=np.complex64)
    )
    del detector_sum, illumination_sum, illumination_j0, ring_phase, axis_phase
    gc.collect()
    update_observed_rss(rss_state)

    side = 2 * n - 1

    def gather_chunked() -> np.ndarray:
        centered = np.zeros((2 * n, 2 * n, 2 * n), dtype=np.complex64)
        chunk = int(args.gather_chunk_x)
        for x_start in range(0, side, chunk):
            x_stop = min(x_start + chunk, side)
            local_inverse = inverse[x_start:x_stop].reshape(-1)
            values = psf_table[local_inverse, :].reshape(
                x_stop - x_start, side, side
            )
            centered[1 + x_start : 1 + x_stop, 1:, 1:] = values
            del values
        return centered

    centered, gather_s = timed(gather_chunked)
    update_observed_rss(rss_state)
    center_value = centered[n, n, n]
    del psf_table, inverse
    gc.collect()
    update_observed_rss(rss_state)
    timings = {
        "unique_radius_setup": radius_setup_s,
        "bessel_and_axial_tables": table_setup_s,
        "radial_axial_gemm": detector_contraction_s,
        "detector_illumination_product": product_s,
        "signed_difference_gather": gather_s,
    }
    return centered, {
        "spacing_um": list(spacing),
        "signed_lateral_point_count": int(side * side),
        "unique_lateral_radius_count": int(radii.size),
        "radius_reuse_factor": float(side * side / radii.size),
        "signed_z_count": int(side),
        "detector_radial_count": int(detector_radial.size),
        "contraction_complex_mac_count": int(
            radii.size * detector_radial.size * side
        ),
        "center_value_real": float(center_value.real),
        "center_value_imag": float(center_value.imag),
        "timing_s": timings,
        "cpu_kernel_build_s": float(sum(timings.values())),
        "observed_process_rss_mib": {
            key: None if value is None else float(value / 1024**2)
            for key, value in rss_state.items()
        },
    }


def gpu_symbol_from_centered(
    torch: Any,
    centered: np.ndarray,
    device: Any,
) -> tuple[Any, dict[str, Any]]:
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    free_before, total_before = torch.cuda.mem_get_info(device)

    torch.cuda.synchronize(device)
    start = time.perf_counter()
    centered_host_tensor = torch.from_numpy(centered)
    centered_gpu = centered_host_tensor.to(device=device)
    torch.cuda.synchronize(device)
    h2d_s = float(time.perf_counter() - start)
    allocated_after_h2d = int(torch.cuda.memory_allocated(device))
    del centered_host_tensor

    torch.cuda.synchronize(device)
    start = time.perf_counter()
    embedded_gpu = torch.fft.ifftshift(centered_gpu, dim=(0, 1, 2))
    torch.cuda.synchronize(device)
    embedding_s = float(time.perf_counter() - start)
    del centered_gpu
    allocated_after_embedding = int(torch.cuda.memory_allocated(device))

    torch.cuda.synchronize(device)
    start = time.perf_counter()
    symbol = torch.fft.fftn(embedded_gpu)
    torch.cuda.synchronize(device)
    fft_s = float(time.perf_counter() - start)
    del embedded_gpu
    allocated_after_fft = int(torch.cuda.memory_allocated(device))
    peak_allocated = int(torch.cuda.max_memory_allocated(device))
    peak_reserved = int(torch.cuda.max_memory_reserved(device))
    return symbol, {
        "h2d_centered_kernel_s": h2d_s,
        "gpu_ifftshift_embedding_s": embedding_s,
        "gpu_symbol_fft_s": fft_s,
        "gpu_setup_s": float(h2d_s + embedding_s + fft_s),
        "free_before_mib": float(free_before / 1024**2),
        "total_before_mib": float(total_before / 1024**2),
        "allocated_after_h2d_mib": float(allocated_after_h2d / 1024**2),
        "allocated_after_embedding_mib": float(
            allocated_after_embedding / 1024**2
        ),
        "allocated_after_fft_mib": float(allocated_after_fft / 1024**2),
        "peak_allocated_mib": float(peak_allocated / 1024**2),
        "peak_reserved_mib": float(peak_reserved / 1024**2),
    }


def hot_apply(
    args: argparse.Namespace,
    torch: Any,
    symbol: Any,
    device: Any,
    n: int,
) -> dict[str, Any]:
    generator = torch.Generator(device=device)
    generator.manual_seed(int(args.seed) + n)
    real = torch.randn(
        (n, n, n), dtype=torch.float32, device=device, generator=generator
    )
    imag = torch.randn(
        (n, n, n), dtype=torch.float32, device=device, generator=generator
    )
    obj = torch.complex(real, imag)
    del real, imag

    def apply() -> Any:
        padded = torch.zeros(
            (2 * n, 2 * n, 2 * n), dtype=torch.complex64, device=device
        )
        padded[:n, :n, :n].copy_(obj)
        spectrum = torch.fft.fftn(padded)
        spectrum.mul_(symbol)
        del padded
        convolved = torch.fft.ifftn(spectrum)
        output = convolved[:n, :n, :n].clone()
        del spectrum, convolved
        return output

    with torch.inference_mode():
        for _ in range(int(args.gpu_warmups)):
            value = apply()
            torch.cuda.synchronize(device)
            del value
        baseline_allocated = int(torch.cuda.memory_allocated(device))
        torch.cuda.reset_peak_memory_stats(device)
        samples: list[float] = []
        value = None
        for _ in range(int(args.gpu_repeats)):
            torch.cuda.synchronize(device)
            start = time.perf_counter()
            value = apply()
            torch.cuda.synchronize(device)
            samples.append(float(time.perf_counter() - start))
        peak_allocated = int(torch.cuda.max_memory_allocated(device))
        checksum = float(torch.linalg.vector_norm(value).item()) if value is not None else None
    del value, obj
    gc.collect()
    return {
        "timing": timing_summary(samples),
        "output_norm_checksum": checksum,
        "object_plus_cached_symbol_mib": float(baseline_allocated / 1024**2),
        "peak_allocated_mib": float(peak_allocated / 1024**2),
        "incremental_peak_mib": float(
            (peak_allocated - baseline_allocated) / 1024**2
        ),
    }


def signed_difference_samples(n: int, count: int, seed: int) -> np.ndarray:
    if count < 8:
        raise ValueError("direct-check-count must be at least 8")
    edge = n - 1
    fixed = [
        (0, 0, 0),
        (1, 0, 0),
        (0, 1, 0),
        (0, 0, 1),
        (edge, edge, edge),
        (-edge, -edge, -edge),
        (edge, -edge, edge),
        (-edge, edge, -edge),
    ]
    rng = np.random.default_rng(seed)
    values = set(fixed)
    while len(values) < count:
        point = tuple(
            int(value)
            for value in rng.integers(-edge, edge + 1, size=3, endpoint=False)
        )
        values.add(point)
    ordered = fixed + sorted(values - set(fixed))
    return np.asarray(ordered[:count], dtype=np.int64)


def direct_q_check(
    args: argparse.Namespace,
    samples: np.ndarray,
    candidate: np.ndarray,
    n: int,
) -> dict[str, Any]:
    q, q_build_s = timed(lambda: production_q_geometry(args))
    spacing = np.asarray(cartesian_spacing(args, n), dtype=np.float64)
    displacement = samples.astype(np.float64) * spacing[None, :]
    reference = np.zeros(samples.shape[0], dtype=np.complex128)

    start_time = time.perf_counter()
    q_count = int(q["metadata"]["q_count"])
    point_chunk = int(args.direct_point_chunk)
    q_chunk = int(args.direct_q_chunk)
    for point_start in range(0, samples.shape[0], point_chunk):
        point_stop = min(point_start + point_chunk, samples.shape[0])
        local_displacement = displacement[point_start:point_stop]
        local_sum = np.zeros(point_stop - point_start, dtype=np.complex128)
        for q_start in range(0, q_count, q_chunk):
            q_stop = min(q_start + q_chunk, q_count)
            phase = (
                q["qx"][q_start:q_stop, None] * local_displacement[None, :, 0]
                + q["qy"][q_start:q_stop, None] * local_displacement[None, :, 1]
                + q["qz"][q_start:q_stop, None] * local_displacement[None, :, 2]
            )
            local_sum += np.exp(1j * phase).sum(axis=0, dtype=np.complex128)
        reference[point_start:point_stop] = local_sum
    direct_sum_s = float(time.perf_counter() - start_time)

    difference = candidate.astype(np.complex128) - reference
    relative_l2 = float(
        np.linalg.norm(difference)
        / max(float(np.linalg.norm(reference)), np.finfo(float).tiny)
    )
    center_mask = np.all(samples == 0, axis=1)
    noncenter = ~center_mask
    noncenter_relative_l2 = float(
        np.linalg.norm(difference[noncenter])
        / max(float(np.linalg.norm(reference[noncenter])), np.finfo(float).tiny)
    )
    point_relative = np.abs(difference) / np.maximum(
        np.abs(reference), np.finfo(float).tiny
    )
    max_abs = float(np.max(np.abs(difference)))
    max_abs_over_center = float(max_abs / q_count)
    rows = [
        {
            "difference_index": [int(value) for value in samples[index]],
            "candidate_real": float(candidate[index].real),
            "candidate_imag": float(candidate[index].imag),
            "reference_real": float(reference[index].real),
            "reference_imag": float(reference[index].imag),
            "absolute_error": float(abs(difference[index])),
        }
        for index in range(samples.shape[0])
    ]
    geometry = q["metadata"]
    del q
    gc.collect()
    return {
        "sample_count": int(samples.shape[0]),
        "includes_center": bool(np.any(np.all(samples == 0, axis=1))),
        "q_count": q_count,
        "q_sha256_qx_qy_qz_float64": geometry["q_sha256_qx_qy_qz_float64"],
        "timing_s": {
            "q_build": q_build_s,
            "direct_sum": direct_sum_s,
        },
        "metrics": {
            "sample_relative_l2": relative_l2,
            "noncenter_sample_relative_l2": noncenter_relative_l2,
            "max_point_relative_error": float(np.max(point_relative)),
            "max_absolute_error": max_abs,
            "max_absolute_error_over_center": max_abs_over_center,
        },
        "samples": rows,
    }


def load_n128_exact_gate(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema") != "odt-acfo-toeplitz-symbol-build-v1":
        raise ValueError("unexpected N=128 exact receipt schema")
    for case in payload.get("cases", []):
        if int(case.get("n", -1)) == 128:
            return {
                "source": str(path.resolve()),
                "receipt_passed": bool(payload.get("passed")),
                "case_passed": bool(case["gate"]["passed"]),
                "centered_kernel_relative_l2": case["metrics"][
                    "centered_kernel_relative_l2"
                ],
                "symbol_relative_l2": case["metrics"]["symbol_relative_l2"],
                "relative_l2_tolerance": case["gate"]["relative_l2_tolerance"],
            }
    raise ValueError("N=128 case missing from exact receipt")


def load_generic_n256(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    for case in payload.get("gpu_cases", []):
        if int(case.get("n", -1)) == 256:
            return {
                "source": str(path.resolve()),
                "q_sha256_qx_qy_qz_float64": payload["geometry"][
                    "q_sha256_qx_qy_qz_float64"
                ],
                "generic_symbol_total_build_s": case["comparison"][
                    "generic_symbol_total_build_s"
                ],
                "generic_type1_execute_s": case["kernel_build"][
                    "type1_execute_s"
                ],
                "generic_finufft_eps": case["kernel_build"]["finufft_eps"],
                "generic_symbol_gpu_build_s": case["kernel_build"][
                    "symbol_gpu_build_s"
                ],
                "hot_apply_median_s": case["hot_apply_timing"]["median_s"],
                "hot_apply_samples_s": case["hot_apply_timing"]["samples_s"],
                "output_norm_checksum": case["output_norm_checksum"],
                "symbol_setup_peak_allocated_mib": case["kernel_build"][
                    "symbol_setup_peak_allocated_mib"
                ],
            }
    raise ValueError("N=256 case missing from generic receipt")


def render_markdown(result: dict[str, Any]) -> str:
    build = result["acfo_build"]
    gpu = result["gpu_symbol_setup"]
    hot = result["hot_apply"]
    generic = result["generic_reference"]
    check = result["direct_q_check"]
    exact = result["n128_complex128_gate"]
    lines = [
        "# ODT N=256 ACFO physical Toeplitz symbol GPU setup",
        "",
        f"- 판정: **{'PASS' if result['passed'] else 'FAIL'}**",
        "- full production-q FINUFFT 재실행: 없음",
        "- 원본 solver 변경: 없음",
        "",
        "## 결론",
        "",
        f"ACFO complex64 end-to-end symbol setup은 **{fmt(result['timing_s']['end_to_end_symbol_setup'])} s**였다. 기존 generic FINUFFT receipt의 {fmt(generic['generic_symbol_total_build_s'])} s 대비 **{fmt(result['comparison']['symbol_setup_speedup'])}x** 빠르다.",
        "",
        "## setup 분해",
        "",
        "| stage | time (s) |",
        "|---|---:|",
        f"| analytic detector geometry | {fmt(result['timing_s']['analytic_geometry'])} |",
        f"| unique r² | {fmt(build['timing_s']['unique_radius_setup'])} |",
        f"| J0 + axial tables | {fmt(build['timing_s']['bessel_and_axial_tables'])} |",
        f"| radial-z GEMM | {fmt(build['timing_s']['radial_axial_gemm'])} |",
        f"| detector × illumination | {fmt(build['timing_s']['detector_illumination_product'])} |",
        f"| signed-difference gather | {fmt(build['timing_s']['signed_difference_gather'])} |",
        f"| H2D | {fmt(gpu['h2d_centered_kernel_s'])} |",
        f"| GPU ifftshift embedding | {fmt(gpu['gpu_ifftshift_embedding_s'])} |",
        f"| GPU symbol FFT | {fmt(gpu['gpu_symbol_fft_s'])} |",
        f"| **total** | **{fmt(result['timing_s']['end_to_end_symbol_setup'])}** |",
        "",
        "## 정확성",
        "",
        f"- N=128 complex128 full FINUFFT gate: kernel {fmt(exact['centered_kernel_relative_l2'])}, symbol {fmt(exact['symbol_relative_l2'])} rel-L2.",
        f"- N=256 direct-q {check['sample_count']}점: all/noncenter rel-L2 {fmt(check['metrics']['sample_relative_l2'])}/{fmt(check['metrics']['noncenter_sample_relative_l2'])}, max point relative error {fmt(check['metrics']['max_point_relative_error'])}.",
        f"- center K(0): {fmt(build['center_value_real'])} (expected {result['geometry']['q_count']:,}).",
        "",
        "## hot apply와 memory",
        "",
        f"- hot apply median: {1e3 * hot['timing']['median_s']:.3f} ms (기존 {1e3 * generic['hot_apply_median_s']:.3f} ms).",
        f"- output norm checksum: {hot['output_norm_checksum']:.9e} (기존 FINUFFT eps={generic['generic_finufft_eps']:.0e} receipt {generic['output_norm_checksum']:.9e}, relative difference {result['comparison']['checksum_relative_difference']:.3e}).",
        f"- symbol setup GPU peak allocated/reserved: {gpu['peak_allocated_mib']:.1f}/{gpu['peak_reserved_mib']:.1f} MiB.",
        f"- hot apply peak allocated: {hot['peak_allocated_mib']:.1f} MiB.",
        f"- observed host RSS maximum: {build['observed_process_rss_mib']['maximum']:.1f} MiB.",
        "",
        "## 해석",
        "",
        f"xy {build['signed_lateral_point_count']:,}개는 unique r² {build['unique_lateral_radius_count']:,}개로 줄어 {build['radius_reuse_factor']:.2f}배 재사용된다. exact discrete symmetry는 C8이지만 finite-comb alias는 double precision보다 훨씬 작으므로 이 grid에서는 m=0 J0 contraction으로 충분하다.",
        "",
        "이 결론은 uniform azimuth, fixed geometry, W=I, Cartesian-state Toeplitz normal에 한정된다. 비균일/missing-angle weight에는 angular FFT 또는 추가 mode가 필요하다.",
    ]
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> dict[str, Any]:
    import torch

    n = int(args.n)
    if n != 256:
        raise ValueError("this production benchmark is frozen at N=256")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device(args.device)
    generic = load_generic_n256(args.generic_receipt)
    exact = load_n128_exact_gate(args.exact_receipt)

    detector = analytic_detector_geometry(args)
    centered, build = build_acfo_centered_complex64(args, detector, n)
    samples = signed_difference_samples(n, int(args.direct_check_count), int(args.seed) + 991)
    candidate_samples = centered[
        samples[:, 0] + n,
        samples[:, 1] + n,
        samples[:, 2] + n,
    ].copy()
    symbol, gpu_setup = gpu_symbol_from_centered(torch, centered, device)
    del centered
    gc.collect()
    hot = hot_apply(args, torch, symbol, device, n)
    direct = direct_q_check(args, samples, candidate_samples, n)

    total_setup = float(
        detector["setup_s"] + build["cpu_kernel_build_s"] + gpu_setup["gpu_setup_s"]
    )
    checksum_relative = float(
        abs(hot["output_norm_checksum"] - generic["output_norm_checksum"])
        / abs(generic["output_norm_checksum"])
    )
    geometry = {
        "variant": args.variant,
        "k_rad_per_um": float(args.k),
        "detector_na": float(args.detector_na),
        "illumination_angle_deg": float(args.illumination_angle_deg),
        "ring_illumination_count": int(args.ring_illum),
        "axis_illumination_count": 1,
        "q_count": int(build["center_value_real"]),
        "data_weights": "W=I",
    }
    gates = {
        "n128_complex128_full_gate": bool(
            exact["receipt_passed"] and exact["case_passed"]
        ),
        "n256_direct_q_sample_l2": bool(
            max(
                direct["metrics"]["sample_relative_l2"],
                direct["metrics"]["noncenter_sample_relative_l2"],
                direct["metrics"]["max_point_relative_error"],
            )
            <= float(args.complex64_tolerance)
        ),
        "n256_center": bool(
            abs(build["center_value_real"] - direct["q_count"])
            / direct["q_count"]
            <= float(args.complex64_tolerance)
            and build["center_value_imag"] == 0.0
        ),
        "q_geometry_hash_match": bool(
            direct["q_sha256_qx_qy_qz_float64"]
            == generic["q_sha256_qx_qy_qz_float64"]
        ),
        "checksum_compatible_with_approximate_generic_receipt": bool(
            checksum_relative <= float(args.checksum_comparison_tolerance)
        ),
        "gpu_memory_within_budget": bool(
            gpu_setup["peak_allocated_mib"]
            <= float(args.max_memory_fraction) * gpu_setup["total_before_mib"]
        ),
    }
    result = {
        "schema": "odt-acfo-toeplitz-symbol-gpu-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": bool(all(gates.values())),
        "geometry": geometry,
        "n": n,
        "shape": [n, n, n],
        "padded_shape": [2 * n, 2 * n, 2 * n],
        "dtype": "complex64",
        "device": {
            "name": torch.cuda.get_device_name(device),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
        },
        "factorization": "K(d)=D(d)I(d), finite uniform angular comb -> m=0 J0",
        "acfo_build": build,
        "gpu_symbol_setup": gpu_setup,
        "hot_apply": hot,
        "direct_q_check": direct,
        "n128_complex128_gate": exact,
        "generic_reference": generic,
        "alias": alias_report(args, detector, n),
        "timing_s": {
            "analytic_geometry": float(detector["setup_s"]),
            "cpu_kernel_build": float(build["cpu_kernel_build_s"]),
            "gpu_symbol_setup": float(gpu_setup["gpu_setup_s"]),
            "end_to_end_symbol_setup": total_setup,
            "validation_direct_q_excluded_from_setup": float(
                direct["timing_s"]["q_build"] + direct["timing_s"]["direct_sum"]
            ),
        },
        "comparison": {
            "symbol_setup_speedup": float(
                generic["generic_symbol_total_build_s"] / total_setup
            ),
            "hot_apply_time_ratio_vs_generic": float(
                hot["timing"]["median_s"] / generic["hot_apply_median_s"]
            ),
            "checksum_relative_difference": checksum_relative,
            "checksum_comparison_tolerance": float(
                args.checksum_comparison_tolerance
            ),
        },
        "gates": gates,
        "scope": [
            "fixed production ring-plus-axis geometry, uniform azimuth, W=I",
            "uniform Cartesian state and exact 2N Toeplitz embedding",
            "standalone benchmark; original cylindrical solver unchanged",
            "generic N=256 FINUFFT timing is loaded from its receipt, not rerun",
        ],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "platform": platform.platform(),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    del symbol
    gc.collect()
    torch.cuda.empty_cache()
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--n", type=int, default=256)
    p.add_argument("--seed", type=int, default=20260805)
    p.add_argument("--device", default="cuda")
    p.add_argument("--gather-chunk-x", type=int, default=8)
    p.add_argument("--direct-check-count", type=int, default=32)
    p.add_argument("--direct-point-chunk", type=int, default=8)
    p.add_argument("--direct-q-chunk", type=int, default=250000)
    p.add_argument("--gpu-warmups", type=int, default=2)
    p.add_argument("--gpu-repeats", type=int, default=10)
    p.add_argument("--complex64-tolerance", type=float, default=2e-6)
    p.add_argument(
        "--checksum-comparison-tolerance",
        type=float,
        default=2e-5,
        help=(
            "Compatibility tolerance against the old FINUFFT eps=1e-5 checksum; "
            "direct-q accuracy continues to use --complex64-tolerance."
        ),
    )
    p.add_argument("--max-memory-fraction", type=float, default=0.80)
    p.add_argument("--exact-receipt", type=Path, default=DEFAULT_EXACT_RECEIPT)
    p.add_argument("--generic-receipt", type=Path, default=DEFAULT_GENERIC_RECEIPT)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--summary", type=Path, default=DEFAULT_SUMMARY)
    return p


if __name__ == "__main__":
    arguments = parser().parse_args()
    payload = run(arguments)
    print(
        f"pass={payload['passed']} setup={payload['timing_s']['end_to_end_symbol_setup']:.3f}s "
        f"speedup={payload['comparison']['symbol_setup_speedup']:.2f}x "
        f"direct_rel_l2={payload['direct_q_check']['metrics']['sample_relative_l2']:.3e} "
        f"hot={1e3 * payload['hot_apply']['timing']['median_s']:.3f}ms"
    )
    print(f"wrote {arguments.output}")
    print(f"wrote {arguments.summary}")
