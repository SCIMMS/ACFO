#!/usr/bin/env python3
"""Aggregate independently produced ODT Toeplitz SI receipts."""

from __future__ import annotations

import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "benchmark_results" / "odt_toeplitz_si_aggregate.json"
DEFAULT_SUMMARY = ROOT / "benchmark_results" / "odt_toeplitz_si_aggregate_ko.md"


def load(path: Path, schema: str) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("schema") != schema:
        raise ValueError(
            f"unexpected receipt schema for {path}: {payload.get('schema')!r}"
        )
    return payload


def sample_values(payload: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    signature = payload["backend_result"]["output_signature"]
    indices = np.asarray(signature["sample_indices"], dtype=np.int64)
    pairs = np.asarray(signature["sample_values_real_imag"], dtype=np.float64)
    if pairs.ndim != 2 or pairs.shape[1] != 2:
        raise ValueError("invalid output sample array")
    values = np.ascontiguousarray(pairs).view(np.complex128).reshape(-1)
    return indices, values


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(reference)), np.finfo(float).tiny)
    return float(np.linalg.norm(candidate - reference) / denominator)


def scalar_relative(candidate: float, reference: float) -> float:
    return float(abs(candidate - reference) / max(abs(reference), np.finfo(float).tiny))


def break_even(setup_s: float, hot_s: float, baseline_hot_s: float) -> float | None:
    saving = float(baseline_hot_s - hot_s)
    if saving <= 0.0:
        return None
    return float(max(0.0, setup_s) / saving)


def total_time(setup_s: float, hot_s: float, applies: int, rebuild_every: int | None) -> float:
    if applies <= 0:
        raise ValueError("applies must be positive")
    rebuilds = 1 if rebuild_every is None else int(math.ceil(applies / rebuild_every))
    return float(rebuilds * setup_s + applies * hot_s)


def memory_value(payload: dict[str, Any], key: str) -> float | None:
    value = payload["backend_result"].get("memory", {}).get(key)
    return None if value is None else float(value)


def render_markdown(result: dict[str, Any]) -> str:
    methods = result["methods"]
    lines = [
        "# ODT Toeplitz SI matched comparison",
        "",
        f"- scientific correctness: `{'PASS' if result['scientific_correctness'] else 'FAIL'}`",
        f"- Toeplitz hot advantage: `{'PASS' if result['performance']['toeplitz_hot_advantage'] else 'FAIL'}`",
        f"- ACFO-derived setup advantage: `{'PASS' if result['performance']['acfo_setup_advantage'] else 'FAIL'}`",
        f"- disposition: `{result['research_disposition']}`",
        "",
        "| backend | setup s | hot normal ms | resident delta MiB |",
        "|---|---:|---:|---:|",
    ]
    for name in result["method_order"]:
        row = methods[name]
        memory = row["resident_delta_after_hot_mib"]
        memory_text = "n/a" if memory is None else f"{memory:.1f}"
        lines.append(
            f"| {name} | {row['method_setup_s']:.3f} | {1000.0 * row['hot_median_s']:.3f} | {memory_text} |"
        )
    accuracy = result["accuracy"]
    lines.extend(
        [
            "",
            "## Accuracy",
            "",
            f"- generic Toeplitz vs cuFINUFFT sampled rel-L2: `{accuracy['generic_vs_cufinufft_sample_relative_l2']:.3e}`",
            f"- ACFO Toeplitz vs cuFINUFFT sampled rel-L2: `{accuracy['acfo_vs_cufinufft_sample_relative_l2']:.3e}`",
            f"- ACFO Toeplitz vs generic Toeplitz sampled rel-L2: `{accuracy['acfo_vs_generic_sample_relative_l2']:.3e}`",
            "",
            "## Amortization",
            "",
            "The weight-update table assumes the cuFINUFFT q plans are reusable while a cached Toeplitz symbol is rebuilt. The per-sample W multiplication cost is not included.",
            "",
            "| total applies | rebuild interval | cuFINUFFT normal s | cuFINUFFT Toeplitz s | CPU-generic Toeplitz s | ACFO Toeplitz s | fastest |",
            "|---:|---:|---:|---:|---:|---:|---|",
        ]
    )
    for row in result["amortization"]["weight_update_scenarios"]:
        cu_toeplitz = row["total_s"].get("cufinufft-toeplitz")
        lines.append(
            "| {applies} | {interval} | {cu:.3f} | {cu_toeplitz} | {generic:.3f} | {acfo:.3f} | {fastest} |".format(
                applies=row["total_applies"],
                interval=row["rebuild_every_applies"],
                cu=row["total_s"]["cufinufft-normal"],
                cu_toeplitz="n/a" if cu_toeplitz is None else f"{cu_toeplitz:.3f}",
                generic=row["total_s"]["generic-toeplitz"],
                acfo=row["total_s"]["acfo-toeplitz"],
                fastest=row["fastest"],
            )
        )
    lines.extend(
        [
            "",
            "Scope: fixed linear Cartesian normal, production q geometry, complex64 GPU timing, and W=I. The weighted CPU gate separately validates three positive axisymmetric separable W updates. Arbitrary nonseparable W and nonlinear operator changes remain on the explicit-operator track.",
            "",
        ]
    )
    return "\n".join(lines)


def run(args: argparse.Namespace) -> dict[str, Any]:
    exact = load(args.exact, "odt-cartesian-toeplitz-exact-gate-v1")
    weighted = load(args.weighted, "odt-toeplitz-weighted-updates-v1")
    cg = load(args.cg, "odt-cartesian-toeplitz-cg-trajectory-v1")
    backend_paths = {
        "cufinufft-normal": args.cufinufft,
        "generic-toeplitz": args.generic,
        "acfo-toeplitz": args.acfo,
    }
    backends = {
        name: load(path, "odt-toeplitz-si-gpu-backend-v1")
        for name, path in backend_paths.items()
    }
    optional_gpu_generic = {
        "requested": args.cufinufft_toeplitz is not None,
        "available": False,
        "path": None
        if args.cufinufft_toeplitz is None
        else str(args.cufinufft_toeplitz),
        "reason": None,
    }
    if args.cufinufft_toeplitz is not None:
        if args.cufinufft_toeplitz.is_file():
            candidate = load(
                args.cufinufft_toeplitz, "odt-toeplitz-si-gpu-backend-v1"
            )
            if candidate.get("backend") != "cufinufft-toeplitz":
                raise ValueError("optional GPU generic backend identity mismatch")
            if candidate.get("passed"):
                backends["cufinufft-toeplitz"] = candidate
                backend_paths["cufinufft-toeplitz"] = args.cufinufft_toeplitz
                optional_gpu_generic["available"] = True
            else:
                optional_gpu_generic["reason"] = "receipt did not pass its local gates"
        else:
            optional_gpu_generic["reason"] = "receipt missing, typically because setup failed or exhausted memory"
    for name, payload in backends.items():
        if payload.get("backend") != name:
            raise ValueError(f"backend receipt identity mismatch: {name}")

    q_hashes = {
        exact["geometry"]["q_sha256_qx_qy_qz_float64"],
        weighted["geometry"]["q_sha256_qx_qy_qz_float64"],
        cg["geometry"]["q_sha256_qx_qy_qz_float64"],
        *(
            payload["geometry"]["q_sha256_qx_qy_qz_float64"]
            for payload in backends.values()
        ),
    }
    configurations = {
        (
            int(payload["configuration"]["n"]),
            payload["configuration"]["dtype"],
            payload["configuration"]["data_weights"],
        )
        for payload in backends.values()
    }
    indices: dict[str, np.ndarray] = {}
    samples: dict[str, np.ndarray] = {}
    for name, payload in backends.items():
        indices[name], samples[name] = sample_values(payload)
    sample_index_match = bool(
        all(
            np.array_equal(indices["cufinufft-normal"], value)
            for value in indices.values()
        )
    )
    accuracy = {
        "generic_vs_cufinufft_sample_relative_l2": relative_l2(
            samples["generic-toeplitz"], samples["cufinufft-normal"]
        ),
        "acfo_vs_cufinufft_sample_relative_l2": relative_l2(
            samples["acfo-toeplitz"], samples["cufinufft-normal"]
        ),
        "acfo_vs_generic_sample_relative_l2": relative_l2(
            samples["acfo-toeplitz"], samples["generic-toeplitz"]
        ),
        "generic_vs_cufinufft_norm_relative_error": scalar_relative(
            backends["generic-toeplitz"]["backend_result"]["output_signature"][
                "output_norm"
            ],
            backends["cufinufft-normal"]["backend_result"]["output_signature"][
                "output_norm"
            ],
        ),
        "acfo_vs_cufinufft_norm_relative_error": scalar_relative(
            backends["acfo-toeplitz"]["backend_result"]["output_signature"][
                "output_norm"
            ],
            backends["cufinufft-normal"]["backend_result"]["output_signature"][
                "output_norm"
            ],
        ),
    }
    if optional_gpu_generic["available"]:
        accuracy["cufinufft_toeplitz_vs_normal_sample_relative_l2"] = relative_l2(
            samples["cufinufft-toeplitz"], samples["cufinufft-normal"]
        )
        accuracy["cufinufft_toeplitz_vs_normal_norm_relative_error"] = scalar_relative(
            backends["cufinufft-toeplitz"]["backend_result"]["output_signature"][
                "output_norm"
            ],
            backends["cufinufft-normal"]["backend_result"]["output_signature"][
                "output_norm"
            ],
        )
    methods: dict[str, dict[str, Any]] = {}
    for name, payload in backends.items():
        backend = payload["backend_result"]
        methods[name] = {
            "method_setup_s": float(backend["method_setup_s"]),
            "first_ready_s": float(backend["first_ready_s"]),
            "hot_median_s": float(backend["hot_apply_timing"]["median_s"]),
            "resident_delta_after_hot_mib": memory_value(
                payload, "resident_delta_after_hot_mib"
            ),
            "process_peak_rss_mib": memory_value(payload, "process_peak_rss_mib"),
        }
    cu_hot = methods["cufinufft-normal"]["hot_median_s"]
    generic_hot = methods["generic-toeplitz"]["hot_median_s"]
    acfo_hot = methods["acfo-toeplitz"]["hot_median_s"]
    generic_setup_names = ["generic-toeplitz"]
    if optional_gpu_generic["available"]:
        generic_setup_names.append("cufinufft-toeplitz")
    strongest_generic_name = min(
        generic_setup_names, key=lambda name: methods[name]["method_setup_s"]
    )
    strongest_generic_setup = methods[strongest_generic_name]["method_setup_s"]
    performance = {
        "generic_toeplitz_hot_speedup_vs_cufinufft": float(cu_hot / generic_hot),
        "acfo_toeplitz_hot_speedup_vs_cufinufft": float(cu_hot / acfo_hot),
        "acfo_setup_speedup_vs_cpu_generic": float(
            methods["generic-toeplitz"]["method_setup_s"]
            / methods["acfo-toeplitz"]["method_setup_s"]
        ),
        "acfo_setup_speedup_vs_strongest_generic": float(
            strongest_generic_setup
            / methods["acfo-toeplitz"]["method_setup_s"]
        ),
        "strongest_generic_setup_backend": strongest_generic_name,
        "toeplitz_hot_advantage": bool(
            min(
                [cu_hot / generic_hot, cu_hot / acfo_hot]
                + (
                    [cu_hot / methods["cufinufft-toeplitz"]["hot_median_s"]]
                    if optional_gpu_generic["available"]
                    else []
                )
            ) > 1.0
        ),
        "acfo_setup_advantage": bool(
            methods["acfo-toeplitz"]["method_setup_s"]
            < strongest_generic_setup
        ),
    }
    if optional_gpu_generic["available"]:
        performance["cufinufft_toeplitz_hot_speedup_vs_cufinufft_normal"] = float(
            cu_hot / methods["cufinufft-toeplitz"]["hot_median_s"]
        )
    correctness_gates = {
        "all_source_receipts_passed": bool(
            exact.get("passed")
            and weighted.get("passed")
            and cg.get("passed")
            and all(payload.get("passed") for payload in backends.values())
        ),
        "q_geometry_hash_match": bool(len(q_hashes) == 1),
        "gpu_configuration_match": bool(len(configurations) == 1),
        "sample_index_match": sample_index_match,
        "sample_accuracy": bool(
            max(
                accuracy["generic_vs_cufinufft_sample_relative_l2"],
                accuracy["acfo_vs_cufinufft_sample_relative_l2"],
                accuracy["acfo_vs_generic_sample_relative_l2"],
                *(
                    [accuracy["cufinufft_toeplitz_vs_normal_sample_relative_l2"]]
                    if optional_gpu_generic["available"]
                    else []
                ),
            )
            <= float(args.gpu_sample_tolerance)
        ),
        "norm_accuracy": bool(
            max(
                accuracy["generic_vs_cufinufft_norm_relative_error"],
                accuracy["acfo_vs_cufinufft_norm_relative_error"],
                *(
                    [accuracy["cufinufft_toeplitz_vs_normal_norm_relative_error"]]
                    if optional_gpu_generic["available"]
                    else []
                ),
            )
            <= float(args.gpu_norm_tolerance)
        ),
    }
    scientific_correctness = bool(all(correctness_gates.values()))

    counts = [int(value) for value in args.apply_counts.split(",") if value.strip()]
    intervals = [
        int(value) for value in args.rebuild_intervals.split(",") if value.strip()
    ]
    if not counts or not intervals or min(counts + intervals) <= 0:
        raise ValueError("apply counts and rebuild intervals must be positive")
    weight_rows: list[dict[str, Any]] = []
    for applies in counts:
        for interval in intervals:
            if interval > applies:
                continue
            total = {
                "cufinufft-normal": float(
                    methods["cufinufft-normal"]["method_setup_s"] + applies * cu_hot
                ),
                "generic-toeplitz": total_time(
                    methods["generic-toeplitz"]["method_setup_s"],
                    generic_hot,
                    applies,
                    interval,
                ),
                "acfo-toeplitz": total_time(
                    methods["acfo-toeplitz"]["method_setup_s"],
                    acfo_hot,
                    applies,
                    interval,
                ),
            }
            if optional_gpu_generic["available"]:
                total["cufinufft-toeplitz"] = total_time(
                    methods["cufinufft-toeplitz"]["method_setup_s"],
                    methods["cufinufft-toeplitz"]["hot_median_s"],
                    applies,
                    interval,
                )
            weight_rows.append(
                {
                    "total_applies": applies,
                    "rebuild_every_applies": interval,
                    "total_s": total,
                    "fastest": min(total, key=total.get),
                }
            )
    amortization = {
        "fixed_operator_break_even_applies_vs_cufinufft": {
            "generic-toeplitz": break_even(
                methods["generic-toeplitz"]["method_setup_s"], generic_hot, cu_hot
            ),
            "acfo-toeplitz": break_even(
                methods["acfo-toeplitz"]["method_setup_s"], acfo_hot, cu_hot
            ),
        },
        "weight_rebuild_break_even_interval_applies": {
            "generic-toeplitz": break_even(
                methods["generic-toeplitz"]["method_setup_s"], generic_hot, cu_hot
            ),
            "acfo-toeplitz": break_even(
                methods["acfo-toeplitz"]["method_setup_s"], acfo_hot, cu_hot
            ),
        },
        "weight_update_assumption": (
            "cuFINUFFT q plans are reused and only diagonal W values change; "
            "each Toeplitz method rebuilds its cached symbol"
        ),
        "weight_update_scenarios": weight_rows,
    }
    if optional_gpu_generic["available"]:
        for key in (
            "fixed_operator_break_even_applies_vs_cufinufft",
            "weight_rebuild_break_even_interval_applies",
        ):
            amortization[key]["cufinufft-toeplitz"] = break_even(
                methods["cufinufft-toeplitz"]["method_setup_s"],
                methods["cufinufft-toeplitz"]["hot_median_s"],
                cu_hot,
            )
    if scientific_correctness and performance["toeplitz_hot_advantage"] and performance["acfo_setup_advantage"]:
        disposition = "two_track_validated"
    elif scientific_correctness:
        disposition = "correct_but_performance_not_compelling"
    else:
        disposition = "not_validated"
    result = {
        "schema": "odt-toeplitz-si-aggregate-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scientific_correctness": scientific_correctness,
        "research_disposition": disposition,
        "source_paths": {
            "exact": str(args.exact),
            "weighted": str(args.weighted),
            "cg": str(args.cg),
            **{name: str(path) for name, path in backend_paths.items()},
        },
        "configuration": {
            "gpu_sample_tolerance": float(args.gpu_sample_tolerance),
            "gpu_norm_tolerance": float(args.gpu_norm_tolerance),
            "q_geometry_sha256": next(iter(q_hashes)) if len(q_hashes) == 1 else None,
            "gpu_backend_configuration": [list(value) for value in sorted(configurations)],
        },
        "correctness_gates": correctness_gates,
        "accuracy": accuracy,
        "methods": methods,
        "method_order": [
            name
            for name in (
                "cufinufft-normal",
                "cufinufft-toeplitz",
                "generic-toeplitz",
                "acfo-toeplitz",
            )
            if name in methods
        ],
        "optional_gpu_generic": optional_gpu_generic,
        "performance": performance,
        "amortization": amortization,
        "supporting_gates": {
            "exact_toeplitz": exact["exact_gate"].get("metrics"),
            "weighted_cases": [
                {
                    "n": case["n"],
                    "profile": case["profile"],
                    "kernel_relative_l2": case["metrics"]["kernel_relative_l2"],
                    "symbol_relative_l2": case["metrics"]["symbol_relative_l2"],
                    "rebuild_speedup": case["comparison"][
                        "generic_over_factorized_rebuild_speedup"
                    ],
                }
                for case in weighted["cases"]
            ],
            "cg_trajectory": cg["trajectory_summary"],
        },
        "claim_boundary": [
            "cuFINUFFT remains the general explicit A/A* baseline",
            "Toeplitz is a fixed-normal specialized hot-speed baseline",
            "ACFO-derived setup applies only to the declared axisymmetric separable weights",
            "arbitrary nonseparable weights, residual formation, and nonlinear updates remain on the explicit-operator track",
            "device residency deltas are primary cross-allocator memory observations; allocator-specific peaks are retained in raw receipts",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--exact", type=Path, required=True)
    p.add_argument("--weighted", type=Path, required=True)
    p.add_argument("--cg", type=Path, required=True)
    p.add_argument("--cufinufft", type=Path, required=True)
    p.add_argument("--cufinufft-toeplitz", type=Path)
    p.add_argument("--generic", type=Path, required=True)
    p.add_argument("--acfo", type=Path, required=True)
    p.add_argument("--gpu-sample-tolerance", type=float, default=2e-4)
    p.add_argument("--gpu-norm-tolerance", type=float, default=2e-4)
    p.add_argument("--apply-counts", default="1,10,100,1000")
    p.add_argument("--rebuild-intervals", default="1,10,100,1000")
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--summary", type=Path, default=DEFAULT_SUMMARY)
    return p


def main() -> None:
    args = parser().parse_args()
    result = run(args)
    print(
        json.dumps(
            {
                "scientific_correctness": result["scientific_correctness"],
                "research_disposition": result["research_disposition"],
                "performance": result["performance"],
                "output": str(args.output),
                "summary": str(args.summary),
            },
            indent=2,
        )
    )
    if not result["scientific_correctness"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
