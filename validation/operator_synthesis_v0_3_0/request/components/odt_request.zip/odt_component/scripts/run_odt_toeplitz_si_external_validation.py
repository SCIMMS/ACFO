#!/usr/bin/env python3
"""Run the frozen ODT Toeplitz SI external validation and package its return."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any


sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_NAME = "odt_toeplitz_si_rtx3090_validation_request_v1"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
os.environ.setdefault(
    "CUPY_CACHE_DIR", str(ROOT.parent / f".{PACKAGE_NAME}_cupy_cache")
)
PROTOCOL_NAME = "ODT_TOEPLITZ_SI_RTX3090_PROTOCOL.json"
MANIFEST_NAME = "PACKAGE_MANIFEST.json"
PROVENANCE_NAME = "REQUEST_PROVENANCE.json"
RETURN_ROOT_NAME = "odt_toeplitz_si_external_return"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_row(path: Path) -> dict[str, Any]:
    return {"bytes": int(path.stat().st_size), "sha256": sha256(path)}


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError(f"JSON root is not an object: {path}")
    return payload


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def verify_request_manifest(root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {
        "schema": "odt-toeplitz-si-request-preflight-v1",
        "passed": False,
        "errors": [],
    }
    try:
        manifest_path = root / MANIFEST_NAME
        manifest = load_json(manifest_path)
        if manifest.get("schema") != "odt-toeplitz-si-request-manifest-v1":
            result["errors"].append("request manifest schema mismatch")
        records = manifest.get("files")
        if not isinstance(records, dict):
            raise TypeError("request manifest files is not an object")
        expected = set(records)
        observed = {
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file() and path.name != MANIFEST_NAME
        }
        result["missing"] = sorted(expected - observed)
        result["unexpected"] = sorted(observed - expected)
        mismatched: list[dict[str, Any]] = []
        for relative in sorted(expected & observed):
            pure = PurePosixPath(relative)
            if pure.is_absolute() or ".." in pure.parts or "\\" in relative:
                mismatched.append({"path": relative, "error": "unsafe path"})
                continue
            path = root / Path(*pure.parts)
            observed_row = file_row(path)
            expected_row = records[relative]
            if observed_row != expected_row:
                mismatched.append(
                    {
                        "path": relative,
                        "expected": expected_row,
                        "observed": observed_row,
                    }
                )
        result["mismatched"] = mismatched
        protocol_hash = sha256(root / PROTOCOL_NAME)
        provenance_hash = sha256(root / PROVENANCE_NAME)
        result["manifest_sha256"] = sha256(manifest_path)
        result["protocol_sha256"] = protocol_hash
        result["provenance_sha256"] = provenance_hash
        result["protocol_anchor_matches"] = bool(
            manifest.get("protocol_sha256") == protocol_hash
        )
        result["provenance_anchor_matches"] = bool(
            manifest.get("provenance_sha256") == provenance_hash
        )
        result["manifest_schema"] = manifest.get("schema")
        result["file_count"] = len(records)
        result["passed"] = bool(
            manifest.get("schema") == "odt-toeplitz-si-request-manifest-v1"
            and not result["missing"]
            and not result["unexpected"]
            and not mismatched
            and result["protocol_anchor_matches"]
            and result["provenance_anchor_matches"]
        )
    except Exception as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
    return result


def capture_command(
    command: list[str], log_path: Path, *, cwd: Path = ROOT
) -> dict[str, Any]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = utc_now()
    start = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
        )
        text = completed.stdout
        returncode = int(completed.returncode)
        error = None
    except Exception as exception:
        text = f"{type(exception).__name__}: {exception}\n"
        returncode = 127
        error = text.strip()
    log_path.write_text(text, encoding="utf-8")
    return {
        "command": command,
        "started_at_utc": started,
        "elapsed_s": float(time.perf_counter() - start),
        "returncode": returncode,
        "log": str(log_path),
        "log_sha256": sha256(log_path),
        "error": error,
    }


def command_text(command: list[str]) -> str:
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
            timeout=30,
        )
        return completed.stdout
    except Exception as error:
        return f"{type(error).__name__}: {error}\n"


def package_versions(names: list[str]) -> dict[str, Any]:
    versions: dict[str, Any] = {}
    for name in names:
        try:
            module = importlib.import_module(name)
            versions[name] = {
                "available": True,
                "version": getattr(module, "__version__", None),
                "file": getattr(module, "__file__", None),
            }
        except Exception as error:
            versions[name] = {
                "available": False,
                "error": f"{type(error).__name__}: {error}",
            }
    return versions


def capture_environment(return_root: Path) -> dict[str, Any]:
    environment_dir = return_root / "environment"
    environment_dir.mkdir(parents=True, exist_ok=True)
    nvidia_smi = command_text(
        [
            "nvidia-smi",
            "--query-gpu=name,memory.total,driver_version",
            "--format=csv,noheader",
        ]
    )
    (environment_dir / "nvidia_smi.txt").write_text(nvidia_smi, encoding="utf-8")
    pip_freeze = command_text([sys.executable, "-m", "pip", "freeze"])
    (environment_dir / "pip_freeze.txt").write_text(pip_freeze, encoding="utf-8")
    disk = shutil.disk_usage(ROOT)
    if os.name == "nt":
        try:
            from benchmark_odt_cufinufft_gpu_baseline import (
                add_gpu_dll_directories,
            )

            add_gpu_dll_directories()
        except Exception:
            pass
    packages = package_versions(
        ["numpy", "scipy", "finufft", "torch", "cupy", "cufinufft"]
    )
    cuda_available = False
    torch_device = None
    torch_memory = None
    try:
        import torch

        cuda_available = bool(torch.cuda.is_available())
        if cuda_available:
            torch_device = torch.cuda.get_device_name(0)
            torch_memory = int(torch.cuda.get_device_properties(0).total_memory)
    except Exception:
        pass
    environment = {
        "schema": "odt-toeplitz-si-environment-v1",
        "captured_at_utc": utc_now(),
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "packages": packages,
        "cuda_available": cuda_available,
        "torch_device_name": torch_device,
        "torch_device_total_bytes": torch_memory,
        "nvidia_smi": nvidia_smi.strip().splitlines(),
        "disk_free_bytes": int(disk.free),
        "environment_variables": {
            name: os.environ.get(name)
            for name in (
                "OMP_NUM_THREADS",
                "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "WAXS_CPP_EXTENSIONS",
                "WAXS_CPP_OPT",
            )
        },
    }
    write_json(environment_dir / "environment.json", environment)
    return environment


def environment_eligible(
    environment: dict[str, Any], *, allow_non_rtx3090: bool
) -> dict[str, Any]:
    required = ["numpy", "scipy", "finufft", "torch", "cupy", "cufinufft"]
    imports = environment.get("packages", {})
    all_imports = bool(
        all(imports.get(name, {}).get("available") for name in required)
    )
    device = str(environment.get("torch_device_name") or "")
    rtx3090 = "RTX 3090" in device.upper()
    memory = int(environment.get("torch_device_total_bytes") or 0)
    memory_ok = memory >= 22 * 1024**3
    disk_ok = int(environment.get("disk_free_bytes") or 0) >= 12 * 1024**3
    passed = bool(
        all_imports
        and environment.get("cuda_available")
        and disk_ok
        and (allow_non_rtx3090 or (rtx3090 and memory_ok))
    )
    return {
        "passed": passed,
        "all_required_imports": all_imports,
        "cuda_available": bool(environment.get("cuda_available")),
        "rtx3090_name_match": rtx3090,
        "at_least_22_gib_vram": memory_ok,
        "at_least_12_gib_free_disk": disk_ok,
        "allow_non_rtx3090": bool(allow_non_rtx3090),
    }


def stage_specifications(
    protocol: dict[str, Any], mode: str, return_root: Path
) -> list[dict[str, Any]]:
    stages = protocol["execution"]["full_stages"]
    smoke = protocol["execution"]["smoke_overrides"]
    result: list[dict[str, Any]] = []
    for original in stages[:-1]:
        stage = json.loads(json.dumps(original))
        arguments = list(stage.get("arguments", []))
        if mode == "smoke":
            if stage["id"] == "stage2_weighted_updates":
                arguments = replace_option(arguments, "--sizes", str(smoke["weighted_sizes"]))
            elif stage["id"] == "stage3_cg_trajectory":
                arguments = replace_option(
                    arguments, "--iterations", str(smoke["cg_iterations"])
                )
            elif stage["id"].startswith(("stage4_", "stage5_", "stage6_", "stage7_")):
                arguments = replace_option(arguments, "--n", str(smoke["gpu_n"]))
                arguments = replace_option(
                    arguments, "--warmups", str(smoke["gpu_warmups"])
                )
                arguments = replace_option(
                    arguments, "--repeats", str(smoke["gpu_repeats"])
                )
                arguments = replace_option(
                    arguments, "--sample-count", str(smoke["gpu_sample_count"])
                )
        receipt = return_root / stage["receipt"]
        arguments.extend(["--output", str(receipt)])
        if stage.get("summary"):
            arguments.extend(["--summary", str(return_root / stage["summary"])])
        stage["arguments"] = arguments
        result.append(stage)
    return result


def replace_option(arguments: list[str], option: str, value: str) -> list[str]:
    updated = list(arguments)
    if option not in updated:
        updated.extend([option, value])
        return updated
    index = updated.index(option)
    if index + 1 >= len(updated):
        raise ValueError(f"option {option} has no value")
    updated[index + 1] = value
    return updated


def inspect_receipt(stage: dict[str, Any], return_root: Path) -> dict[str, Any]:
    path = return_root / stage["receipt"]
    result: dict[str, Any] = {
        "path": str(path),
        "exists": path.is_file(),
        "schema": None,
        "schema_matches": False,
        "payload_passed": None,
        "backend_matches": None,
        "sha256": None,
        "error": None,
    }
    if not path.is_file():
        return result
    try:
        payload = load_json(path)
        result["schema"] = payload.get("schema")
        result["schema_matches"] = bool(
            payload.get("schema") == stage.get("required_schema")
        )
        result["payload_passed"] = payload.get("passed")
        expected_backend = None
        arguments = stage.get("arguments", [])
        if "--backend" in arguments:
            expected_backend = arguments[arguments.index("--backend") + 1]
            result["backend_matches"] = bool(
                payload.get("backend") == expected_backend
            )
        result["sha256"] = sha256(path)
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def run_aggregate(
    return_root: Path, stages: list[dict[str, Any]]
) -> dict[str, Any]:
    by_id = {stage["id"]: stage for stage in stages}
    paths = {
        stage_id: return_root / by_id[stage_id]["receipt"]
        for stage_id in by_id
    }
    command = [
        sys.executable,
        str(ROOT / "scripts" / "aggregate_odt_toeplitz_si.py"),
        "--exact",
        str(paths["stage1_exact_complex128"]),
        "--weighted",
        str(paths["stage2_weighted_updates"]),
        "--cg",
        str(paths["stage3_cg_trajectory"]),
        "--cufinufft",
        str(paths["stage4_cufinufft_normal"]),
        "--generic",
        str(paths["stage6_cpu_generic_toeplitz"]),
        "--acfo",
        str(paths["stage7_acfo_toeplitz"]),
        "--output",
        str(return_root / "aggregate" / "ODT_TOEPLITZ_SI_AGGREGATE.json"),
        "--summary",
        str(return_root / "aggregate" / "ODT_TOEPLITZ_SI_AGGREGATE_ko.md"),
    ]
    optional = paths["stage5_cufinufft_toeplitz"]
    if optional.is_file():
        command.extend(["--cufinufft-toeplitz", str(optional)])
    return capture_command(
        command, return_root / "logs" / "stage8_aggregate.log"
    )


def write_request_anchor(return_root: Path, preflight: dict[str, Any]) -> None:
    anchor = {
        "schema": "odt-toeplitz-si-request-anchor-v1",
        "request_package_name": PACKAGE_NAME,
        "request_manifest_sha256": preflight.get("manifest_sha256"),
        "protocol_sha256": preflight.get("protocol_sha256"),
        "provenance_sha256": preflight.get("provenance_sha256"),
        "runner_sha256": sha256(Path(__file__).resolve()),
    }
    write_json(return_root / "REQUEST_ANCHOR.json", anchor)


def copy_request_evidence(return_root: Path) -> None:
    target = return_root / "request_evidence"
    target.mkdir(parents=True, exist_ok=True)
    for name in (PROTOCOL_NAME, MANIFEST_NAME, PROVENANCE_NAME):
        source = ROOT / name
        if source.is_file():
            shutil.copy2(source, target / name)


def write_return_manifest(return_root: Path) -> dict[str, Any]:
    files: dict[str, dict[str, Any]] = {}
    for path in sorted(return_root.rglob("*")):
        if path.is_file() and path.name != "RETURN_MANIFEST.json":
            relative = path.relative_to(return_root).as_posix()
            pure = PurePosixPath(relative)
            if pure.is_absolute() or ".." in pure.parts or "\\" in relative:
                raise RuntimeError(f"unsafe return member {relative}")
            files[relative] = file_row(path)
    manifest = {
        "schema": "odt-toeplitz-si-return-manifest-v1",
        "generated_at_utc": utc_now(),
        "return_root": RETURN_ROOT_NAME,
        "files": files,
    }
    write_json(return_root / "RETURN_MANIFEST.json", manifest)
    return manifest


def write_return_archive(return_root: Path) -> dict[str, Any]:
    archive_path = return_root.parent / f"{RETURN_ROOT_NAME}.zip"
    sidecar_path = Path(str(archive_path) + ".sha256")
    if archive_path.exists():
        archive_path.unlink()
    if sidecar_path.exists():
        sidecar_path.unlink()
    with zipfile.ZipFile(
        archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for path in sorted(return_root.rglob("*")):
            if path.is_file():
                member = (Path(RETURN_ROOT_NAME) / path.relative_to(return_root)).as_posix()
                archive.write(path, member)
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"return ZIP CRC failed at {bad}")
    digest = sha256(archive_path)
    sidecar_path.write_text(
        f"{digest}  {archive_path.name}\n", encoding="utf-8", newline="\n"
    )
    return {
        "archive": str(archive_path),
        "archive_bytes": int(archive_path.stat().st_size),
        "archive_sha256": digest,
        "sha256_sidecar": str(sidecar_path),
        "sha256_sidecar_sha256": sha256(sidecar_path),
    }


def run(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    protocol = load_json(ROOT / PROTOCOL_NAME)
    if protocol.get("schema") != "odt-toeplitz-si-rtx3090-protocol-v1":
        raise ValueError("unexpected protocol schema")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_parent = (
        args.run_parent.resolve()
        if args.run_parent is not None
        else ROOT.parent / f"{PACKAGE_NAME}_external_runs"
    )
    run_dir = run_parent / stamp
    return_root = run_dir / RETURN_ROOT_NAME
    return_root.mkdir(parents=True, exist_ok=False)
    if args.allow_unpackaged_workspace and not (ROOT / MANIFEST_NAME).is_file():
        preflight = {
            "schema": "odt-toeplitz-si-request-preflight-v1",
            "passed": True,
            "workspace_bypass": True,
            "manifest_sha256": None,
            "protocol_sha256": sha256(ROOT / PROTOCOL_NAME),
            "provenance_sha256": None,
            "errors": [],
        }
    else:
        preflight = verify_request_manifest(ROOT)
    write_json(return_root / "request_preflight.json", preflight)
    write_request_anchor(return_root, preflight)
    copy_request_evidence(return_root)
    environment = capture_environment(return_root)
    eligibility = environment_eligible(
        environment, allow_non_rtx3090=bool(args.allow_non_rtx3090)
    )
    write_json(return_root / "environment" / "eligibility.json", eligibility)

    build_row: dict[str, Any]
    if args.skip_build or not args.build_extension:
        build_row = {
            "skipped": True,
            "returncode": 0,
            "reason": (
                "--skip-build"
                if args.skip_build
                else "pure-Python Toeplitz SI path; compiled ODT extension not required"
            ),
        }
        (return_root / "logs" / "build_extension.log").parent.mkdir(
            parents=True, exist_ok=True
        )
        (return_root / "logs" / "build_extension.log").write_text(
            "build skipped by explicit runner option\n", encoding="utf-8"
        )
    else:
        build_row = capture_command(
            [sys.executable, "setup.py", "build_ext", "--inplace"],
            return_root / "logs" / "build_extension.log",
        )
    stages = stage_specifications(protocol, args.mode, return_root)
    stage_rows: list[dict[str, Any]] = []
    can_run = bool(preflight.get("passed") and eligibility.get("passed") and build_row["returncode"] == 0)
    for stage in stages:
        log_path = return_root / "logs" / f"{stage['id']}.log"
        if can_run:
            command = [
                sys.executable,
                str(ROOT / stage["script"]),
                *stage["arguments"],
            ]
            execution = capture_command(command, log_path)
        else:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text(
                "stage skipped because request preflight, environment, or build failed\n",
                encoding="utf-8",
            )
            execution = {
                "command": [],
                "started_at_utc": utc_now(),
                "elapsed_s": 0.0,
                "returncode": 125,
                "log": str(log_path),
                "log_sha256": sha256(log_path),
                "error": "prerequisite failure",
            }
        receipt = inspect_receipt(stage, return_root)
        required_pass = bool(stage.get("required_pass", True))
        stage_ok = bool(
            execution["returncode"] == 0
            and receipt["exists"]
            and receipt["schema_matches"]
            and (not required_pass or receipt["payload_passed"] is True)
            and (receipt["backend_matches"] is not False)
        )
        stage_rows.append(
            {
                "id": stage["id"],
                "required_pass": required_pass,
                "execution": execution,
                "receipt": receipt,
                "stage_ok": stage_ok,
            }
        )

    aggregate_execution = run_aggregate(return_root, stages) if can_run else None
    aggregate_path = return_root / "aggregate" / "ODT_TOEPLITZ_SI_AGGREGATE.json"
    aggregate = load_json(aggregate_path) if aggregate_path.is_file() else None
    required_stage_ok = bool(
        all(row["stage_ok"] for row in stage_rows if row["required_pass"])
    )
    optional_gpu_generic = next(
        row for row in stage_rows if row["id"] == "stage5_cufinufft_toeplitz"
    )
    scientific_correctness = bool(
        can_run
        and required_stage_ok
        and aggregate_execution is not None
        and aggregate_execution["returncode"] == 0
        and aggregate is not None
        and aggregate.get("scientific_correctness") is True
    )
    performance_compelling = bool(
        aggregate is not None
        and aggregate.get("performance", {}).get("toeplitz_hot_advantage") is True
        and aggregate.get("performance", {}).get("acfo_setup_advantage") is True
    )
    aggregate_result = {
        "schema": "odt-toeplitz-si-external-run-result-v1",
        "generated_at_utc": utc_now(),
        "mode": args.mode,
        "request_integrity": bool(preflight.get("passed")),
        "environment_eligible": bool(eligibility.get("passed")),
        "build_passed": bool(build_row["returncode"] == 0),
        "scientific_correctness": scientific_correctness,
        "performance_compelling": performance_compelling,
        "research_disposition": (
            aggregate.get("research_disposition")
            if aggregate is not None
            else "not_validated"
        ),
        "optional_gpu_generic_setup": {
            "completed": bool(optional_gpu_generic["stage_ok"]),
            "failure_is_memory_evidence_not_integrity_failure": True,
        },
        "preflight": preflight,
        "eligibility": eligibility,
        "build": build_row,
        "stages": stage_rows,
        "aggregate_execution": aggregate_execution,
        "aggregate": aggregate,
    }
    write_json(return_root / "AGGREGATE_RESULT.json", aggregate_result)
    manifest = write_return_manifest(return_root)
    archive = write_return_archive(return_root)
    output = {
        "schema": "odt-toeplitz-si-external-run-console-v1",
        "mode": args.mode,
        "run_dir": str(run_dir),
        "return_root": str(return_root),
        "return_manifest_sha256": sha256(return_root / "RETURN_MANIFEST.json"),
        "manifested_file_count": len(manifest["files"]),
        "request_integrity": aggregate_result["request_integrity"],
        "scientific_correctness": scientific_correctness,
        "performance_compelling": performance_compelling,
        "research_disposition": aggregate_result["research_disposition"],
        **archive,
    }
    exit_code = 0 if scientific_correctness else 2
    return output, exit_code


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mode", choices=["smoke", "full"], default="full")
    p.add_argument(
        "--allow-non-rtx3090",
        action="store_true",
        help="Permit local plumbing smoke on another CUDA GPU; never use for the publication run.",
    )
    p.add_argument(
        "--skip-build",
        action="store_true",
        help="Use an already-built local extension; intended only for workspace smoke.",
    )
    p.add_argument(
        "--build-extension",
        action="store_true",
        help="Optionally build the ODT extension; the frozen SI path does not require it.",
    )
    p.add_argument(
        "--allow-unpackaged-workspace",
        action="store_true",
        help="Bypass package-manifest preflight only for a local workspace smoke.",
    )
    p.add_argument(
        "--run-parent",
        type=Path,
        help="Override the parent directory for timestamped runs; useful for local smoke.",
    )
    return p


def main() -> None:
    output, exit_code = run(parser().parse_args())
    print(json.dumps(output, ensure_ascii=False, indent=2))
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
