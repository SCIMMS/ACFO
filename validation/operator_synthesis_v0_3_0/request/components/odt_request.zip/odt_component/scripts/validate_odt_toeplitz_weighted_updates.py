#!/usr/bin/env python3
"""Validate and time ACFO-derived Toeplitz rebuilds for structured W updates.

The normal kernel for a Cartesian ODT state is

    K_W(d) = sum_j w_j exp(+i q_j . d).

For the frozen detector x illumination acquisition and weights of the form
``w(detector, illumination)=w_d(detector) w_i(illumination)``, the kernel
factors into detector and illumination sums.  This script compares that
factorized build against an independent FINUFFT type-1 build for three
predeclared positive weight profiles.  Arbitrary nonseparable weights are
explicitly outside this gate.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import fft as scipy_fft
from scipy import special


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from benchmark_odt_acfo_toeplitz_symbol_build import (  # noqa: E402
    analytic_detector_geometry,
    unique_lateral_radii,
)
from benchmark_odt_cartesian_toeplitz_exact_gate import (  # noqa: E402
    cartesian_spacing,
    create_finufft_plan,
    production_q_geometry,
    scaled_finufft_coordinates,
)
from benchmark_odt_banded_cartesian_final_packed import VARIANTS  # noqa: E402


DEFAULT_OUTPUT = (
    ROOT / "benchmark_results" / "odt_toeplitz_weighted_updates_20260806.json"
)
DEFAULT_SUMMARY = (
    ROOT / "benchmark_results" / "odt_toeplitz_weighted_updates_20260806_ko.md"
)


def timed(callback: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = callback()
    return value, float(time.perf_counter() - start)


def parse_sizes(text: str) -> list[int]:
    sizes = sorted({int(value.strip()) for value in text.split(",") if value.strip()})
    if not sizes or any(value <= 0 for value in sizes):
        raise ValueError("sizes must contain positive integers")
    return sizes


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(reference.ravel())), np.finfo(float).tiny)
    return float(np.linalg.norm((candidate - reference).ravel()) / denominator)


def array_sha256(arrays: list[np.ndarray]) -> str:
    digest = hashlib.sha256()
    for array in arrays:
        contiguous = np.ascontiguousarray(array)
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(np.asarray(contiguous.shape, dtype=np.int64).tobytes())
        digest.update(contiguous.view(np.uint8))
    return digest.hexdigest()


def profile_parameters(
    name: str, detector: dict[str, Any], detector_na: float
) -> dict[str, Any]:
    radial = np.asarray(detector["radial"], dtype=np.float64)
    if name == "unity":
        detector_weight = np.ones_like(radial)
        ring_weight, axis_weight = 1.0, 1.0
    elif name == "radial_apodized":
        normalized = np.clip(radial / float(detector_na), 0.0, 1.0)
        detector_weight = 0.25 + 0.75 * (1.0 - normalized**2) ** 2
        ring_weight, axis_weight = 1.0, 1.0
    elif name == "source_and_band_reweighted":
        detector_weight = np.ones_like(radial)
        offset = 0
        for band_index, band in enumerate(detector["bands"]):
            count = int(band["cap_radial"])
            detector_weight[offset : offset + count] *= 1.15 if band_index == 0 else 0.65
            offset += count
        ring_weight, axis_weight = 0.7, 1.4
    else:
        raise ValueError(f"unknown profile {name!r}")
    return {
        "name": name,
        "detector_weight": np.ascontiguousarray(detector_weight),
        "ring_weight": float(ring_weight),
        "axis_weight": float(axis_weight),
        "minimum_weight": float(
            detector_weight.min() * min(ring_weight, axis_weight)
        ),
        "maximum_weight": float(
            detector_weight.max() * max(ring_weight, axis_weight)
        ),
    }


def q_weight_vector(
    args: argparse.Namespace,
    detector: dict[str, Any],
    profile: dict[str, Any],
) -> np.ndarray:
    parts: list[np.ndarray] = []
    offset = 0
    for specification in VARIANTS[args.variant]:
        radial_count = int(specification["cap_radial"])
        cap_phi = int(specification["cap_phi"])
        detector_weight = profile["detector_weight"][offset : offset + radial_count]
        one_illumination = np.repeat(detector_weight, cap_phi)
        parts.append(
            np.tile(one_illumination, int(args.ring_illum))
            * float(profile["ring_weight"])
        )
        parts.append(one_illumination * float(profile["axis_weight"]))
        offset += radial_count
    result = np.ascontiguousarray(np.concatenate(parts), dtype=np.float64)
    return result


def build_factorized_centered(
    args: argparse.Namespace,
    detector: dict[str, Any],
    profile: dict[str, Any],
    n: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    spacing = cartesian_spacing(args, n)
    radii_data, radius_s = timed(lambda: unique_lateral_radii(n, spacing[0]))
    differences = radii_data["differences"]
    radii = radii_data["radii"]
    inverse = radii_data["inverse"]
    z = np.ascontiguousarray(differences.astype(np.float64) * spacing[2])
    k = float(args.k)
    ring_na = math.sin(math.radians(float(args.illumination_angle_deg)))
    ring_sz = math.sqrt(max(1.0 - ring_na * ring_na, 0.0))

    def tables() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        detector_j0 = special.j0(
            k * radii[:, None] * detector["radial"][None, :]
        )
        detector_j0 *= (
            detector["multiplicity"] * profile["detector_weight"]
        )[None, :]
        detector_z = np.exp(
            1j * k * detector["axial"][:, None] * z[None, :]
        )
        illumination_j0 = special.j0(k * ring_na * radii)
        return detector_j0, detector_z, illumination_j0

    (detector_j0, detector_z, illumination_j0), tables_s = timed(tables)
    detector_sum, contraction_s = timed(lambda: detector_j0 @ detector_z)
    del detector_j0, detector_z
    illumination_sum = (
        float(args.ring_illum)
        * float(profile["ring_weight"])
        * illumination_j0[:, None]
        * np.exp(-1j * k * ring_sz * z)[None, :]
        + float(profile["axis_weight"])
        * np.exp(-1j * k * z)[None, :]
    )
    psf_table, product_s = timed(lambda: detector_sum * illumination_sum)
    del detector_sum, illumination_sum, illumination_j0
    side = 2 * n - 1

    def gather() -> np.ndarray:
        signed = psf_table[inverse.reshape(-1), :].reshape(side, side, side)
        centered = np.zeros((2 * n, 2 * n, 2 * n), dtype=np.complex128)
        centered[1:, 1:, 1:] = signed
        return np.ascontiguousarray(centered)

    centered, gather_s = timed(gather)
    center = centered[n, n, n]
    del psf_table
    gc.collect()
    timing = {
        "unique_radius_setup": radius_s,
        "bessel_and_axial_tables": tables_s,
        "radial_axial_contraction": contraction_s,
        "detector_illumination_product": product_s,
        "signed_difference_gather": gather_s,
    }
    return centered, {
        "timing_s": timing,
        "kernel_build_s": float(sum(timing.values())),
        "unique_lateral_radius_count": int(radii.size),
        "signed_lateral_point_count": int(side * side),
        "radius_reuse_factor": float(side * side / radii.size),
        "center_value": [float(center.real), float(center.imag)],
    }


def build_generic_centered(
    args: argparse.Namespace,
    q: dict[str, Any],
    weights: np.ndarray,
    n: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    import finufft

    spacing = cartesian_spacing(args, n)
    (qx, qy, qz, coordinate_max), coordinate_s = timed(
        lambda: scaled_finufft_coordinates(
            q, spacing, real_dtype=np.dtype(np.float64)
        )
    )
    plan, plan_s = create_finufft_plan(
        finufft,
        1,
        (2 * n, 2 * n, 2 * n),
        (qx, qy, qz),
        eps=float(args.finufft_eps),
        isign=+1,
        dtype="complex128",
        nthreads=int(args.finufft_threads),
    )
    strengths = np.ascontiguousarray(weights, dtype=np.complex128)
    centered, execute_s = timed(lambda: plan.execute(strengths))
    del plan, strengths, qx, qy, qz
    centered = np.ascontiguousarray(centered, dtype=np.complex128)
    centered[0, :, :] = 0
    centered[:, 0, :] = 0
    centered[:, :, 0] = 0
    gc.collect()
    timing = {
        "coordinate_scaling": coordinate_s,
        "type1_plan_setup": plan_s,
        "type1_execute": execute_s,
    }
    return centered, {
        "timing_s": timing,
        "kernel_build_s": float(sum(timing.values())),
        "scaled_q_coordinate_max_abs": coordinate_max,
    }


def run_case(
    args: argparse.Namespace,
    q: dict[str, Any],
    detector: dict[str, Any],
    profile_name: str,
    n: int,
) -> dict[str, Any]:
    profile = profile_parameters(profile_name, detector, float(args.detector_na))
    weights, weight_s = timed(lambda: q_weight_vector(args, detector, profile))
    expected_q = int(q["metadata"]["q_count"])
    if weights.size != expected_q:
        raise RuntimeError(f"weight count {weights.size} != q count {expected_q}")
    factorized, factorized_meta = build_factorized_centered(
        args, detector, profile, n
    )
    generic, generic_meta = build_generic_centered(args, q, weights, n)
    kernel_error = relative_l2(factorized, generic)
    center_expected = float(np.sum(weights))
    center_factorized = factorized[n, n, n]
    center_generic = generic[n, n, n]
    factorized_center_error = float(
        abs(center_factorized - center_expected) / max(abs(center_expected), 1.0)
    )
    generic_center_error = float(
        abs(center_generic - center_expected) / max(abs(center_expected), 1.0)
    )
    embedded_factorized = np.fft.ifftshift(factorized)
    embedded_generic = np.fft.ifftshift(generic)
    symbol_factorized, factorized_fft_s = timed(
        lambda: scipy_fft.fftn(embedded_factorized, workers=int(args.fft_workers))
    )
    symbol_generic, generic_fft_s = timed(
        lambda: scipy_fft.fftn(embedded_generic, workers=int(args.fft_workers))
    )
    symbol_error = relative_l2(symbol_factorized, symbol_generic)
    digest = array_sha256([weights])
    del factorized, generic, embedded_factorized, embedded_generic
    del symbol_factorized, symbol_generic, weights
    gc.collect()
    factorized_total = float(
        weight_s + factorized_meta["kernel_build_s"] + factorized_fft_s
    )
    generic_total = float(weight_s + generic_meta["kernel_build_s"] + generic_fft_s)
    gates = {
        "kernel_relative_l2": bool(kernel_error <= float(args.relative_l2_tolerance)),
        "symbol_relative_l2": bool(symbol_error <= float(args.relative_l2_tolerance)),
        "center_identity": bool(
            max(factorized_center_error, generic_center_error)
            <= float(args.center_tolerance)
        ),
        "positive_weights": bool(profile["minimum_weight"] > 0.0),
    }
    return {
        "n": int(n),
        "profile": profile_name,
        "weight_sha256_float64": digest,
        "weight_range": [
            float(profile["minimum_weight"]),
            float(profile["maximum_weight"]),
        ],
        "ring_weight": float(profile["ring_weight"]),
        "axis_weight": float(profile["axis_weight"]),
        "metrics": {
            "kernel_relative_l2": kernel_error,
            "symbol_relative_l2": symbol_error,
            "factorized_center_relative_error": factorized_center_error,
            "generic_center_relative_error": generic_center_error,
        },
        "timing_s": {
            "weight_vector": weight_s,
            "factorized_kernel": factorized_meta["kernel_build_s"],
            "factorized_symbol_fft": factorized_fft_s,
            "factorized_total": factorized_total,
            "generic_kernel": generic_meta["kernel_build_s"],
            "generic_symbol_fft": generic_fft_s,
            "generic_total": generic_total,
        },
        "comparison": {
            "generic_over_factorized_rebuild_speedup": float(
                generic_total / factorized_total
            )
        },
        "factorized_build": factorized_meta,
        "generic_build": generic_meta,
        "gates": gates,
        "passed": bool(all(gates.values())),
    }


def render_markdown(result: dict[str, Any]) -> str:
    lines = [
        "# ODT structured-weight Toeplitz rebuild validation",
        "",
        f"- overall: `{'PASS' if result['passed'] else 'FAIL'}`",
        f"- q samples: `{result['geometry']['q_count']}`",
        "- scope: positive axisymmetric detector x illumination separable weights",
        "",
        "| N | profile | kernel rel-L2 | symbol rel-L2 | generic s | ACFO-derived s | speedup | verdict |",
        "|---:|---|---:|---:|---:|---:|---:|---|",
    ]
    for case in result["cases"]:
        timing = case["timing_s"]
        lines.append(
            "| {n} | {profile} | {kernel:.3e} | {symbol:.3e} | {generic:.3f} | {factorized:.3f} | {speedup:.3f}x | {verdict} |".format(
                n=case["n"],
                profile=case["profile"],
                kernel=case["metrics"]["kernel_relative_l2"],
                symbol=case["metrics"]["symbol_relative_l2"],
                generic=timing["generic_total"],
                factorized=timing["factorized_total"],
                speedup=case["comparison"]["generic_over_factorized_rebuild_speedup"],
                verdict="PASS" if case["passed"] else "FAIL",
            )
        )
    lines.extend(
        [
            "",
            "Arbitrary per-sample or nonseparable weights are outside this compiler gate and require the explicit operator or a generic Toeplitz rebuild.",
            "",
        ]
    )
    return "\n".join(lines)


def run(args: argparse.Namespace) -> dict[str, Any]:
    profiles = [
        value.strip() for value in args.profiles.split(",") if value.strip()
    ]
    allowed = {"unity", "radial_apodized", "source_and_band_reweighted"}
    if not profiles or not set(profiles).issubset(allowed):
        raise ValueError(f"profiles must be selected from {sorted(allowed)}")
    q = production_q_geometry(args)
    detector = analytic_detector_geometry(args)
    cases = [
        run_case(args, q, detector, profile, n)
        for n in parse_sizes(args.sizes)
        for profile in profiles
    ]
    result = {
        "schema": "odt-toeplitz-weighted-updates-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": bool(all(case["passed"] for case in cases)),
        "geometry": q["metadata"],
        "configuration": {
            "sizes": parse_sizes(args.sizes),
            "profiles": profiles,
            "dtype": "complex128",
            "finufft_eps": float(args.finufft_eps),
            "relative_l2_tolerance": float(args.relative_l2_tolerance),
            "center_tolerance": float(args.center_tolerance),
        },
        "factorization": "K_W(d)=D_w(d) I_w(d) for separable detector x illumination weights",
        "cases": cases,
        "scope": [
            "fixed production ring-plus-axis geometry with uniform azimuth sampling",
            "positive axisymmetric weights separable between detector and illumination",
            "uniform Cartesian reconstruction state and exact 2N Toeplitz embedding",
            "arbitrary nonseparable per-q weights are not compiled by this path",
        ],
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "finufft": __import__("finufft").__version__,
            "platform": platform.platform(),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(render_markdown(result), encoding="utf-8")
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--variant", default="banded_inner96_outer64")
    p.add_argument("--k", type=float, default=17.307319527958313)
    p.add_argument("--detector-na", type=float, default=0.9240924092409241)
    p.add_argument("--illumination-angle-deg", type=float, default=49.0)
    p.add_argument("--ring-illum", type=int, default=120)
    p.add_argument("--r-max", type=float, default=1.0)
    p.add_argument("--z-max", type=float, default=0.8)
    p.add_argument("--sizes", default="64,128")
    p.add_argument(
        "--profiles",
        default="unity,radial_apodized,source_and_band_reweighted",
    )
    p.add_argument("--finufft-eps", type=float, default=1e-12)
    p.add_argument("--finufft-threads", type=int, default=0)
    p.add_argument("--fft-workers", type=int, default=-1)
    p.add_argument("--relative-l2-tolerance", type=float, default=2e-10)
    p.add_argument("--center-tolerance", type=float, default=2e-12)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--summary", type=Path, default=DEFAULT_SUMMARY)
    return p


def main() -> None:
    args = parser().parse_args()
    result = run(args)
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "q_count": result["geometry"]["q_count"],
                "cases": [
                    {
                        "n": case["n"],
                        "profile": case["profile"],
                        "rel_l2": case["metrics"]["kernel_relative_l2"],
                        "speedup": case["comparison"][
                            "generic_over_factorized_rebuild_speedup"
                        ],
                    }
                    for case in result["cases"]
                ],
                "output": str(args.output),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
