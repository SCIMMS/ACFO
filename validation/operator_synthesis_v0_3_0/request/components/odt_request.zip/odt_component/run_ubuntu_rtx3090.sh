#!/usr/bin/env bash
set -u -o pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/src:$ROOT/scripts${PYTHONPATH:+:$PYTHONPATH}"
export WAXS_CPP_EXTENSIONS=odt
export WAXS_CPP_OPT=native
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
export CUPY_CACHE_DIR="${CUPY_CACHE_DIR:-$ROOT/../.odt_toeplitz_si_rtx3090_validation_request_v1_cupy_cache}"
python3 scripts/run_odt_toeplitz_si_external_validation.py --mode full
status=$?
echo "runner exit status: $status"
exit "$status"
