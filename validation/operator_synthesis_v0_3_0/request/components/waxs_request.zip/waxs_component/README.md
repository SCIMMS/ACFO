# WAXS 100-state ranking validation request v1

This package tests whether a prepared ACFO workflow preserves the candidate
ranking and top-k decision of a full-supercell FINUFFT workflow.

The full experiment evaluates a frozen 10x10 manufactured occupancy/B-factor
library at q=6.7--8.0 A^-1 for three predeclared noisy observations. Each
observation is generated from an off-grid parameter state, so no candidate
exactly generates the data.

## Full independent-workstation run

```bash
chmod +x run_ubuntu_rtx3090.sh
./run_ubuntu_rtx3090.sh
```

The timed calculation is CPU-only. The RTX 3090 identifies the predeclared
independent workstation but is not used by the WAXS kernels. Expected runtime
is approximately 30 minutes, dominated by full-supercell FINUFFT.

## Reference-machine smoke

```bash
PYTHONPATH="$PWD/src:$PWD/scripts" python3 scripts/run_waxs_100_state_external_validation.py   --mode smoke --allow-reference-machine --no-resume
```

Smoke output validates the package and evidence path only.

## Interpretation

- Scientific outcome targets are never integrity gates.
- The finite-lattice factor is a standard crystallographic specialization.
- The primary outcome is ranking/top-k preservation, not operator-only
  speedup.
- Return the generated `waxs_100_state_full_external_return.zip` unchanged.
