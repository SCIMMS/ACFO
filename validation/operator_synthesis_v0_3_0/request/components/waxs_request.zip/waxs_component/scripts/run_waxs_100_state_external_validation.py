from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL_PATH = ROOT / "WAXS_100_STATE_RANKING_PROTOCOL.json"
EVIDENCE = ROOT / "evidence"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def verify_package_manifest() -> dict[str, Any]:
    path = ROOT / "PACKAGE_MANIFEST.json"
    manifest = load_json(path)
    missing: list[str] = []
    mismatched: list[dict[str, str]] = []
    for relative, record in manifest["files"].items():
        candidate = ROOT / relative
        if not candidate.is_file():
            missing.append(relative)
            continue
        observed = sha256(candidate)
        if observed != record["sha256"]:
            mismatched.append(
                {
                    "path": relative,
                    "expected": record["sha256"],
                    "observed": observed,
                }
            )
    return {
        "manifest_sha256": sha256(path),
        "file_count": len(manifest["files"]),
        "missing": missing,
        "mismatched": mismatched,
        "passed": not missing and not mismatched,
    }


def cpu_model() -> str | None:
    if platform.system() == "Linux":
        cpuinfo = Path("/proc/cpuinfo")
        if cpuinfo.is_file():
            for line in cpuinfo.read_text(encoding="utf-8").splitlines():
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    return platform.processor() or None


def gpu_name() -> str | None:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout.splitlines()[0].strip() if result.stdout.strip() else None


def environment_receipt() -> dict[str, Any]:
    import finufft
    import numpy
    import scipy

    return {
        "generated_at_utc": utc_now(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "numpy": numpy.__version__,
        "scipy": scipy.__version__,
        "finufft": getattr(finufft, "__version__", None),
        "cpu_model": cpu_model(),
        "cpu_count": os.cpu_count(),
        "gpu_name": gpu_name(),
        "omp_num_threads": os.environ.get("OMP_NUM_THREADS"),
        "mkl_num_threads": os.environ.get("MKL_NUM_THREADS"),
        "openblas_num_threads": os.environ.get("OPENBLAS_NUM_THREADS"),
    }


def run_logged(command: list[str], log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            log.write(line)
        return_code = process.wait()
    if return_code:
        raise subprocess.CalledProcessError(return_code, command)


def command_for_seed(
    protocol: dict[str, Any],
    *,
    mode: str,
    seed: int,
    output: Path,
) -> list[str]:
    shared = protocol["shared_contract"]
    profile = protocol[mode]
    return [
        sys.executable,
        "scripts/benchmark_waxs_100_state_ranking.py",
        "--mode",
        mode,
        "--unit",
        shared["unit_structure"],
        "--supercell",
        shared["supercell_structure"],
        "--q-min",
        str(profile["q_range_inv_angstrom"][0]),
        "--q-max",
        str(profile["q_range_inv_angstrom"][1]),
        "--nq",
        str(profile["nq"]),
        "--nphi",
        str(profile["nphi"]),
        "--wavelength-nm",
        str(shared["wavelength_nm"]),
        "--harmonic-margin",
        str(shared["harmonic_margin"]),
        "--finufft-eps",
        str(shared["finufft_eps"]),
        "--finufft-threads",
        str(shared["finufft_threads"]),
        "--occupancy-min",
        str(shared["occupancy_range"][0]),
        "--occupancy-max",
        str(shared["occupancy_range"][1]),
        "--occupancy-count",
        str(profile["occupancy_count"]),
        "--b-min",
        str(shared["b_iso_range_angstrom2"][0]),
        "--b-max",
        str(shared["b_iso_range_angstrom2"][1]),
        "--b-count",
        str(profile["b_count"]),
        "--truth-occupancy",
        str(profile["off_grid_truth"]["subdomain_occupancy"]),
        "--truth-b",
        str(profile["off_grid_truth"]["b_iso_angstrom2"]),
        "--intensity-noise-rel-l2",
        str(shared["intensity_noise_relative_l2"]),
        "--seed",
        str(seed),
        "--top-k",
        str(shared["top_k"]),
        "--out",
        str(output),
    ]


def audit_result(
    result: dict[str, Any],
    *,
    protocol: dict[str, Any],
    mode: str,
    seed: int,
) -> dict[str, Any]:
    shared = protocol["shared_contract"]
    profile = protocol[mode]
    problem = result["problem"]
    gates = {
        "schema": result["schema"] == "waxs-100-state-ranking-v1",
        "mode": result["mode"] == mode,
        "candidate_count": int(problem["candidate_count"])
        == int(profile["candidate_count"]),
        "q_range": problem["q_range_inv_angstrom"]
        == profile["q_range_inv_angstrom"],
        "nq": int(problem["nq"]) == int(profile["nq"]),
        "nphi": int(problem["nphi"]) == int(profile["nphi"]),
        "seed": int(problem["noise"]["seed"]) == int(seed),
        "unit_structure_sha": bool(result["structures"]["unit_sha256"]),
        "supercell_structure_sha": bool(
            result["structures"]["supercell_sha256"]
        ),
        "finufft_eps": float(result["operators"]["finufft"]["eps"])
        == float(shared["finufft_eps"]),
        "finufft_threads": int(result["operators"]["finufft"]["threads"])
        == int(shared["finufft_threads"]),
        "row_count": len(result["rows"]) == int(profile["candidate_count"]),
        "finite_scores": all(
            all(
                abs(float(row[key])) < float("inf")
                for key in ("acfo_score", "finufft_score")
            )
            for row in result["rows"]
        ),
    }
    return {
        "seed": int(seed),
        "gates": gates,
        "integrity_passed": all(gates.values()),
        "scientific_outcome": {
            "ranking": result["ranking"],
            "accuracy": result["accuracy"],
            "outcome_targets": result["outcome_targets"],
        },
    }


def aggregate_results(
    results: list[dict[str, Any]],
    audits: list[dict[str, Any]],
    *,
    protocol: dict[str, Any],
) -> dict[str, Any]:
    spearman = [float(result["ranking"]["spearman"]) for result in results]
    jaccard = [
        float(result["ranking"]["top_k_overlap"]["jaccard"])
        for result in results
    ]
    intensity_error = [
        float(result["accuracy"]["maximum_intensity_relative_l2"])
        for result in results
    ]
    same_top1 = [
        int(result["ranking"]["acfo_top_indices"][0])
        == int(result["ranking"]["finufft_top_indices"][0])
        for result in results
    ]
    acfo_total = [
        float(result["operators"]["acfo"]["timing"]["total_s"])
        for result in results
    ]
    finufft_total = [
        float(result["operators"]["finufft"]["timing"]["total_s"])
        for result in results
    ]
    targets = protocol["scientific_outcome_targets"]
    assessment = {
        "spearman": min(spearman) >= float(targets["spearman_min"]),
        "same_top1": all(same_top1),
        "top_k_jaccard": min(jaccard)
        >= float(targets["top_k_jaccard_min"]),
        "maximum_intensity_relative_l2": max(intensity_error)
        <= float(targets["maximum_intensity_relative_l2_max"]),
    }
    return {
        "schema": "waxs-100-state-ranking-external-aggregate-v1",
        "generated_at_utc": utc_now(),
        "run_count": len(results),
        "run_integrity_passed": all(
            audit["integrity_passed"] for audit in audits
        ),
        "outcomes": {
            "spearman": {"values": spearman, "minimum": min(spearman)},
            "same_top1": {"values": same_top1, "all": all(same_top1)},
            "top_k_jaccard": {
                "values": jaccard,
                "minimum": min(jaccard),
            },
            "maximum_intensity_relative_l2": {
                "values": intensity_error,
                "maximum": max(intensity_error),
            },
            "acfo_library_total_s": {
                "values": acfo_total,
                "median": median(acfo_total),
            },
            "finufft_library_total_s": {
                "values": finufft_total,
                "median": median(finufft_total),
            },
            "workflow_speedup": {
                "values": [
                    baseline / candidate
                    for candidate, baseline in zip(
                        acfo_total, finufft_total, strict=True
                    )
                ]
            },
            "predeclared_target_assessment": assessment,
        },
        "outcome_targets_are_integrity_gates": False,
    }


def write_return_manifest() -> None:
    files: dict[str, dict[str, Any]] = {}
    for path in sorted(EVIDENCE.rglob("*")):
        if path.is_file() and path.name != "RETURN_MANIFEST.json":
            files[path.relative_to(EVIDENCE).as_posix()] = {
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
    write_json(
        EVIDENCE / "RETURN_MANIFEST.json",
        {
            "schema": "waxs-100-state-ranking-return-manifest-v1",
            "files": files,
        },
    )


def write_return_archive(mode: str) -> Path:
    archive_path = ROOT / f"waxs_100_state_{mode}_external_return.zip"
    if archive_path.exists():
        archive_path.unlink()
    with zipfile.ZipFile(
        archive_path,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
    ) as archive:
        for path in sorted(EVIDENCE.rglob("*")):
            if path.is_file():
                archive.write(
                    path,
                    (
                        Path("waxs_100_state_external_return")
                        / path.relative_to(EVIDENCE)
                    ).as_posix(),
                )
        for name in (
            "WAXS_100_STATE_RANKING_PROTOCOL.json",
            "PACKAGE_MANIFEST.json",
        ):
            archive.write(
                ROOT / name,
                (Path("waxs_100_state_external_return") / name).as_posix(),
            )
    return archive_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("full", "smoke"), default="full")
    parser.add_argument("--allow-reference-machine", action="store_true")
    parser.add_argument("--allow-reference-machine-full", action="store_true", help="Permit the prespecified second-machine full replication; the actual GPU is recorded.")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    protocol = load_json(PROTOCOL_PATH)
    package_audit = verify_package_manifest()
    if not package_audit["passed"]:
        raise RuntimeError("package manifest verification failed")
    if EVIDENCE.exists() and args.no_resume:
        resolved = EVIDENCE.resolve()
        if resolved.parent != ROOT.resolve():
            raise RuntimeError("evidence target escaped package root")
        shutil.rmtree(EVIDENCE)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    shared = protocol["shared_contract"]
    env = os.environ.copy()
    env.update(
        {
            "PYTHONPATH": (
                f"{ROOT / 'src'}{os.pathsep}{ROOT / 'scripts'}"
            ),
            "WAXS_CPP_EXTENSIONS": "histogram,solvers",
            "WAXS_CPP_OPT": "native",
            "OMP_NUM_THREADS": str(shared["omp_threads"]),
            "MKL_NUM_THREADS": str(shared["mkl_threads"]),
            "OPENBLAS_NUM_THREADS": str(shared["openblas_threads"]),
        }
    )
    for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
        os.environ[name] = env[name]
    environment = environment_receipt()
    write_json(EVIDENCE / "environment.json", environment)
    preferred_gpu = protocol["environment"]["preferred_workstation_gpu"]
    independent_environment = bool(
        environment["gpu_name"] == preferred_gpu
        or (args.mode == "smoke" and args.allow_reference_machine)
        or (args.mode == "full" and args.allow_reference_machine_full)
    )
    if not independent_environment:
        raise RuntimeError(
            f"expected workstation GPU {preferred_gpu}, "
            f"observed {environment['gpu_name']}"
        )
    run_logged(
        [sys.executable, "setup.py", "build_ext", "--inplace"],
        EVIDENCE / "build.log",
        env,
    )
    profile = protocol[args.mode]
    results: list[dict[str, Any]] = []
    audits: list[dict[str, Any]] = []
    for index, seed in enumerate(profile["seeds"], start=1):
        output = EVIDENCE / f"seed_{seed}.json"
        if args.no_resume or not output.is_file():
            run_logged(
                command_for_seed(
                    protocol,
                    mode=args.mode,
                    seed=int(seed),
                    output=output,
                ),
                EVIDENCE / f"seed_{seed}.log",
                env,
            )
        result = load_json(output)
        results.append(result)
        audit = audit_result(
            result,
            protocol=protocol,
            mode=args.mode,
            seed=int(seed),
        )
        audits.append(audit)
        write_json(EVIDENCE / f"seed_{seed}_audit.json", audit)
        print(
            f"completed {index}/{len(profile['seeds'])}: "
            f"seed={seed}, integrity={audit['integrity_passed']}",
            flush=True,
        )
    aggregate = aggregate_results(results, audits, protocol=protocol)
    write_json(EVIDENCE / "aggregate.json", aggregate)
    return_audit = {
        "schema": "waxs-100-state-ranking-external-return-audit-v1",
        "generated_at_utc": utc_now(),
        "mode": args.mode,
        "package_audit": package_audit,
        "environment": environment,
        "gates": {
            "package_manifest_passed": package_audit["passed"],
            "independent_environment_passed": independent_environment,
            "all_runs_integrity_passed": aggregate["run_integrity_passed"],
            "expected_run_count": len(results) == len(profile["seeds"]),
        },
        "integrity_passed": bool(
            package_audit["passed"]
            and independent_environment
            and aggregate["run_integrity_passed"]
            and len(results) == len(profile["seeds"])
        ),
        "scientific_outcomes": aggregate["outcomes"],
        "scientific_outcomes_are_integrity_gates": False,
    }
    write_json(EVIDENCE / "RETURN_AUDIT.json", return_audit)
    write_return_manifest()
    archive = write_return_archive(args.mode)
    print(
        json.dumps(
            {
                **return_audit,
                "return_archive": archive.name,
                "return_archive_sha256": sha256(archive),
            },
            indent=2,
        )
    )
    if not return_audit["integrity_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
