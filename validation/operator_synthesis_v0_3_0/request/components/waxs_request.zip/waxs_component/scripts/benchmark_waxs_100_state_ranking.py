from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any

import numpy as np
from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parents[1]
for candidate in (ROOT / "src", ROOT / "scripts"):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from validate_public_waxs_structures import (  # noqa: E402
    build_form_factors,
    load_structure,
)
from waxs_cake import (  # noqa: E402
    PreparedExactCoordinateHarmonicPlan,
    encode_elements,
    repeated_block_translations,
    translation_lattice_factor_separable,
)
from waxs_cake.geometry import ewald_ring  # noqa: E402
from waxs_cake.physical_scaling import q_to_inv_nm  # noqa: E402
from waxs_cake.solvers import normalize_form_factors  # noqa: E402


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def array_sha256(value: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(value)
    digest = hashlib.sha256()
    digest.update(str(contiguous.dtype).encode("ascii"))
    digest.update(json.dumps(list(contiguous.shape)).encode("ascii"))
    digest.update(memoryview(contiguous).cast("B"))
    return digest.hexdigest()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def relative_l2(candidate: np.ndarray, reference: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(reference.ravel())), 1e-300)
    return float(np.linalg.norm((candidate - reference).ravel()) / denominator)


def debye_waller_amplitude(q_inv_angstrom: np.ndarray, b_iso: float) -> np.ndarray:
    return np.exp(
        -float(b_iso) * np.square(q_inv_angstrom) / (16.0 * np.pi * np.pi)
    )


def score_intensity(candidate: np.ndarray, observed: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(observed.ravel())), 1e-300)
    return float(np.linalg.norm((candidate - observed).ravel()) / denominator)


def add_intensity_noise(
    clean: np.ndarray,
    *,
    relative_l2: float,
    seed: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    if relative_l2 <= 0.0:
        return np.ascontiguousarray(clean.copy()), {
            "seed": int(seed),
            "target_relative_l2": 0.0,
            "observed_relative_l2": 0.0,
        }
    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(clean.shape)
    scale = (
        float(relative_l2)
        * max(float(np.linalg.norm(clean.ravel())), 1e-300)
        / max(float(np.linalg.norm(noise.ravel())), 1e-300)
    )
    observed = np.maximum(clean + scale * noise, 0.0)
    return np.ascontiguousarray(observed), {
        "seed": int(seed),
        "target_relative_l2": float(relative_l2),
        "observed_relative_l2": relative_l2_fn(observed, clean),
        "clipped_negative_pixels": int(np.count_nonzero(clean + scale * noise < 0.0)),
    }


def relative_l2_fn(candidate: np.ndarray, reference: np.ndarray) -> float:
    return relative_l2(candidate, reference)


def candidate_grid(
    *,
    occupancy_min: float,
    occupancy_max: float,
    occupancy_count: int,
    b_min: float,
    b_max: float,
    b_count: int,
) -> list[dict[str, Any]]:
    occupancies = np.linspace(occupancy_min, occupancy_max, occupancy_count)
    b_values = np.linspace(b_min, b_max, b_count)
    rows: list[dict[str, Any]] = []
    state_index = 0
    for occupancy_index, occupancy in enumerate(occupancies):
        for b_index, b_iso in enumerate(b_values):
            rows.append(
                {
                    "state_index": int(state_index),
                    "occupancy_index": int(occupancy_index),
                    "b_index": int(b_index),
                    "subdomain_occupancy": float(occupancy),
                    "b_iso_angstrom2": float(b_iso),
                }
            )
            state_index += 1
    return rows


def top_indices(scores: np.ndarray, count: int) -> list[int]:
    return [
        int(value)
        for value in np.argsort(scores, kind="stable")[: min(count, scores.size)]
    ]


def top_k_overlap(left: list[int], right: list[int]) -> dict[str, Any]:
    left_set = set(left)
    right_set = set(right)
    intersection = left_set & right_set
    union = left_set | right_set
    return {
        "intersection_count": len(intersection),
        "fraction": len(intersection) / max(len(left_set), 1),
        "jaccard": len(intersection) / max(len(union), 1),
        "same_order": left == right,
    }


def timing_summary(values: list[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    return {
        "count": int(array.size),
        "total_s": float(array.sum()),
        "median_s": float(np.median(array)),
        "p05_s": float(np.percentile(array, 5)),
        "p95_s": float(np.percentile(array, 95)),
        "min_s": float(array.min()),
        "max_s": float(array.max()),
    }


def build_finufft_plans(
    sources: np.ndarray,
    source_e: np.ndarray,
    qx: np.ndarray,
    qy: np.ndarray,
    qz: np.ndarray,
    *,
    n_elements: int,
    eps: float,
    threads: int,
) -> tuple[list[Any], list[np.ndarray]]:
    """Prepare one reusable type-3 FINUFFT plan per element channel."""

    import finufft

    plans: list[Any] = []
    masks: list[np.ndarray] = []
    for element_index in range(n_elements):
        mask = np.flatnonzero(source_e == element_index)
        plan = finufft.Plan(
            3,
            3,
            eps=eps,
            isign=1,
            dtype="complex128",
            nthreads=threads,
        )
        plan.setpts(
            np.ascontiguousarray(sources[mask, 0]),
            np.ascontiguousarray(sources[mask, 1]),
            np.ascontiguousarray(sources[mask, 2]),
            qx,
            qy,
            qz,
        )
        plans.append(plan)
        masks.append(mask)
    return plans, masks


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate a manufactured occupancy/B-factor WAXS candidate library "
            "and test whether ACFO preserves FINUFFT model ranking."
        )
    )
    parser.add_argument(
        "--unit",
        type=Path,
        default=Path(
            "structures/processed/"
            "protein_nanocrystal_lysozyme_1iee_1x1x1_fixed.npz"
        ),
    )
    parser.add_argument(
        "--supercell",
        type=Path,
        default=Path(
            "structures/processed/"
            "protein_nanocrystal_lysozyme_1iee_3x3x3_fixed.npz"
        ),
    )
    parser.add_argument("--mode", choices=["smoke", "full"], default="smoke")
    parser.add_argument("--nq", type=int)
    parser.add_argument("--q-min", type=float, default=6.7)
    parser.add_argument("--q-max", type=float, default=8.0)
    parser.add_argument("--nphi", type=int)
    parser.add_argument("--wavelength-nm", type=float, default=0.08)
    parser.add_argument("--harmonic-margin", type=int, default=48)
    parser.add_argument("--finufft-eps", type=float, default=1e-6)
    parser.add_argument("--finufft-threads", type=int, default=4)
    parser.add_argument("--occupancy-min", type=float, default=0.7)
    parser.add_argument("--occupancy-max", type=float, default=1.0)
    parser.add_argument("--occupancy-count", type=int)
    parser.add_argument("--b-min", type=float, default=5.0)
    parser.add_argument("--b-max", type=float, default=23.0)
    parser.add_argument("--b-count", type=int)
    parser.add_argument("--truth-occupancy", type=float)
    parser.add_argument("--truth-b", type=float)
    parser.add_argument("--intensity-noise-rel-l2", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=2026072611)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument(
        "--out",
        type=Path,
        default=ROOT / "benchmark_results" / "waxs_100_state_ranking.json",
    )
    args = parser.parse_args()
    defaults = (
        {
            "nq": 4,
            # Keep the high-q azimuthal Nyquist contract even in smoke mode;
            # reducing only q rows and candidate count makes the test fast
            # without silently switching away from the FFT synthesis path.
            "nphi": 864,
            "occupancy_count": 3,
            "b_count": 3,
            "truth_occupancy": 0.86,
            "truth_b": 13.4,
        }
        if args.mode == "smoke"
        else {
            "nq": 16,
            "nphi": 864,
            "occupancy_count": 10,
            "b_count": 10,
            # The observation is deliberately off-grid so the ranking test is
            # not reduced to reproducing a candidate that generated itself.
            "truth_occupancy": 0.915,
            "truth_b": 12.4,
        }
    )
    for key, value in defaults.items():
        if getattr(args, key) is None:
            setattr(args, key, value)
    if args.nphi % 2 or args.nphi < 4:
        raise ValueError("nphi must be an even integer >= 4")
    states = candidate_grid(
        occupancy_min=args.occupancy_min,
        occupancy_max=args.occupancy_max,
        occupancy_count=args.occupancy_count,
        b_min=args.b_min,
        b_max=args.b_max,
        b_count=args.b_count,
    )
    truth_state = {
        "state_index": None,
        "occupancy_index": None,
        "b_index": None,
        "subdomain_occupancy": float(args.truth_occupancy),
        "b_iso_angstrom2": float(args.truth_b),
        "off_grid": True,
    }

    unit_path = args.unit if args.unit.is_absolute() else ROOT / args.unit
    supercell_path = (
        args.supercell if args.supercell.is_absolute() else ROOT / args.supercell
    )
    unit_coords, unit_elements, unit_metadata = load_structure(unit_path)
    coords, elements, metadata = load_structure(supercell_path)
    blocks = elements.reshape(-1, unit_elements.size)
    if not np.array_equal(blocks, np.broadcast_to(unit_elements, blocks.shape)):
        raise RuntimeError("supercell does not repeat the unit element ordering")
    translations, repetition_residual = repeated_block_translations(
        unit_coords,
        coords,
        atol=1e-9,
    )
    unit_e, element_order = encode_elements(unit_elements)
    element_indices, _ = encode_elements(elements, element_order=element_order)
    q_report = np.linspace(args.q_min, args.q_max, args.nq, dtype=np.float64)
    q_solver = np.asarray(
        [q_to_inv_nm(value, "inv_angstrom") for value in q_report]
    )
    q_perp, q_z_rows = ewald_ring(q_solver, args.wavelength_nm)
    phi = (np.arange(args.nphi) + 0.5) * (2.0 * np.pi / args.nphi)
    qx = np.ascontiguousarray(
        (q_perp[:, None] * np.cos(phi)[None, :]).ravel()
    )
    qy = np.ascontiguousarray(
        (q_perp[:, None] * np.sin(phi)[None, :]).ravel()
    )
    qz = np.ascontiguousarray(
        np.broadcast_to(q_z_rows[:, None], (args.nq, args.nphi)).ravel()
    )
    target_q_indices = np.repeat(np.arange(args.nq), args.nphi)
    ff_mapping = build_form_factors(unit_elements, q_solver, "xray_f0")
    form_factors = normalize_form_factors(
        element_order,
        q_solver,
        ff_mapping,
    ).astype(np.complex128, copy=False)
    # A deterministic coordinate-defined subdomain is used because the frozen
    # processed NPZ stores coordinates/elements but no residue identifiers.
    center = np.median(unit_coords, axis=0)
    distances = np.linalg.norm(unit_coords - center[None, :], axis=1)
    threshold = float(np.quantile(distances, 0.25))
    occupancy_mask = distances <= threshold
    if not np.any(occupancy_mask):
        raise RuntimeError("manufactured occupancy subdomain is empty")

    setup_start = time.perf_counter()
    lattice = translation_lattice_factor_separable(
        qx,
        qy,
        qz,
        translations,
        metadata["supercell"],
    ).reshape(args.nq, args.nphi)
    prepared = PreparedExactCoordinateHarmonicPlan(
        unit_coords,
        q_perp,
        q_z_rows,
        phi,
        element_indices=unit_e,
        form_factors=form_factors,
        harmonic_margin=args.harmonic_margin,
        prepare_direct_basis=False,
        coefficient_backend="fused_phase",
    )
    if not prepared.fft_supported:
        raise RuntimeError("prepared ACFO plan does not support FFT synthesis")
    acfo_setup_s = time.perf_counter() - setup_start
    setup_start = time.perf_counter()
    plans, masks = build_finufft_plans(
        coords,
        element_indices,
        qx,
        qy,
        qz,
        n_elements=len(element_order),
        eps=args.finufft_eps,
        threads=args.finufft_threads,
    )
    finufft_setup_s = time.perf_counter() - setup_start

    def weights_for_state(state: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
        unit_weights = np.ones(unit_coords.shape[0], dtype=np.complex128)
        unit_weights[occupancy_mask] = float(state["subdomain_occupancy"])
        source_weights = np.tile(unit_weights, int(translations.shape[0]))
        if source_weights.shape[0] != coords.shape[0]:
            raise RuntimeError("repeated state weights do not match supercell atoms")
        return unit_weights, source_weights

    def apply_b_factor(amplitude: np.ndarray, b_iso: float) -> np.ndarray:
        factor = debye_waller_amplitude(q_report, b_iso)
        return amplitude * factor[:, None]

    def acfo_execute(state: dict[str, Any]) -> np.ndarray:
        unit_weights, _ = weights_for_state(state)
        unit, _ = prepared.execute(
            atom_weights=unit_weights,
            synthesis_backend="fft",
        )
        return apply_b_factor(unit * lattice, state["b_iso_angstrom2"])

    def finufft_execute(state: dict[str, Any]) -> np.ndarray:
        _, source_weights = weights_for_state(state)
        active = np.zeros(qx.size, dtype=np.complex128)
        for element_index, (plan, mask) in enumerate(zip(plans, masks, strict=True)):
            values = plan.execute(np.ascontiguousarray(source_weights[mask]))
            active += values * form_factors[element_index, target_q_indices]
        amplitude = active.reshape(args.nq, args.nphi)
        return apply_b_factor(amplitude, state["b_iso_angstrom2"])

    # The observed map is generated with the generic full-supercell baseline.
    truth_amplitude = finufft_execute(truth_state)
    clean_intensity = np.square(np.abs(truth_amplitude))
    observed_intensity, noise_metadata = add_intensity_noise(
        clean_intensity,
        relative_l2=args.intensity_noise_rel_l2,
        seed=args.seed,
    )
    acfo_execute(states[0])
    finufft_execute(states[0])
    rows: list[dict[str, Any]] = []
    acfo_times: list[float] = []
    finufft_times: list[float] = []
    for candidate_index, state in enumerate(states):
        order = "AB" if candidate_index % 2 == 0 else "BA"
        outputs: dict[str, np.ndarray] = {}
        times: dict[str, float] = {}
        for label in order:
            gc.collect()
            start = time.perf_counter()
            if label == "A":
                outputs["acfo"] = acfo_execute(state)
                times["acfo"] = time.perf_counter() - start
            else:
                outputs["finufft"] = finufft_execute(state)
                times["finufft"] = time.perf_counter() - start
        acfo_times.append(times["acfo"])
        finufft_times.append(times["finufft"])
        acfo_intensity = np.square(np.abs(outputs["acfo"]))
        finufft_intensity = np.square(np.abs(outputs["finufft"]))
        row = {
            **state,
            "order": order,
            "acfo_s": times["acfo"],
            "finufft_s": times["finufft"],
            "acfo_score": score_intensity(acfo_intensity, observed_intensity),
            "finufft_score": score_intensity(
                finufft_intensity,
                observed_intensity,
            ),
            "complex_relative_l2": relative_l2(
                outputs["acfo"],
                outputs["finufft"],
            ),
            "intensity_relative_l2": relative_l2(
                acfo_intensity,
                finufft_intensity,
            ),
        }
        rows.append(row)
        print(
            f"state {candidate_index + 1}/{len(states)} "
            f"{order}: ACFO={times['acfo']:.6f}s "
            f"FINUFFT={times['finufft']:.6f}s "
            f"scores={row['acfo_score']:.6g}/{row['finufft_score']:.6g}",
            flush=True,
        )
    acfo_scores = np.asarray([row["acfo_score"] for row in rows])
    finufft_scores = np.asarray([row["finufft_score"] for row in rows])
    acfo_top = top_indices(acfo_scores, args.top_k)
    finufft_top = top_indices(finufft_scores, args.top_k)
    rank_correlation = float(spearmanr(acfo_scores, finufft_scores).statistic)
    overlap = top_k_overlap(acfo_top, finufft_top)
    occupancy_span = max(float(args.occupancy_max - args.occupancy_min), 1e-300)
    b_span = max(float(args.b_max - args.b_min), 1e-300)

    def normalized_parameter_distance(state: dict[str, Any]) -> float:
        return float(
            np.hypot(
                (
                    float(state["subdomain_occupancy"])
                    - float(truth_state["subdomain_occupancy"])
                )
                / occupancy_span,
                (
                    float(state["b_iso_angstrom2"])
                    - float(truth_state["b_iso_angstrom2"])
                )
                / b_span,
            )
        )

    max_complex_l2 = max(float(row["complex_relative_l2"]) for row in rows)
    max_intensity_l2 = max(float(row["intensity_relative_l2"]) for row in rows)
    acfo_timing = timing_summary(acfo_times)
    finufft_timing = timing_summary(finufft_times)
    payload = {
        "schema": "waxs-100-state-ranking-v1",
        "generated_at_utc": utc_now(),
        "mode": args.mode,
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "finufft_threads": int(args.finufft_threads),
        },
        "structures": {
            "unit_path": unit_path.relative_to(ROOT).as_posix(),
            "unit_sha256": sha256(unit_path),
            "unit_structure_id": unit_metadata.get("structure_id"),
            "supercell_path": supercell_path.relative_to(ROOT).as_posix(),
            "supercell_sha256": sha256(supercell_path),
            "supercell_shape": metadata.get("supercell"),
            "unit_atom_count": int(unit_coords.shape[0]),
            "supercell_atom_count": int(coords.shape[0]),
            "cell_count": int(translations.shape[0]),
            "repetition_residual_nm": float(repetition_residual),
        },
        "problem": {
            "candidate_count": len(states),
            "candidate_axes": {
                "subdomain_occupancy": [
                    float(args.occupancy_min),
                    float(args.occupancy_max),
                    int(args.occupancy_count),
                ],
                "b_iso_angstrom2": [
                    float(args.b_min),
                    float(args.b_max),
                    int(args.b_count),
                ],
            },
            "occupancy_subdomain": {
                "definition": "unit-cell atoms within the first radial-distance quartile from the coordinate-wise median",
                "atom_count": int(np.count_nonzero(occupancy_mask)),
                "fraction": float(np.mean(occupancy_mask)),
                "manufactured_parameter_set": True,
            },
            "truth_state": truth_state,
            "q_range_inv_angstrom": [float(args.q_min), float(args.q_max)],
            "nq": int(args.nq),
            "nphi": int(args.nphi),
            "target_count": int(args.nq * args.nphi),
            "wavelength_nm": float(args.wavelength_nm),
            "observed_intensity_sha256": array_sha256(observed_intensity),
            "noise": noise_metadata,
        },
        "operators": {
            "acfo": {
                "prepared_unit_cell": True,
                "finite_lattice_factor": "separable exact translation factor",
                "harmonic_margin": int(args.harmonic_margin),
                "setup_s": float(acfo_setup_s),
                "timing": acfo_timing,
            },
            "finufft": {
                "source": "full repeated supercell",
                "eps": float(args.finufft_eps),
                "threads": int(args.finufft_threads),
                "setup_s": float(finufft_setup_s),
                "timing": finufft_timing,
            },
        },
        "ranking": {
            "spearman": rank_correlation,
            "top_k": int(args.top_k),
            "acfo_top_indices": acfo_top,
            "finufft_top_indices": finufft_top,
            "top_k_overlap": overlap,
            "acfo_best_state": states[acfo_top[0]],
            "finufft_best_state": states[finufft_top[0]],
            "off_grid_truth": truth_state,
            "acfo_best_normalized_parameter_distance": normalized_parameter_distance(
                states[acfo_top[0]]
            ),
            "finufft_best_normalized_parameter_distance": normalized_parameter_distance(
                states[finufft_top[0]]
            ),
        },
        "accuracy": {
            "maximum_complex_relative_l2": max_complex_l2,
            "maximum_intensity_relative_l2": max_intensity_l2,
        },
        "outcome_targets": {
            "spearman_ge_0p999": bool(rank_correlation >= 0.999),
            "same_top1": acfo_top[0] == finufft_top[0],
            "top5_jaccard_eq_1": bool(
                args.top_k != 5 or math.isclose(overlap["jaccard"], 1.0)
            ),
            "maximum_intensity_relative_l2_le_5e_6": bool(
                max_intensity_l2 <= 5e-6
            ),
        },
        "rows": rows,
        "claim_boundary": [
            "This is a manufactured occupancy/B-factor candidate library, not a fitted crystallographic ensemble.",
            "The coordinate-defined occupancy subdomain is used because the frozen processed NPZ does not retain residue identifiers.",
            "The finite lattice factor is a standard crystallographic specialization and is not claimed as an ACFO novelty.",
            "ACFO uses a prepared unit-cell plus exact lattice-factor workflow; FINUFFT evaluates the full repeated supercell.",
            "The primary scientific claim is preservation of model ranking and top-k decisions, not an operator-only speedup.",
            "Anomalous scattering, solvent/background models, orientation uncertainty, and experimental detector noise are not included.",
        ],
    }
    write_json(args.out, payload)
    write_csv(args.out.with_suffix(".csv"), rows)
    lines = [
        "# WAXS 100-state ranking",
        "",
        f"- candidates: `{len(states)}`",
        f"- Spearman score correlation: `{rank_correlation:.9f}`",
        f"- ACFO / FINUFFT top-1: `{acfo_top[0]} / {finufft_top[0]}`",
        f"- top-{args.top_k} Jaccard: `{overlap['jaccard']:.6f}`",
        f"- maximum intensity rel-L2: `{max_intensity_l2:.6g}`",
        f"- ACFO candidate-library total: `{acfo_timing['total_s']:.6f}` s",
        f"- FINUFFT candidate-library total: `{finufft_timing['total_s']:.6f}` s",
        "",
        "The primary outcome is preservation of candidate ranking and selected "
        "models. Timing is reported for the declared structure-aware workflows; "
        "the lattice factor is not an ACFO novelty claim.",
    ]
    args.out.with_suffix(".md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "out": str(args.out),
                "candidate_count": len(states),
                "ranking": payload["ranking"],
                "accuracy": payload["accuracy"],
                "outcome_targets": payload["outcome_targets"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
