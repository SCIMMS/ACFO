"""Frozen local radial/PTF-ATF composition and q-local normal pilot."""
from __future__ import annotations
import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
from time import perf_counter
import numpy as np
import scipy
from scipy import linalg

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from waxs_cake.aidt_acfo import (aidt_transfer_functions_on_points, PreparedAidtAcfoOperator,
                               direct_aidt_forward, direct_aidt_adjoint)
from waxs_cake.radial_cpswf import PreparedRadialProjection, radial_block
from waxs_cake.radial_aidt import ModalRadialMap, PhysicalModalTransfer, PreparedRadialAidt


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def rel(actual, expected):
    return float(np.linalg.norm(actual-expected)/max(np.linalg.norm(expected), 1e-300))


def random_complex(rng, shape):
    return rng.normal(size=shape)+1j*rng.normal(size=shape)


def small_reference():
    old = PreparedAidtAcfoOperator.build(r_edges_um=np.linspace(0, 1.3, 8), n_phi=64,
        depth_values_um=np.array([-0.7, 0, 0.7]), radial_frequency_um_inv=np.linspace(.02, .71, 6),
        source_na_xy=np.array([[.25, -.15], [-.12, .28]]), wavelength_um=.515,
        medium_index=1.47, objective_na=.65, dz_um=.7)
    modes = [-3, -1, 0, 1, 3]
    blocks = {m: radial_block(2*np.pi*old.radial_frequency_um_inv, old.r_centers_um, m) for m in [0, 1, 3]}
    r = ModalRadialMap.build(modes, old.n_phi*old.cell_area_um2[:, 0], blocks, old.n_z)
    t = PhysicalModalTransfer.build(modes, old.beta_centers, old.ptf, old.atf, 2)
    op = PreparedRadialAidt(r, t)
    rng = np.random.default_rng(841)
    x, y = random_complex(rng, r.input_shape), random_complex(rng, t.data_shape)
    f = np.einsum("pm,mrzc->rpzc", t.angular, x)
    direct = direct_aidt_forward(old, f[..., 0], f[..., 1])
    adj = np.einsum("pm,rpzc->mrzc", t.angular.conj(), np.stack(direct_aidt_adjoint(old, y), axis=-1))
    return {"forward_relative_l2": rel(op.forward(x), direct), "adjoint_relative_l2": rel(op.adjoint(y), adj),
            "existing_angular_fft_forward_relative_l2": rel(op.forward(x), old.forward(f[..., 0], f[..., 1]))}


def time_arms(ops, normal, x, y, rng, cfg):
    functions = {}
    for arm, op in ops.items():
        functions[arm+"/forward"] = lambda op=op: op.forward(x)
        functions[arm+"/adjoint"] = lambda op=op: op.adjoint(y)
        functions[arm+"/normal_composed"] = lambda op=op: op.normal(x)
        functions[arm+"/normal_compiled"] = lambda op=op: op.compiled_normal(x, normal)
    raw = {key: [] for key in functions}
    keys = list(functions)
    for fn in functions.values():
        for _ in range(cfg["warmup"]):
            fn()
    for _ in range(cfg["trials"]):
        for index in rng.permutation(len(keys)):
            key = keys[index]
            start = perf_counter()
            for _ in range(cfg["inner"]):
                functions[key]()
            raw[key].append((perf_counter()-start)/cfg["inner"])
    result = {key: {"raw_seconds": val, "median_seconds": float(np.median(val))} for key, val in raw.items()}
    for key, entry in result.items():
        arm, operation = key.split("/")
        entry["dense_same_operation_over_arm"] = result["dense/"+operation]["median_seconds"]/entry["median_seconds"]
        if operation == "normal_compiled":
            entry["same_arm_composed_over_compiled"] = result[arm+"/normal_composed"]["median_seconds"]/entry["median_seconds"]
    return result


def gram_details(normal, transfer, weights, rng):
    nq, nm, nz, nc = normal.modal_shape
    g = normal.gram
    herm = rel(g, g.conj().transpose(0, 2, 1))
    b = random_complex(rng, normal.modal_shape)
    expected = transfer.adjoint(weights*transfer.forward(b))
    agreement = rel(normal.apply(b), expected)
    # Independent selected-q lift, recomputed without compile_normal's reshape.
    indices = [0, nq//2, nq-1]
    residuals = []
    for q in indices:
        columns = []
        for m in range(nm):
            for z in range(nz):
                for h in (transfer.ptf, transfer.atf):
                    columns.append((h[:, q, :, z]*transfer.angular[None, :, m]).ravel())
        f = np.column_stack(columns)
        direct = f.conj().T@(weights[:, q].ravel()[:, None]*f)
        residuals.append(rel(g[q], direct))
    mode_groups = np.repeat(np.arange(nm), nz*nc)
    off_mask = mode_groups[:, None] != mode_groups[None, :]
    off_fraction = float(np.linalg.norm(g[:, off_mask])/np.linalg.norm(g))
    diagonal = g.copy()
    diagonal[:, off_mask] = 0
    diagonal_action = (diagonal@b.reshape(nq, -1, 1)).reshape(b.shape)
    return {"hermitian_relative_error": herm, "transfer_composition_relative_error": agreement,
            "independent_q_gram_errors": residuals, "off_diagonal_mode_frobenius_fraction": off_fraction,
            "diagonal_mode_negative_control_relative_action_error": rel(diagonal_action, normal.apply(b)),
            "retained_bytes": normal.cache_bytes}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"reports/acfo_radial_physical_transfer_v1")
    args = parser.parse_args()
    out = args.output
    if (out/"summary.json").exists():
        raise SystemExit("Existing summary preserved; choose a new output path.")
    protocol_path = ROOT/"validation_contracts/acfo_radial_physical_transfer_v1.json"
    p = json.loads(protocol_path.read_text(encoding="utf-8"))
    parent = ROOT/p["parent_report"]
    previous = json.loads((parent/"summary.json").read_text(encoding="utf-8"))
    receipts = json.loads((parent/"receipt.json").read_text(encoding="utf-8"))
    assert previous["passed_case_count"] == previous["case_count"] == 45
    used = [protocol_path, parent/"summary.json", parent/"receipt.json", parent/"coordinates.npz"]
    with np.load(parent/"coordinates.npz") as data:
        r, q, freq = data["radius_um"], data["q_perp"], data["radial_frequency_um_inv"]
    with np.load(ROOT/p["measurement_geometry"]) as measured:
        source_na = np.asarray(measured["source_na_xy"], dtype=float)
    cfg = json.loads((ROOT/p["geometry_source"]).read_text(encoding="utf-8"))["configuration"]
    physical = json.loads((ROOT/p["physics_source"]).read_text(encoding="utf-8"))["physical_model"]
    used.extend(ROOT/p[key] for key in ("measurement_geometry", "geometry_source", "physics_source"))
    assert q.size == p["radial_frequency_count"] == 350
    assert cfg["n_phi"] == p["angular_sample_count"] == 1024
    depths = np.linspace(-cfg["depth_half_range_um"], cfg["depth_half_range_um"], cfg["n_z"])
    dz = float(np.mean(np.diff(depths)))
    edges = np.linspace(0, cfg["radius_um"], r.size+1)
    area = np.pi*np.diff(edges**2)
    phi = (np.arange(cfg["n_phi"])+.5)*2*np.pi/cfg["n_phi"]
    blocks = {name: {} for name in p["timing"]["arms"]}
    rank_rows = []
    start_all = perf_counter()
    for m in sorted(set(abs(m) for m in p["modes"])):
        path = parent/f"q350_m{m}.npz"
        used.append(path)
        row = next(row for row in previous["blocks"] if row["id"] == f"q350_m{m}")
        ranks = next(row for row in row["rank_results"] if row["tolerance"] == p["parent_tolerance"])
        with np.load(path) as data:
            a = data["matrix"]
            blocks["dense"][m] = a.astype(complex)
            record = {"mode_abs": m}
            for arm, bkey, rkey in (("cpswf", "cpswf_basis", "cpswf_rank"), ("shared_svd", "svd_basis", "shared_svd_rank")):
                k = ranks[rkey]
                b = data[bkey][:, :k]
                blocks[arm][m] = PreparedRadialProjection.build(a, b, [])
                # Density-space radial error after the same finite-volume scaling.
                exact = a*area[None, :]
                approximate = ((a@b)@b.T)*area[None, :]
                record[arm] = {"rank": k, "density_space_relative_operator_error": float(linalg.norm(approximate-exact, 2)/linalg.norm(exact, 2))}
            rank_rows.append(record)
    for path in used:
        key = path.relative_to(ROOT).as_posix()
        if path.parent == parent and path.name != "receipt.json":
            assert digest(path) == receipts[key], f"Parent receipt mismatch: {path}"
    out.mkdir(parents=True, exist_ok=True)
    (out/"protocol.json").write_bytes(protocol_path.read_bytes())
    rng = np.random.default_rng(p["seed"])
    small = small_reference()
    rows = []
    for case in p["cases"]:
        depth, source = depths[case["depth_indices"]], source_na[case["source_indices"]]
        start = perf_counter()
        h, a, stats = aidt_transfer_functions_on_points(
            frequency_x=freq[:, None]*np.cos(phi)[None, :], frequency_y=freq[:, None]*np.sin(phi)[None, :],
            source_na_xy=source, wavelength_um=physical["wavelength_um"], medium_index=physical["medium_index"],
            objective_na=physical["objective_na"], depth_values_um=depth, dz_um=dz)
        transfer = PhysicalModalTransfer.build(p["modes"], phi, h, a, p["q_chunk"])
        prep_transfer = perf_counter()-start
        ops = {name: PreparedRadialAidt(ModalRadialMap.build(p["modes"], area, b, len(depth)), transfer) for name, b in blocks.items()}
        w1 = ((1+.2*np.arange(len(source)))[:, None, None]
              *(.7+.3*np.cos(phi)**2)[None, None, :]*(.8+.2*q/q[-1])[None, :, None])
        weights = [np.ones(transfer.data_shape), w1]
        normals, normal_rows = [], []
        for name, w in zip(p["weights"], weights):
            begin = perf_counter()
            normal = transfer.compile_normal(w)
            elapsed = perf_counter()-begin
            detail = gram_details(normal, transfer, w, rng)
            detail.update(weight=name, compilation_seconds=elapsed)
            normal_rows.append(detail)
            normals.append(normal)
        probe_rows = []
        for index in range(p["random_probes"]):
            x = random_complex(rng, ops["dense"].radial.input_shape)
            y = random_complex(rng, transfer.data_shape)
            exact_f, exact_a = ops["dense"].forward(x), ops["dense"].adjoint(y)
            exact_n = [ops["dense"].compiled_normal(x, normal) for normal in normals]
            for arm, op in ops.items():
                f, adj = op.forward(x), op.adjoint(y)
                dot = float(abs(np.vdot(f, y)-np.vdot(x, adj))/max(np.linalg.norm(f)*np.linalg.norm(y), 1e-300))
                nr = []
                for wi, (w, normal) in enumerate(zip(weights, normals)):
                    compiled, composed = op.compiled_normal(x, normal), op.normal(x, w)
                    nr.append({"weight": p["weights"][wi], "relative_l2_vs_dense": rel(compiled, exact_n[wi]),
                               "compiled_vs_composed_relative_l2": rel(compiled, composed),
                               "quadratic_form_real": float(np.vdot(x, compiled).real),
                               "quadratic_form_relative_imaginary": float(abs(np.vdot(x, compiled).imag)/max(abs(np.vdot(x, compiled)), 1e-300))})
                probe_rows.append({"probe": index, "arm": arm, "forward_relative_l2_vs_dense": rel(f, exact_f),
                                   "adjoint_relative_l2_vs_dense": rel(adj, exact_a), "adjoint_dot_error": dot, "normals": nr})
        print(json.dumps({"case": case["id"], "stage": "correctness_complete", "compilation_seconds": [v["compilation_seconds"] for v in normal_rows]}), flush=True)
        timings = time_arms(ops, normals[0], x, y, rng, p["timing"])
        th = p["thresholds"]
        checks = [max(small.values()) <= th["small_grid_direct_reference_error"]]
        for entry in probe_rows:
            checks.extend([entry["forward_relative_l2_vs_dense"] <= th["full_chain_relative_probe_error"],
                           entry["adjoint_relative_l2_vs_dense"] <= th["full_chain_relative_probe_error"],
                           entry["adjoint_dot_error"] <= th["adjoint_dot_error"]])
            for n in entry["normals"]:
                checks.extend([n["relative_l2_vs_dense"] <= th["full_chain_relative_probe_error"],
                               n["compiled_vs_composed_relative_l2"] <= th["gram_vs_composition_relative_error"],
                               n["quadratic_form_real"] >= 0])
        for n in normal_rows:
            checks.extend([n["hermitian_relative_error"] <= th["gram_hermitian_relative_error"],
                           n["transfer_composition_relative_error"] <= th["gram_vs_composition_relative_error"],
                           max(n["independent_q_gram_errors"]) <= th["gram_vs_composition_relative_error"]])
        cache = {}
        for arm, op in ops.items():
            rb = op.radial.cache_bytes
            cache[arm] = {"radial_bytes": rb, "forward_adjoint_total_bytes": rb+transfer.cache_bytes,
                          "standalone_one_weight_normal_total_bytes": rb+normals[0].cache_bytes,
                          "forward_adjoint_and_two_normals_total_bytes": rb+transfer.cache_bytes+sum(n.cache_bytes for n in normals)}
        # Persist small coordinate/provenance arrays, not disposable transfer tensors.
        coord_path = out/(case["id"]+"_coordinates.npz")
        np.savez_compressed(coord_path, radius_um=r, q_perp=q, frequency=freq, phi=phi,
                            area_scale=area, depth_um=depth, source_na_xy=source, dz_um=dz, modes=p["modes"])
        used.append(coord_path)
        row = {**case, "input_shape": list(x.shape), "data_shape": list(y.shape), "modal_shape": list(transfer.modal_shape),
               "transfer_preparation_seconds": prep_transfer, "transfer_cache_bytes": transfer.cache_bytes,
               "transfer_stats": {k: v.tolist() for k, v in stats.items()}, "normals": normal_rows,
               "probes": probe_rows, "timings": timings, "cache": cache,
               "explicit_intermediate_sizes": {"radial_modal_array_bytes": int(np.prod(transfer.modal_shape))*16,
                   "one_full_data_array_bytes": int(np.prod(transfer.data_shape))*16,
                   "one_chunk_lateral_two_channel_array_bytes": min(p["q_chunk"], q.size)*phi.size*len(depth)*2*16,
                   "note": "Individual array sizes, not their simultaneous peak or allocator/RSS measurements; compiled normal uses modal arrays and needs neither lateral nor data array."},
               "passed_checks": int(sum(checks)), "total_checks": len(checks), "passed": bool(all(checks))}
        rows.append(row)
        print(json.dumps({"case": case["id"], "passed": row["passed"], "cpswf_forward_dense_ratio": timings["cpswf/forward"]["dense_same_operation_over_arm"],
                          "cpswf_normal_composed_over_compiled": timings["cpswf/normal_compiled"]["same_arm_composed_over_compiled"]}), flush=True)
    result = {"schema": p["schema"], "created_utc": datetime.now(timezone.utc).isoformat(), "protocol_sha256": digest(protocol_path),
              "duration_seconds": perf_counter()-start_all, "environment": {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__,
                  "platform": platform.platform(), "blas_threads": 1}, "small_direct_reference": small, "reused_ranks": rank_rows,
              "case_count": len(rows), "passed_case_count": sum(row["passed"] for row in rows), "cases": rows,
              "claim_scope": p["claim_policy"]}
    summary_path = out/"summary.json"
    summary_path.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    used.extend([summary_path, out/"protocol.json", Path(__file__).resolve(), ROOT/"src/waxs_cake/radial_aidt.py",
                 ROOT/"src/waxs_cake/radial_cpswf.py", ROOT/"src/waxs_cake/aidt_acfo.py", ROOT/"tests/test_radial_aidt.py"])
    receipt = {path.relative_to(ROOT).as_posix(): digest(path) for path in used}
    (out/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(f"Completed {result['passed_case_count']}/{result['case_count']} cases in {result['duration_seconds']:.1f}s.", flush=True)
    return 0 if result["passed_case_count"] == result["case_count"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
