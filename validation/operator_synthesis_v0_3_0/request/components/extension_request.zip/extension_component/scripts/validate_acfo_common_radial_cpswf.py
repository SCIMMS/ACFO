"""Prespecified actual-grid common radial-block rank/composition pilot."""
from __future__ import annotations

import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
from time import perf_counter

import numpy as np
import scipy
from scipy import linalg

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from waxs_cake.axisymmetric_operator import PreparedAxisymmetricOperator
from waxs_cake.axisymmetric_manifold import AxisymmetricManifold
from waxs_cake.histogram import BinnedStructure
from waxs_cake.radial_cpswf import (
    PreparedRadialProjection, prefix_error, radial_block, sampled_cpswf_basis,
    smallest_shared_prefix, weighted_families,
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fft_probe(radius, q, mode, nphi):
    """Actual existing operator, only subselecting original coordinate arrays."""
    r = radius[np.linspace(0, radius.size-1, 11, dtype=int)]
    qq = q[np.linspace(0, q.size-1, 9, dtype=int)]
    beta_edges = np.linspace(0, 2*np.pi, nphi+1)
    template = BinnedStructure(hist=np.zeros((1, r.size, 1, nphi), dtype=complex),
        r_centers=r, z_centers=np.zeros(1), beta_centers=(beta_edges[:-1]+beta_edges[1:])/2,
        elements=("X",), r_edges=np.r_[0, r], z_edges=np.array([-0.5, 0.5]), beta_edges=beta_edges)
    manifold = AxisymmetricManifold(np.arange(qq.size, dtype=float), qq, np.zeros_like(qq))
    op = PreparedAxisymmetricOperator(template, manifold)
    actual = op.kernel_fft[:, :, mode]/(nphi*(1j**mode))
    return float(np.max(np.abs(actual-radial_block(qq, r, mode))))


def timed_forward(a, plans, rng, design):
    dense = np.asarray(a, dtype=complex)
    x = rng.normal(size=(a.shape[1], design["rhs"]))+1j*rng.normal(size=(a.shape[1], design["rhs"]))
    arms = {"dense": lambda: dense@x}
    for name, plan in plans.items():
        arms[name] = lambda plan=plan: plan.forward(x)
    raw = {key: [] for key in arms}
    keys = list(arms)
    for fn in arms.values():
        for _ in range(3):
            fn()
    for _ in range(design["trials"]):
        for index in rng.permutation(len(keys)):
            name = keys[index]
            start = perf_counter()
            for _ in range(design["inner"]):
                arms[name]()
            raw[name].append((perf_counter()-start)/design["inner"])
    return {key: {"seconds_per_call": val, "median_seconds": float(np.median(val)),
                  "dense_over_arm_ratio": float(np.median(raw["dense"])/np.median(val))} for key, val in raw.items()}


def verify_plan(a, weights, scales, plan, rng):
    n = a.shape[1]
    approx = plan.forward(np.eye(n))
    relative = [float(linalg.norm(np.sqrt(w)[:, None]*(approx-a), 2)/s) for w, s in zip(weights, scales)]
    normal_errors = []
    for j, w in enumerate(weights):
        exact = a.T@(w[:, None]*a)
        normal_errors.append(float(linalg.norm(plan.normal(np.eye(n), j)-exact, 2)/linalg.norm(exact, 2)))
    x = rng.normal(size=n)+1j*rng.normal(size=n)
    y = rng.normal(size=a.shape[0])+1j*rng.normal(size=a.shape[0])
    lhs, rhs = np.vdot(plan.forward(x), y), np.vdot(x, plan.adjoint(y))
    dot = float(abs(lhs-rhs)/max(linalg.norm(plan.forward(x))*linalg.norm(y), 1e-300))
    return {"weighted_forward_operator_errors": relative, "weighted_normal_operator_errors": normal_errors,
            "adjoint_dot_error": dot,
            "forward_bytes": plan.forward_bytes, "with_two_normal_cores_bytes": plan.all_operator_bytes}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"reports/acfo_common_radial_cpswf_v1")
    args = parser.parse_args()
    out = args.output
    if (out/"summary.json").exists():
        raise SystemExit("Existing summary preserved; choose a new output path.")
    protocol_path = ROOT/"validation_contracts/acfo_common_radial_cpswf_v1.json"
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    source_path, physics_path = ROOT/protocol["geometry_source"], ROOT/protocol["physics_source"]
    source = json.loads(source_path.read_text(encoding="utf-8"))
    physics = json.loads(physics_path.read_text(encoding="utf-8"))["physical_model"]
    cfg = source["configuration"]
    nr, nq, nphi, radius_max = cfg["n_r"], cfg["n_frequency"], cfg["n_phi"], cfg["radius_um"]
    assert (nr, nq, nphi, radius_max) == (350, 350, 1024, 56.875)
    r = (np.arange(nr)+0.5)*radius_max/nr
    frequency = (np.arange(nq)+0.5)*(0.98*physics["objective_na"]/physics["wavelength_um"])/nq
    q_all = 2*np.pi*frequency
    out.mkdir(parents=True, exist_ok=True)
    (out/"protocol.json").write_bytes(protocol_path.read_bytes())
    np.savez_compressed(out/"coordinates.npz", radius_um=r, radial_frequency_um_inv=frequency, q_perp=q_all)
    rng = np.random.default_rng(protocol["seed"])
    rows, evidence_files = [], []
    start_all = perf_counter()
    thresholds = protocol["numerical_thresholds"]
    for count in protocol["frequency_prefix_counts"]:
        q = q_all[:count]
        weights = [np.ones(count), 0.35+0.9*np.sin(np.linspace(0, np.pi, count))**2+0.15*np.linspace(0, 1, count)]
        c = float(q[-1]*radius_max)
        for mode in protocol["modes"]:
            name = f"q{count}_m{mode}"
            begin = perf_counter()
            a = radial_block(q, r, mode)
            kernel_seconds = perf_counter()-begin
            angular_error = fft_probe(r, q, mode, nphi)
            dim = max(nr, int(np.ceil(c))+mode+48)
            begin = perf_counter()
            p, basis_info = sampled_cpswf_basis(r, radius_max, q[-1], mode, dim)
            basis_seconds = perf_counter()-begin
            p_pad, _ = sampled_cpswf_basis(r, radius_max, q[-1], mode, dim+protocol["basis_padding_audit"])
            orth_error = float(linalg.norm(p.T@p-np.eye(p.shape[1]), 2))
            blocks, scales = weighted_families(a, weights)
            begin = perf_counter()
            singular = [linalg.svdvals(block) for block in blocks]
            _, stack_s, stack_vh = linalg.svd(np.vstack(blocks), full_matrices=False)
            svd_seconds = perf_counter()-begin
            p_svd = stack_vh.T
            ranks, timing_plans = [], {}
            saved = {"matrix": a, "weights": np.asarray(weights), "scales": scales,
                     "cpswf_basis": p, "svd_basis": p_svd, "svd_values": np.asarray(singular),
                     "stack_singular_values": stack_s, "qr_diagonal": basis_info["qr_diagonal"]}
            for tol in protocol["relative_operator_tolerances"]:
                begin = perf_counter()
                kc, cc = smallest_shared_prefix(blocks, p, tol)
                ks, sc = smallest_shared_prefix(blocks, p_svd, tol)
                selection_seconds = perf_counter()-begin
                best_each = [int(np.sum(s > tol)) for s in singular]
                entry = {"tolerance": tol, "individual_optimal_svd_ranks": best_each,
                         "common_rank_lower_bound": max(best_each), "shared_svd_rank": ks, "cpswf_rank": kc,
                         "cpswf_rank_search": cc, "shared_svd_rank_search": sc,
                         "selection_seconds": selection_seconds, "arms": {}}
                for label, basis, rank in (("shared_svd", p_svd, ks), ("cpswf", p, kc)):
                    if rank is None:
                        entry["arms"][label] = {"resolved": False, "numerical_criteria_passed": False}
                        continue
                    begin = perf_counter()
                    plan = PreparedRadialProjection.build(a, basis[:, :rank], weights)
                    materialize_seconds = perf_counter()-begin
                    audit = verify_plan(a, weights, scales, plan, rng)
                    audit.update(resolved=True, materialize_seconds=materialize_seconds,
                                 forward_storage_ratio=plan.forward_bytes/(16*a.size))
                    audit["numerical_criteria_passed"] = (
                        max(audit["weighted_forward_operator_errors"]) <= tol+thresholds["compression_roundoff_slack"]
                        and max(audit["weighted_normal_operator_errors"]) <= 2*tol+tol*tol+thresholds["normal_roundoff_slack"]
                        and audit["adjoint_dot_error"] <= thresholds["adjoint_dot_error"])
                    entry["arms"][label] = audit
                    if tol == protocol["primary_tolerance"]:
                        timing_plans[label] = plan
                if kc is not None and p_pad.shape[1] >= kc:
                    ap, app = (a@p[:, :kc])@p[:, :kc].T, (a@p_pad[:, :kc])@p_pad[:, :kc].T
                    pad_change = float(linalg.norm(ap-app, 2)/scales[0])
                else:
                    pad_change = None
                entry["padding_projected_operator_change"] = pad_change
                entry["passed"] = (angular_error <= thresholds["angular_fft_agreement"]
                    and orth_error <= thresholds["basis_orthogonality"]
                    and pad_change is not None and pad_change <= thresholds["basis_padding_projected_operator_change"]
                    and all(v["numerical_criteria_passed"] for v in entry["arms"].values()))
                ranks.append(entry)
            timing = timed_forward(a, timing_plans, rng, protocol["hot_timing"])
            evidence_path = out/(name+".npz")
            np.savez_compressed(evidence_path, **saved)
            evidence_files.append(evidence_path)
            row = {"id": name, "mode": mode, "frequency_count": count, "radius_count": nr, "c": c,
                   "primary_band": count == protocol["primary_frequency_count"], "jacobi_dimension": dim,
                   "resolved_cpswf_prefix": p.shape[1], "angular_fft_max_abs_error": angular_error,
                   "basis_orthogonality_spectral_error": orth_error,
                   "preparation_seconds": {"kernel": kernel_seconds, "cpswf_basis": basis_seconds,
                                           "svd_family_factorizations": svd_seconds},
                   "rank_results": ranks, "forward_timing_at_primary_tolerance": timing}
            rows.append(row)
            primary = next(v for v in ranks if v["tolerance"] == protocol["primary_tolerance"])
            print(json.dumps({"block": name, "c": c, "cpswf": primary["cpswf_rank"],
                              "shared_svd": primary["shared_svd_rank"], "svd_lower_bound": primary["common_rank_lower_bound"],
                              "passed_all_eps": all(v["passed"] for v in ranks)}), flush=True)
    payload = {"schema": protocol["schema"], "created_utc": datetime.now(timezone.utc).isoformat(),
               "duration_seconds": perf_counter()-start_all,
               "environment": {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__,
                               "platform": platform.platform(), "blas_thread_environment": 1},
               "protocol_sha256": digest(protocol_path),
               "geometry": {"radius_um": radius_max, "n_r": nr, "n_frequency": nq, "n_phi": nphi,
                            "wavelength_um": physics["wavelength_um"], "objective_na": physics["objective_na"]},
               "block_count": len(rows), "case_count": sum(len(row["rank_results"]) for row in rows),
               "passed_case_count": sum(v["passed"] for row in rows for v in row["rank_results"]), "blocks": rows}
    (out/"summary.json").write_text(json.dumps(payload, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    files = [protocol_path, source_path, physics_path, out/"coordinates.npz", out/"summary.json", *evidence_files,
             ROOT/"src/waxs_cake/radial_cpswf.py", ROOT/"src/waxs_cake/finite_hankel.py", Path(__file__).resolve(),
             ROOT/"tests/test_radial_cpswf.py"]
    receipt = {str(path.relative_to(ROOT)).replace("\\", "/"): digest(path) for path in files}
    (out/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(f"Completed {payload['passed_case_count']}/{payload['case_count']} cases in {payload['duration_seconds']:.1f}s.")
    return 0 if payload["passed_case_count"] == payload["case_count"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
