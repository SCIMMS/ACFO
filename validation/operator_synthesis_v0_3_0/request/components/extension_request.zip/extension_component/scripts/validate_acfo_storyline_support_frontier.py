"""No-allocation support accounting; deliberately not a full-support simulation."""
import argparse
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def calculate(qmax, radius, nq, nphi, depth, selected, contract):
    kernel = int(np.ceil(qmax*radius))
    required = max(kernel, contract["data_bandlimit"])+contract["mode_padding"]
    counts = [len(selected), 2*contract["data_bandlimit"]+1, 2*required+1]
    rows = []
    for name, nm in zip(contract["cases"], counts):
        byte_count = 16*nq*(nm*depth*2)**2
        rows.append({"case": name, "mode_count": nm, "dense_gram_retained_bytes": byte_count,
                     "exceeds_prespecified_normal_limit": byte_count > contract["normal_byte_limit"],
                     "allocation_attempted": False, "numerical_validation": False})
    return {"schema": "acfo-storyline-full-support-accounting-v2", "qmax_R": qmax*radius,
            "H_kernel": kernel, "H_data": contract["data_bandlimit"], "padding": contract["mode_padding"],
            "H_req": required, "n_phi": nphi, "kernel_sampling_sufficient": nphi > 2*required,
            "normal_byte_limit": contract["normal_byte_limit"], "rows": rows,
            "accounting_complete": True, "full_support_numerics_passed": None,
            "scope": "Kernel expansion support is distinct from input-density modes. The API adds padding to an explicitly declared input band. These byte estimates neither instantiate that API with all kernel modes nor demonstrate full-support accuracy, OOM or peak memory."}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--protocol", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    with np.load(ROOT/"reports/acfo_radial_physical_transfer_v1/three_illuminations_five_depths_coordinates.npz") as d:
        qmax = float(2*np.pi*d["frequency"][-1])
        nq, depth = len(d["frequency"]), len(d["depth_um"])
    out = calculate(qmax, 56.875, nq, 1024, depth, [-128,-64,-16,-4,0,4,16,64,128], protocol["full_support_frontier"])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
    return 0 if out["kernel_sampling_sufficient"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
