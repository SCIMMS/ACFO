"""Recompute cached radial errors and reconcile API preparation evidence."""
import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import linalg, special

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"reports/acfo_geometry_preparation_api_v1")
    out = parser.parse_args().output
    summary = json.loads((out/"summary.json").read_text(encoding="utf-8"))
    protocol = json.loads((out/"protocol.json").read_text(encoding="utf-8"))
    receipt = json.loads((out/"receipt.json").read_text(encoding="utf-8"))
    checks, radial_errors = [], []
    def check(name, condition):
        checks.append({"name": name, "passed": bool(condition)})
    for path, expected in receipt.items():
        check("hash:"+path, sha(ROOT/path) == expected)
    check("protocol identity", sha(out/"protocol.json") == summary["protocol_sha256"])
    check("check accounting", summary["passed_checks"] == sum(c["passed"] for c in summary["checks"]) == summary["check_count"])
    fresh, cached = summary["fresh_preparation"], summary["cached_preparation"]
    check("fresh preparation requested", not fresh["cache_hit"])
    check("cache key parity", cached["cache_hit"] and fresh["radial_key"] == cached["radial_key"])
    with np.load(out/"radial_cache.npz", allow_pickle=False) as d:
        meta = json.loads(str(d["metadata_json"]))
        desc = meta["descriptor"]
        key = hashlib.sha256(json.dumps(desc, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        check("cache descriptor key", key == meta["radial_key"] == fresh["radial_key"])
        r, q, area = map(np.asarray, (desc["radius_um"], desc["q_perp"], desc["area_scale"]))
        retained = area.nbytes
        for record in fresh["blocks"]:
            m, k = record["mode_abs"], record["rank"]
            b, c = d[f"basis_{m}"], d[f"reduced_{m}"]
            a = special.jv(m, q[:, None]*r[None, :])
            check(f"rank shape {m}", b.shape == (r.size, k) and c.shape == (q.size, k))
            check(f"C = A P {m}", linalg.norm(c-a@b, 2)/linalg.norm(c, 2) <= 1e-12)
            error = float(linalg.norm((c@b.T-a)*area, 2)/linalg.norm(a*area, 2))
            check(f"density norm error {m}", error <= protocol["radial_tolerance"]+protocol["thresholds"]["radial_roundoff_slack"])
            check(f"reported density error {m}", np.isclose(error, record["density_relative_operator_errors"][0], rtol=1e-5, atol=1e-14))
            check(f"orthogonality {m}", linalg.norm(b.conj().T@b-np.eye(k), 2) <= 1e-10)
            check(f"conservative prefix criterion {m}", max(record["rank_search_bound"]) <= protocol["radial_tolerance"]
                  and max(record["previous_prefix_bound"]) > protocol["radial_tolerance"])
            check(f"padding audit {m}", record["padding_change_relative_operator_error"] <= protocol["radial_tolerance"]/4+5e-13)
            radial_errors.append({"mode_abs": m, "rank": k, "density_relative_operator_error": error})
            retained += b.nbytes+c.nbytes
        check("radial retained bytes", retained == fresh["radial_retained_bytes"])
    check("all probes present", [p["probe"] for p in summary["probes"]] == list(range(protocol["full_chain_probes"])))
    for p in summary["probes"]:
        check(f"dense parity {p['probe']}", max(p["fresh_vs_dense_forward"], p["fresh_vs_dense_adjoint"]) <= protocol["thresholds"]["full_chain_relative_probe_error"])
        check(f"cache actions {p['probe']}", p["cache_vs_fresh_forward"] == p["cache_vs_fresh_adjoint"] == 0)
        check(f"legacy actions {p['probe']}", max(p["legacy_vs_saved_forward"], p["legacy_vs_saved_adjoint"]) <= protocol["thresholds"]["legacy_action_error"])
        for n in p["normal_results"]:
            check(f"normal {p['probe']} {n['weight']}", n["normal_vs_composition"] <= protocol["thresholds"]["normal_composition_error"]
                  and n["normal_vs_dense"] <= protocol["thresholds"]["full_chain_relative_probe_error"] and n["cached_composition_vs_fresh"] == 0)
    for r in summary["legacy_rank_comparison"]:
        check(f"source metric rank {r['mode_abs']}", r["saved_rank"] == r["fresh_rank"])
    for label in ("fresh_preparation", "cached_preparation", "legacy_preparation"):
        report = summary[label]
        check(label+" adjoint", report["adjoint_dot_error"] <= protocol["thresholds"]["adjoint_dot_error"])
        subtotal = report["radial_preparation_or_load_seconds"]+report["transfer_preparation_seconds"]
        check(label+" setup includes both phases", report["total_preparation_seconds"] >= subtotal > 0)
    expected_normal_bytes = fresh["radial_retained_bytes"]+16*350*(9*5*2)**2
    for normal in summary["normal_preparation"]:
        check(normal["weight"]+" standalone bytes", normal["standalone_retained_bytes"] == expected_normal_bytes)
    result = {"schema": "acfo-geometry-preparation-api-audit-v1", "checks": checks,
              "passed": all(c["passed"] for c in checks), "passed_count": sum(c["passed"] for c in checks),
              "check_count": len(checks), "independent_cached_radial_checks": radial_errors,
              "scope": "No prepared API import. Recomputed radial kernel, reduced image, density spectral error, orthogonality and storage from cache; reconciled source hashes and reported full-chain probes. Full-chain output arrays are not independently rerun by this audit."}
    (out/"audit.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    if not result["passed"]:
        print(json.dumps([c for c in checks if not c["passed"]], indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
