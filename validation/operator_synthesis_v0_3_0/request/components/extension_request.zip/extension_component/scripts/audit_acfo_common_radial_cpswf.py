"""Independent saved-array audit; does not import the radial implementation."""
from __future__ import annotations
import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import linalg, special


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=root/"reports/acfo_common_radial_cpswf_v1")
    args = parser.parse_args()
    folder = args.output
    data = json.loads((folder/"summary.json").read_text(encoding="utf-8"))
    design = json.loads((folder/"protocol.json").read_text(encoding="utf-8"))
    receipt = json.loads((folder/"receipt.json").read_text(encoding="utf-8"))
    checks = {"sha256:"+name: hashlib.sha256((root/name).read_bytes()).hexdigest() == digest for name, digest in receipt.items()}
    checks["protocol_snapshot"] = hashlib.sha256((folder/"protocol.json").read_bytes()).hexdigest() == data["protocol_sha256"]
    expected = {(n, m, eps) for n in design["frequency_prefix_counts"] for m in design["modes"] for eps in design["relative_operator_tolerances"]}
    actual = {(b["frequency_count"], b["mode"], v["tolerance"]) for b in data["blocks"] for v in b["rank_results"]}
    checks["complete_prespecified_cases"] = expected == actual and len(actual) == data["case_count"]
    cfg = data["geometry"]
    coords = np.load(folder/"coordinates.npz")
    r, q = coords["radius_um"], coords["q_perp"]
    edges = np.linspace(0, cfg["radius_um"], cfg["n_r"]+1)
    coordinate_roundoff = float(np.max(np.abs(r-0.5*(edges[:-1]+edges[1:]))))
    checks["source_radius_midpoints"] = coordinate_roundoff < 1e-13
    reconstructed_q = 2*np.pi*((np.arange(cfg["n_frequency"])+0.5)*(0.98*cfg["objective_na"]/cfg["wavelength_um"])/cfg["n_frequency"])
    checks["source_q_coordinates"] = np.array_equal(q, reconstructed_q)
    recomputed = []
    for block in data["blocks"]:
        name = block["id"]
        with np.load(folder/(name+".npz")) as evidence:
            a = evidence["matrix"]
            w = evidence["weights"]
            expected_a = special.jv(block["mode"], q[:block["frequency_count"], None]*r[None, :])
            checks[name+":kernel"] = np.array_equal(a, expected_a)
            norms = [linalg.svdvals(np.sqrt(weight)[:, None]*a)[0] for weight in w]
            spectra = [linalg.svdvals(np.sqrt(weight)[:, None]*a)/norm for weight, norm in zip(w, norms)]
            for result in block["rank_results"]:
                tol = result["tolerance"]
                tag = f"{name}:{tol:g}"
                optimal = [int(np.sum(s > tol)) for s in spectra]
                checks[tag+":svd_lower_bound"] = optimal == result["individual_optimal_svd_ranks"] and max(optimal) == result["common_rank_lower_bound"]
                for arm, key, rank_key in (("cpswf", "cpswf_basis", "cpswf_rank"), ("shared_svd", "svd_basis", "shared_svd_rank")):
                    k = result[rank_key]
                    if k is None:
                        checks[tag+":"+arm+":resolved"] = False
                        continue
                    p = evidence[key][:, :k]
                    reduced = a@p
                    approximation = reduced@p.T
                    err = [float(linalg.norm(np.sqrt(weight)[:, None]*(a-approximation), 2)/norm) for weight, norm in zip(w, norms)]
                    stored = result["arms"][arm]
                    checks[tag+":"+arm+":accuracy"] = max(err) <= tol+design["numerical_thresholds"]["compression_roundoff_slack"]
                    checks[tag+":"+arm+":reported_error"] = np.allclose(err, stored["weighted_forward_operator_errors"], rtol=1e-4, atol=1e-14)
                    checks[tag+":"+arm+":bytes"] = 16*k*(a.shape[0]+a.shape[1]) == stored["forward_bytes"]
                    if k:
                        previous = evidence[key][:, :k-1]
                        err_previous = [linalg.norm(np.sqrt(weight)[:, None]*(a-(a@previous)@previous.T), 2)/norm for weight, norm in zip(w, norms)]
                        checks[tag+":"+arm+":minimal_prefix"] = max(err_previous) > tol
                    if tol == design["primary_tolerance"]:
                        ne = []
                        for weight in w:
                            exact = a.T@(weight[:, None]*a)
                            compact = p@(reduced.T@(weight[:, None]*reduced))@p.T
                            ne.append(float(linalg.norm(exact-compact, 2)/linalg.norm(exact, 2)))
                        checks[tag+":"+arm+":normal"] = np.allclose(ne, stored["weighted_normal_operator_errors"], rtol=1e-4, atol=1e-14)
                recomputed.append({"id": tag, "svd_lower_bound": max(optimal), "cpswf_rank": result["cpswf_rank"]})
        timing = block["forward_timing_at_primary_tolerance"]
        for arm, value in timing.items():
            raw = value["seconds_per_call"]
            checks[name+":"+arm+":timing"] = len(raw) == design["hot_timing"]["trials"] and min(raw) > 0 and np.isclose(np.median(raw), value["median_seconds"], rtol=1e-12)
    result = {"assessment": "Share with caveats" if all(checks.values()) else "Needs revision",
              "passed": all(checks.values()), "checks_passed": sum(bool(v) for v in checks.values()), "checks_total": len(checks),
              "radius_midpoint_roundoff_um": coordinate_roundoff,
              "checks": {key: bool(value) for key, value in checks.items()}, "recomputed": recomputed,
              "caveats": ["Actual-grid radial kernel only, five modes; no PTF/ATF, axial contraction or measured-data reconstruction.",
                          "Two positive diagonal weight profiles; no general operator-family or all-mode guarantee.",
                          "No optimized full ACFO or GPU speed claim; retained-array count is not peak memory.",
                          "Basis and aggregate diagnostic SVD preparation timings are not matched minimal-setup baselines."],
              "blockers": [key for key, value in checks.items() if not value]}
    (folder/"audit.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(f"{result['assessment']}: {result['checks_passed']}/{result['checks_total']} checks passed.")
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
