"""Independent receipt, source-coordinate, rank, density-error and metric audit.

No new physical-chain module is imported. Direct-DFT and full-chain numerical
checks live in the validation run and independent-formula unit tests; this
audit does not claim a second full reconstruction of every chain output.
"""
from __future__ import annotations
import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import linalg

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"reports/acfo_radial_physical_transfer_v1")
    out = parser.parse_args().output
    summary = json.loads((out/"summary.json").read_text(encoding="utf-8"))
    protocol = json.loads((out/"protocol.json").read_text(encoding="utf-8"))
    receipt = json.loads((out/"receipt.json").read_text(encoding="utf-8"))
    checks = []
    def check(name, value):
        checks.append({"check": name, "passed": bool(value)})
    for name, expected in receipt.items():
        check("sha256:"+name, sha(ROOT/name) == expected)
    check("protocol digest", sha(out/"protocol.json") == summary["protocol_sha256"])
    check("case completeness", [c["id"] for c in summary["cases"]] == [c["id"] for c in protocol["cases"]])
    source = json.loads((ROOT/protocol["geometry_source"]).read_text(encoding="utf-8"))
    check("measurement contract source digest", sha(ROOT/protocol["measurement_geometry"]) == source["measured_data"]["contract_sha256"])
    cfg = source["configuration"]
    with np.load(ROOT/protocol["measurement_geometry"]) as d:
        source_na = d["source_na_xy"]
    parent = ROOT/protocol["parent_report"]
    old = json.loads((parent/"summary.json").read_text(encoding="utf-8"))
    edges = np.linspace(0, cfg["radius_um"], cfg["n_r"]+1)
    area = np.pi*np.diff(edges**2)
    for rank in summary["reused_ranks"]:
        m = rank["mode_abs"]
        old_row = next(row for row in old["blocks"] if row["id"] == f"q350_m{m}")
        old_rank = next(row for row in old_row["rank_results"] if row["tolerance"] == protocol["parent_tolerance"])
        with np.load(parent/f"q350_m{m}.npz") as data:
            a = data["matrix"]
            for arm, bkey, key in (("cpswf", "cpswf_basis", "cpswf_rank"), ("shared_svd", "svd_basis", "shared_svd_rank")):
                k = rank[arm]["rank"]
                check(f"rank unchanged {m} {arm}", k == old_rank[key])
                b = data[bkey][:, :k]
                density = a*area
                error = linalg.norm(((a@b)@b.T)*area-density, 2)/linalg.norm(density, 2)
                check(f"density error {m} {arm}", np.isclose(error, rank[arm]["density_space_relative_operator_error"], rtol=1e-5, atol=1e-14))
    th = protocol["thresholds"]
    check("small direct reference", max(summary["small_direct_reference"].values()) <= th["small_grid_direct_reference_error"])
    compact = []
    for c, spec in zip(summary["cases"], protocol["cases"]):
        cid = c["id"]
        nz, ns, nq, nm, nphi = len(spec["depth_indices"]), len(spec["source_indices"]), 350, len(protocol["modes"]), 1024
        with np.load(out/(cid+"_coordinates.npz")) as d:
            check(cid+" sources", np.array_equal(d["source_na_xy"], source_na[spec["source_indices"]]))
            check(cid+" depth selection", np.array_equal(d["depth_um"], np.linspace(-25.5, 25.5, 35)[spec["depth_indices"]]))
            check(cid+" unchanged dz", float(d["dz_um"]) == 1.5)
            check(cid+" area metric", np.array_equal(d["area_scale"], area))
            check(cid+" angular modes", np.array_equal(d["modes"], protocol["modes"]))
            check(cid+" angular grid", np.array_equal(d["phi"], (np.arange(nphi)+.5)*2*np.pi/nphi))
        check(cid+" transfer bytes", c["transfer_cache_bytes"] == 16*(2*ns*nq*nphi*nz+nphi*nm))
        gram_bytes = 16*nq*(nm*nz*2)**2
        for g in c["normals"]:
            check(cid+g["weight"]+" Gram bytes", g["retained_bytes"] == gram_bytes)
            check(cid+g["weight"]+" Hermitian", g["hermitian_relative_error"] <= th["gram_hermitian_relative_error"])
            check(cid+g["weight"]+" transfer composition", g["transfer_composition_relative_error"] <= th["gram_vs_composition_relative_error"])
            check(cid+g["weight"]+" direct selected-q lift", max(g["independent_q_gram_errors"]) <= th["gram_vs_composition_relative_error"])
        expected_pairs = {(i, a) for i in range(protocol["random_probes"]) for a in protocol["timing"]["arms"]}
        check(cid+" all probes", {(x["probe"], x["arm"]) for x in c["probes"]} == expected_pairs)
        for entry in c["probes"]:
            tag = cid+str(entry["probe"])+entry["arm"]
            for key in ("forward_relative_l2_vs_dense", "adjoint_relative_l2_vs_dense"):
                check(tag+key, entry[key] <= th["full_chain_relative_probe_error"])
            check(tag+" dot", entry["adjoint_dot_error"] <= th["adjoint_dot_error"])
            check(tag+" weight completeness", [n["weight"] for n in entry["normals"]] == protocol["weights"])
            for n in entry["normals"]:
                check(tag+n["weight"]+" normal error", n["relative_l2_vs_dense"] <= th["full_chain_relative_probe_error"])
                check(tag+n["weight"]+" compiled agreement", n["compiled_vs_composed_relative_l2"] <= th["gram_vs_composition_relative_error"])
                check(tag+n["weight"]+" PSD probe", n["quadratic_form_real"] >= 0)
        for key, t in c["timings"].items():
            arm, operation = key.split("/")
            median = float(np.median(t["raw_seconds"]))
            check(cid+key+" timing count", len(t["raw_seconds"]) == protocol["timing"]["trials"])
            check(cid+key+" positive timing", min(t["raw_seconds"]) > 0)
            check(cid+key+" median", np.isclose(median, t["median_seconds"], rtol=1e-13))
            ratio = np.median(c["timings"]["dense/"+operation]["raw_seconds"])/median
            check(cid+key+" matched ratio", np.isclose(ratio, t["dense_same_operation_over_arm"], rtol=1e-13))
            if operation == "normal_compiled":
                ratio2 = np.median(c["timings"][arm+"/normal_composed"]["raw_seconds"])/median
                check(cid+key+" compilation ratio", np.isclose(ratio2, t["same_arm_composed_over_compiled"], rtol=1e-13))
        for arm, arrays in c["cache"].items():
            rank_sum = sum(r[arm]["rank"] for r in summary["reused_ranks"]) if arm != "dense" else 0
            radial_bytes = area.nbytes+(16*350*350*5 if arm == "dense" else 16*(350+350)*rank_sum)
            check(cid+arm+" radial bytes", arrays["radial_bytes"] == radial_bytes)
            check(cid+arm+" full cache", arrays["forward_adjoint_total_bytes"] == radial_bytes+c["transfer_cache_bytes"])
            check(cid+arm+" standalone normal sufficient cache", arrays["standalone_one_weight_normal_total_bytes"] == radial_bytes+gram_bytes)
            check(cid+arm+" complete family cache", arrays["forward_adjoint_and_two_normals_total_bytes"] == radial_bytes+c["transfer_cache_bytes"]+2*gram_bytes)
        probe = c["probes"]
        compact.append({"case": cid,
            "max_forward_error": max(p["forward_relative_l2_vs_dense"] for p in probe),
            "max_adjoint_error": max(p["adjoint_relative_l2_vs_dense"] for p in probe),
            "max_normal_error": max(n["relative_l2_vs_dense"] for p in probe for n in p["normals"]),
            "max_dot_error": max(p["adjoint_dot_error"] for p in probe),
            "max_compiled_composed_error": max(n["compiled_vs_composed_relative_l2"] for p in probe for n in p["normals"]),
            "timings_ms": {key: round(t["median_seconds"]*1000, 4) for key, t in c["timings"].items()},
            "normal_offmode_fraction": [n["off_diagonal_mode_frobenius_fraction"] for n in c["normals"]],
            "diagonal_mode_negative_control": [n["diagonal_mode_negative_control_relative_action_error"] for n in c["normals"]],
            "cache_MiB": {arm: {key: round(v/2**20, 4) for key, v in sizes.items()} for arm, sizes in c["cache"].items()}})
    result = {"schema": "acfo-radial-physical-transfer-audit-v1", "passed": all(c["passed"] for c in checks),
              "check_count": len(checks), "passed_count": sum(c["passed"] for c in checks),
              "scope": __doc__, "checks": checks, "compact_results": compact}
    (out/"audit.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    failures = [c for c in checks if not c["passed"]]
    if failures:
        print(json.dumps(failures, indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
