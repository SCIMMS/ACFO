"""Fresh geometry preparation, previous-basis parity and checked cache reuse."""
from __future__ import annotations
import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_key] = "1"
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
from time import perf_counter
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"src"))
from waxs_cake.prepared_cpswf_aidt import AidtCpswfGeometry, prepare_cpswf_aidt, PreparationLimits
from waxs_cake.radial_aidt import ModalRadialMap, PreparedRadialAidt
from waxs_cake.radial_cpswf import PreparedRadialProjection, radial_block


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def relative(x, ref):
    return float(np.linalg.norm(x-ref)/max(np.linalg.norm(ref), 1e-300))


def random_complex(rng, shape):
    return rng.normal(size=shape)+1j*rng.normal(size=shape)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"reports/acfo_geometry_preparation_api_v1")
    out = parser.parse_args().output
    if (out/"summary.json").exists() or (out/"radial_cache.npz").exists():
        raise SystemExit("Existing result/cache preserved; choose a new output directory.")
    protocol_path = ROOT/"validation_contracts/acfo_geometry_preparation_api_v1.json"
    p = json.loads(protocol_path.read_text(encoding="utf-8"))
    physics = json.loads((ROOT/p["physics_source"]).read_text(encoding="utf-8"))["physical_model"]
    with np.load(ROOT/p["geometry_source"]) as d:
        radius, frequency, depth, source = d["radius_um"], d["frequency"], d["depth_um"], d["source_na_xy"]
        area, dz = d["area_scale"], float(d["dz_um"])
    # Recover original finite-volume edges from the saved 2*pi annular areas.
    # The known original uniform grid is retained, not re-fitted to data.
    edges = np.linspace(0, 56.875, len(radius)+1)
    assert np.array_equal(np.pi*np.diff(edges**2), area)
    g = AidtCpswfGeometry(r_edges_um=edges, radial_frequency_um_inv=frequency, n_phi=p["n_phi"],
        modes=tuple(p["modes"]), depth_values_um=depth, dz_um=dz, source_na_xy=source,
        wavelength_um=physics["wavelength_um"], medium_index=physics["medium_index"],
        objective_na=physics["objective_na"], angular_padding=p["angular_padding"])
    out.mkdir(parents=True, exist_ok=True)
    (out/"protocol.json").write_bytes(protocol_path.read_bytes())
    began = perf_counter()
    limits = PreparationLimits(max_normal_bytes=p["normal_limit_bytes"])
    fresh = prepare_cpswf_aidt(g, radial_tolerance=p["radial_tolerance"], limits=limits)
    print(json.dumps({"stage": "fresh_geometry_prepared", "seconds": fresh.report["total_preparation_seconds"],
                      "ranks": {r["mode_abs"]: r["rank"] for r in fresh.report["blocks"]}}), flush=True)
    cache = out/"radial_cache.npz"
    fresh.save_radial_cache(cache)
    cached = prepare_cpswf_aidt(g, radial_tolerance=p["radial_tolerance"], radial_cache=cache, limits=limits)
    normals = [fresh.prepare_normal()]
    w = ((1+.2*np.arange(len(source)))[:, None, None]*(.7+.3*np.cos(g.phi)**2)[None, None, :]
         *(.8+.2*g.q_perp/g.q_perp[-1])[None, :, None])
    normals.append(fresh.prepare_normal(w))
    # A pre-existing source-space metric/profile is explicitly requested for
    # compatibility, separate from the new default density metric.
    nq = len(frequency)
    old_weights = [np.ones(nq), .35+.9*np.sin(np.linspace(0, np.pi, nq))**2+.15*np.linspace(0, 1, nq)]
    legacy = prepare_cpswf_aidt(g, radial_tolerance=p["radial_tolerance"],
                              rank_metric="source_strength", radial_weights=old_weights, limits=limits)
    parent = ROOT/p["legacy_basis_source"]
    previous = json.loads((parent/"summary.json").read_text(encoding="utf-8"))
    saved_blocks, legacy_rows = {}, []
    evidence = [protocol_path, ROOT/p["geometry_source"], ROOT/p["physics_source"], parent/"summary.json"]
    for row in legacy.report["blocks"]:
        m = row["mode_abs"]
        old = next(b for b in previous["blocks"] if b["id"] == f"q350_m{m}")
        old_rank = next(r for r in old["rank_results"] if r["tolerance"] == p["radial_tolerance"])["cpswf_rank"]
        block_path = parent/f"q350_m{m}.npz"
        with np.load(block_path) as d:
            saved_blocks[m] = PreparedRadialProjection.build(d["matrix"], d["cpswf_basis"][:, :old_rank], [])
        legacy_rows.append({"mode_abs": m, "saved_rank": old_rank, "fresh_rank": row["rank"]})
        evidence.append(block_path)
    old_op = PreparedRadialAidt(ModalRadialMap.build(g.modes, g.area_scale, saved_blocks, len(depth)), legacy.operator.transfer)
    dense_blocks = {m: radial_block(g.q_perp, g.radius_um, m) for m in saved_blocks}
    dense = PreparedRadialAidt(ModalRadialMap.build(g.modes, g.area_scale, dense_blocks, len(depth)), fresh.operator.transfer)
    checks, probes = [], []
    def check(name, passed):
        checks.append({"name": name, "passed": bool(passed)})
    check("cache hit", cached.report["cache_hit"])
    check("cache key matches fresh", cached.report["radial_key"] == fresh.report["radial_key"])
    for record in fresh.report["blocks"]:
        check(f"density spectral error {record['mode_abs']}", max(record["density_relative_operator_errors"]) <= p["radial_tolerance"]+p["thresholds"]["radial_roundoff_slack"])
    for row in legacy_rows:
        check(f"legacy rank {row['mode_abs']}", row["saved_rank"] == row["fresh_rank"])
    rng = np.random.default_rng(p["seed"])
    for index in range(p["full_chain_probes"]):
        x, y = random_complex(rng, fresh.input_shape), random_complex(rng, fresh.data_shape)
        fx, ay = fresh.forward(x), fresh.adjoint(y)
        entry = {"probe": index, "fresh_vs_dense_forward": relative(fx, dense.forward(x)),
                 "fresh_vs_dense_adjoint": relative(ay, dense.adjoint(y)),
                 "cache_vs_fresh_forward": relative(cached.forward(x), fx),
                 "cache_vs_fresh_adjoint": relative(cached.adjoint(y), ay),
                 "legacy_vs_saved_forward": relative(legacy.forward(x), old_op.forward(x)),
                 "legacy_vs_saved_adjoint": relative(legacy.adjoint(y), old_op.adjoint(y)),
                 "normal_results": []}
        for name, weights, normal in zip(("identity", "positive_profile"), (None, w), normals):
            nx = normal.apply(x)
            n = {"weight": name, "normal_vs_composition": relative(nx, fresh.normal(x, weights)),
                 "normal_vs_dense": relative(nx, dense.normal(x, weights)),
                 "cached_composition_vs_fresh": relative(cached.normal(x, weights), fresh.normal(x, weights))}
            entry["normal_results"].append(n)
            check(f"normal identity {index} {name}", n["normal_vs_composition"] <= p["thresholds"]["normal_composition_error"])
            check(f"normal accuracy {index} {name}", n["normal_vs_dense"] <= p["thresholds"]["full_chain_relative_probe_error"])
            check(f"normal cache {index} {name}", n["cached_composition_vs_fresh"] <= p["thresholds"]["cached_vs_fresh_action_error"])
        for key in ("fresh_vs_dense_forward", "fresh_vs_dense_adjoint"):
            check(f"{key} {index}", entry[key] <= p["thresholds"]["full_chain_relative_probe_error"])
        for key in ("cache_vs_fresh_forward", "cache_vs_fresh_adjoint"):
            check(f"{key} {index}", entry[key] <= p["thresholds"]["cached_vs_fresh_action_error"])
        for key in ("legacy_vs_saved_forward", "legacy_vs_saved_adjoint"):
            check(f"{key} {index}", entry[key] <= p["thresholds"]["legacy_action_error"])
        probes.append(entry)
    for label, op in (("fresh", fresh), ("cached", cached), ("legacy", legacy)):
        check(label+" preparation dot", op.report["adjoint_dot_error"] <= p["thresholds"]["adjoint_dot_error"])
    result = {"schema": p["schema"], "created_utc": datetime.now(timezone.utc).isoformat(),
              "duration_seconds": perf_counter()-began, "protocol_sha256": sha(protocol_path),
              "environment": {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__, "platform": platform.platform(), "blas_threads": 1},
              "fresh_preparation": fresh.report, "cached_preparation": cached.report,
              "legacy_preparation": legacy.report, "legacy_rank_comparison": legacy_rows,
              "normal_preparation": [{"weight": name, "seconds": n.preparation_seconds,
                  "standalone_retained_bytes": n.retained_bytes, "normal_key": n.key}
                  for name, n in zip(("identity", "positive_profile"), normals)],
              "cache_file_bytes": cache.stat().st_size, "probes": probes, "checks": checks,
              "passed_checks": sum(c["passed"] for c in checks), "check_count": len(checks),
              "passed": all(c["passed"] for c in checks), "claim_scope": p["claim_scope"]}
    path = out/"summary.json"
    path.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    evidence.extend([path, out/"protocol.json", cache, Path(__file__).resolve(),
        ROOT/"src/waxs_cake/prepared_cpswf_aidt.py", ROOT/"src/waxs_cake/radial_aidt.py",
        ROOT/"src/waxs_cake/radial_cpswf.py", ROOT/"src/waxs_cake/finite_hankel.py",
        ROOT/"src/waxs_cake/aidt_acfo.py", ROOT/"tests/test_prepared_cpswf_aidt.py"])
    receipt = {str(path.relative_to(ROOT)).replace("\\", "/"): sha(path) for path in evidence}
    (out/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "checks": f"{result['passed_checks']}/{result['check_count']}",
                      "duration_seconds": result["duration_seconds"],
                      "fresh_seconds": fresh.report["total_preparation_seconds"],
                      "cached_seconds": cached.report["total_preparation_seconds"],
                      "normal_seconds": [n.preparation_seconds for n in normals], "probes": probes}, indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
