from dataclasses import replace
import gc
import json
import weakref

import numpy as np
import pytest
from scipy import linalg

from waxs_cake.prepared_cpswf_aidt import (
    AidtCpswfGeometry, PreparationLimits, PreparationError, PreparationBudgetError,
    prepare_cpswf_aidt,
)
from waxs_cake.radial_aidt import ModalRadialMap, PreparedRadialAidt
from waxs_cake.radial_cpswf import radial_block


def geometry():
    return AidtCpswfGeometry(r_edges_um=np.linspace(0, 2.0, 33),
        radial_frequency_um_inv=np.linspace(.02, .65, 28), n_phi=64,
        modes=(-3, -1, 0, 1, 3), depth_values_um=np.array([-.5, .5]), dz_um=1,
        source_na_xy=np.array([[.2, -.15], [-.1, .25]]), wavelength_um=.515,
        medium_index=1.47, objective_na=.65, angular_padding=0)


def values(rng, shape):
    return rng.normal(size=shape)+1j*rng.normal(size=shape)


@pytest.mark.parametrize("metric", ["source_strength", "density"])
def test_automatic_rank_spectral_error_and_full_api(metric):
    g = geometry()
    op = prepare_cpswf_aidt(g, rank_metric=metric)
    assert not op.report["cache_hit"]
    dense = {m: radial_block(g.q_perp, g.radius_um, m) for m in (0, 1, 3)}
    ref = PreparedRadialAidt(ModalRadialMap.build(g.modes, g.area_scale, dense, 2), op.operator.transfer)
    for record in op.report["blocks"]:
        m, k = record["mode_abs"], record["rank"]
        assert k < len(g.radius_um)
        block = op.operator.radial.blocks[m]
        a = dense[m]
        d = g.area_scale if metric == "density" else np.ones(a.shape[1])
        error = linalg.norm((block.forward(np.eye(a.shape[1]))-a)*d, 2)/linalg.norm(a*d, 2)
        assert error <= 1e-8+5e-13
        assert max(record["rank_search_bound"]) <= 1e-8
        assert max(record["previous_prefix_bound"]) > 1e-8
    rng = np.random.default_rng(22)
    x, y = values(rng, op.input_shape), values(rng, op.data_shape)
    for f, r in ((op.forward(x), ref.forward(x)), (op.adjoint(y), ref.adjoint(y))):
        assert np.linalg.norm(f-r)/np.linalg.norm(r) < 1e-7
    np.testing.assert_allclose(np.vdot(op.forward(x), y), np.vdot(x, op.adjoint(y)), atol=1e-11, rtol=1e-12)
    normal = op.prepare_normal()
    np.testing.assert_allclose(normal.apply(x), op.normal(x), atol=1e-11, rtol=1e-11)


def test_cache_roundtrip_skips_basis_preparation(tmp_path, monkeypatch):
    op = prepare_cpswf_aidt(geometry())
    cache = tmp_path/"radial.npz"
    op.save_radial_cache(cache)
    import waxs_cake.prepared_cpswf_aidt as module
    def forbidden(*args, **kwargs):
        raise AssertionError("cache load must not rebuild CPSWF or dense calibration")
    monkeypatch.setattr(module, "sampled_cpswf_basis", forbidden)
    monkeypatch.setattr(module, "radial_block", forbidden)
    copy = prepare_cpswf_aidt(geometry(), radial_cache=cache)
    assert copy.report["cache_hit"]
    rng = np.random.default_rng(32)
    x, y = values(rng, op.input_shape), values(rng, op.data_shape)
    np.testing.assert_array_equal(copy.forward(x), op.forward(x))
    np.testing.assert_array_equal(copy.adjoint(y), op.adjoint(y))
    with pytest.raises(FileExistsError):
        op.save_radial_cache(cache)


@pytest.mark.parametrize("change", ["q", "area", "tolerance", "metric", "row_weight"])
def test_cache_invalidation(tmp_path, change):
    g = geometry()
    op = prepare_cpswf_aidt(g)
    cache = tmp_path/"radial.npz"
    op.save_radial_cache(cache)
    kwargs = {"radial_cache": cache}
    if change == "q":
        g = replace(g, radial_frequency_um_inv=g.radial_frequency_um_inv*1.01)
    elif change == "area":
        g = replace(g, r_edges_um=g.r_edges_um*1.01)
    elif change == "tolerance":
        kwargs["radial_tolerance"] = 1e-7
    elif change == "metric":
        kwargs["rank_metric"] = "source_strength"
    else:
        kwargs["radial_weights"] = [np.linspace(.5, 1, 28)]
    with pytest.raises(PreparationError, match="mismatch"):
        prepare_cpswf_aidt(g, **kwargs)


def test_corrupted_array_rejected(tmp_path):
    op = prepare_cpswf_aidt(geometry())
    cache = tmp_path/"good.npz"
    op.save_radial_cache(cache)
    with np.load(cache, allow_pickle=False) as d:
        arrays = {k: d[k] for k in d.files}
    arrays["reduced_0"][0, 0] += .1
    damaged = tmp_path/"damaged.npz"
    np.savez(damaged, **arrays)
    with pytest.raises(PreparationError, match="integrity"):
        prepare_cpswf_aidt(geometry(), radial_cache=damaged)


def test_physics_changes_reuse_radial_basis_but_change_normal_key(tmp_path):
    g = geometry()
    op = prepare_cpswf_aidt(g)
    cache = tmp_path/"radial.npz"
    op.save_radial_cache(cache)
    shifted = prepare_cpswf_aidt(replace(g, depth_values_um=g.depth_values_um+.2), radial_cache=cache)
    assert shifted.report["radial_key"] == op.report["radial_key"]
    assert shifted.report["geometry_key"] != op.report["geometry_key"]
    n1, n2 = op.prepare_normal(), shifted.prepare_normal()
    assert n1.key != n2.key
    nw = op.prepare_normal(np.full(op.data_shape, .5))
    assert nw.key != n1.key
    np.testing.assert_allclose(nw.modal_normal.gram, .5*n1.modal_normal.gram, atol=1e-12)


def test_normal_standalone_ownership():
    op = prepare_cpswf_aidt(geometry())
    normal = op.prepare_normal()
    ref = weakref.ref(op.operator.transfer)
    x = values(np.random.default_rng(5), op.input_shape)
    expected = op.normal(x)
    del op
    gc.collect()
    assert ref() is None
    np.testing.assert_allclose(normal.apply(x), expected, atol=1e-11, rtol=1e-11)


@pytest.mark.parametrize("name", ["max_transfer_bytes", "max_radial_matrix_bytes", "max_basis_dimension"])
def test_preallocation_limits(name):
    with pytest.raises(PreparationBudgetError):
        prepare_cpswf_aidt(geometry(), limits=replace(PreparationLimits(), **{name: 1}))


def test_normal_budget_checked_without_changing_modes(monkeypatch):
    op = prepare_cpswf_aidt(geometry(), limits=replace(PreparationLimits(), max_normal_bytes=1))
    from waxs_cake.radial_aidt import PhysicalModalTransfer
    def forbidden(*args, **kwargs):
        raise AssertionError("should fail before Gram allocation")
    monkeypatch.setattr(PhysicalModalTransfer, "compile_normal", forbidden)
    with pytest.raises(PreparationBudgetError, match="Modes unchanged"):
        op.prepare_normal()
    assert op.geometry.modes == (-3, -1, 0, 1, 3)


@pytest.mark.parametrize("kwargs", [{"n_phi": 8}, {"modes": (0, 0)}, {"angular_padding": -1},
                                   {"data_bandlimit": 1}, {"source_na_xy": [[1, 0]]},
                                   {"dz_um": -1}, {"r_edges_um": [0, 1, .5]}])
def test_bad_geometry(kwargs):
    with pytest.raises(PreparationError):
        replace(geometry(), **kwargs)


def test_bad_tolerance_and_weights():
    with pytest.raises(PreparationError):
        prepare_cpswf_aidt(geometry(), radial_tolerance=1e-15)
    with pytest.raises(PreparationError):
        prepare_cpswf_aidt(geometry(), radial_weights=[np.zeros(28)])
    op = prepare_cpswf_aidt(geometry())
    with pytest.raises(PreparationError):
        op.prepare_normal(np.ones(op.data_shape)*1j)
    with pytest.raises(PreparationError):
        op.prepare_normal(-np.ones(op.data_shape))
