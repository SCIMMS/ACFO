"""Independent convention, differential-action and finite-section tests."""

import numpy as np
import pytest
from scipy import special

from waxs_cake.finite_hankel import (
    PreparedCPSWF, chebyshev_tridiagonal_apply, commuting_tridiagonal,
    gauss_unit_interval, hankel_basis_images, hankel_galerkin,
    radial_jacobi_basis, tridiagonal_apply, x_squared_tridiagonal,
)


def dense_tri(d, e):
    return np.diag(d) + np.diag(e, 1) + np.diag(e, -1)


@pytest.mark.parametrize("nu", [0.0, 0.5, 1.0, 4.0])
def test_basis_and_x_squared(nu):
    x, w = gauss_unit_interval(120)
    phi = radial_jacobi_basis(nu, 24, x)
    np.testing.assert_allclose((phi.T*w)@phi, np.eye(24), atol=2e-12)
    d, e = x_squared_tridiagonal(nu, 24)
    np.testing.assert_allclose((phi.T*(w*x*x))@phi, dense_tri(d, e), atol=2e-12)


@pytest.mark.parametrize("nu", [0.0, 0.5, 1.0, 4.0])
def test_differential_action_independent_of_matrix_recurrence(nu):
    x = np.linspace(0.03, 0.97, 73)
    t = 2*x*x - 1
    n, c = 7, 13.0
    a, s = nu+0.5, np.sqrt(2*(2*n+nu+1))
    p = special.eval_jacobi(n, 0, nu, t)
    pt = (n+nu+1)/2 * special.eval_jacobi(n-1, 1, nu+1, t)
    ptt = (n+nu+1)*(n+nu+2)/4 * special.eval_jacobi(n-2, 2, nu+2, t)
    f = s*x**a*p
    fp = s*(a*x**(a-1)*p + 4*x**(a+1)*pt)
    fpp = s*(a*(a-1)*x**(a-2)*p + 4*(2*a+1)*x**a*pt + 16*x**(a+2)*ptt)
    actual = -(1-x*x)*fpp + 2*x*fp + ((nu*nu-0.25)/(x*x)+c*c*x*x)*f
    d, e = commuting_tridiagonal(nu, c, n+2)
    expected = radial_jacobi_basis(nu, n+2, x) @ dense_tri(d, e)[:, n]
    np.testing.assert_allclose(actual, expected, rtol=1e-10, atol=1e-9)


@pytest.mark.parametrize("nu,c", [(0, 4), (1, 16), (4, 48)])
def test_analytic_integral_and_commuting_pair(nu, c):
    n, q = 64, 180
    h = hankel_galerkin(nu, c, n, q)
    direct = hankel_galerkin(nu, c, n, q, direct=True)
    assert np.linalg.norm(h-direct) / np.linalg.norm(direct) < 1e-10
    d, e = commuting_tridiagonal(nu, c, n)
    plan, audit = PreparedCPSWF.from_pair(d, e, h)
    u, lam = audit["vectors"], audit["hankel_eigenvalues"]
    assert np.linalg.norm(h-(u*lam)@u.T) / np.linalg.norm(h) < 1e-10
    assert np.max(lam**2) <= 1+1e-10
    rng = np.random.default_rng(19)
    a = rng.normal(size=(n, 3)) + 1j*rng.normal(size=(n, 3))
    assert np.linalg.norm(plan.apply(a)-h@a) / np.linalg.norm(h@a) < 3e-10
    assert np.linalg.norm(plan.apply(a, normal=True)-h@h@a) / np.linalg.norm(h@h@a) < 3e-10
    left, right = a[:, 0], a[:, 1]
    np.testing.assert_allclose(np.vdot(left, plan.apply(right)), np.vdot(plan.apply(left), right), atol=1e-12)


def test_half_order_sine_normalization_and_origin():
    x, w = gauss_unit_interval(160)
    c, nu = 6, 0.5
    phi = radial_jacobi_basis(nu, 20, x)
    # c sqrt(xy) J_(1/2)(cxy) = sqrt(2c/pi) sin(cxy).
    kernel = np.sqrt(2*c/np.pi)*np.sin(c*x[:, None]*x[None, :])
    actual = (phi.T*w) @ kernel @ (w[:, None]*phi)
    expected = hankel_galerkin(nu, c, 20, 160)
    np.testing.assert_allclose(actual, expected, atol=1e-12)
    assert np.all(hankel_basis_images(nu, c, 4, np.array([0.0])) == 0)


def test_polynomial_tridiagonal_action():
    d, e = commuting_tridiagonal(0, 8, 30)
    matrix = dense_tri(d, e)
    chi, u = np.linalg.eigh(matrix)
    bounds = (chi[0], chi[-1])
    t = (2*chi-sum(bounds))/(bounds[1]-bounds[0])
    rng = np.random.default_rng(15)
    coefficients = rng.normal(size=9)
    values = rng.normal(size=(30, 3)) + 1j*rng.normal(size=(30, 3))
    actual = chebyshev_tridiagonal_apply(d, e, coefficients, bounds, values)
    expected = u @ (np.polynomial.chebyshev.chebval(t, coefficients)[:, None]*(u.T@values))
    np.testing.assert_allclose(actual, expected, atol=1e-11)
    np.testing.assert_allclose(tridiagonal_apply(d, e, values), matrix@values, atol=1e-11)


@pytest.mark.parametrize("args", [(-1, 2, 5), (0, 0, 5), (0, np.inf, 5), (0, 1, 1.5), (0, 1, 0)])
def test_invalid_parameters(args):
    with pytest.raises(ValueError):
        commuting_tridiagonal(*args)


def test_low_order_section_and_rank_tolerance():
    d, e = commuting_tridiagonal(0, 2, 1)
    np.testing.assert_allclose(tridiagonal_apply(d, e, np.array([2j])), 2j*d)
    with pytest.raises(ValueError):
        PreparedCPSWF.from_pair(d, e, np.eye(1), relative_tolerance=0)


def test_insufficient_section_has_visible_boundary_defect():
    # An algebraic commutator is not automatically preserved by truncation.
    h = hankel_galerkin(0, 48, 8, 180)
    d, e = commuting_tridiagonal(0, 48, 8)
    plan, audit = PreparedCPSWF.from_pair(d, e, h)
    u, lam = audit["vectors"], audit["hankel_eigenvalues"]
    assert np.linalg.norm(h-(u*lam)@u.T)/np.linalg.norm(h) > 1e-3
