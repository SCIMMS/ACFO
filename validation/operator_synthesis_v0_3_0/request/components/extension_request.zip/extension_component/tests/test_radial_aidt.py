import numpy as np
import pytest

from waxs_cake.aidt_acfo import PreparedAidtAcfoOperator, direct_aidt_forward, direct_aidt_adjoint
from waxs_cake.radial_cpswf import radial_block, PreparedRadialProjection
from waxs_cake.radial_aidt import ModalRadialMap, PhysicalModalTransfer, PreparedRadialAidt


def tiny_operator(chunk=2, compress=False):
    modes = (-3, -1, 0, 1, 3)
    old = PreparedAidtAcfoOperator.build(
        r_edges_um=np.linspace(0, 1.3, 8), n_phi=64,
        depth_values_um=np.array([-0.7, 0.0, 0.7]),
        radial_frequency_um_inv=np.linspace(0.02, 0.71, 6),
        source_na_xy=np.array([[0.25, -0.15], [-0.12, 0.28]]),
        wavelength_um=0.515, medium_index=1.47, objective_na=0.65, dz_um=0.7)
    blocks = {m: radial_block(2*np.pi*old.radial_frequency_um_inv, old.r_centers_um, m)
              for m in (0, 1, 3)}
    if compress:
        # Deliberate rank restriction: exact algebra must work even when this
        # truncation is insufficient for an accurate physical approximation.
        p, _ = np.linalg.qr(np.random.default_rng(9).normal(size=(7, 3)))
        blocks = {m: PreparedRadialProjection.build(a, p, []) for m, a in blocks.items()}
    radial = ModalRadialMap.build(modes, old.n_phi*old.cell_area_um2[:, 0], blocks, old.n_z)
    transfer = PhysicalModalTransfer.build(modes, old.beta_centers, old.ptf, old.atf, q_chunk=chunk)
    return old, PreparedRadialAidt(radial, transfer)


def complex_random(rng, shape):
    return rng.normal(size=shape)+1j*rng.normal(size=shape)


@pytest.mark.parametrize("chunk", [1, 2, 20])
def test_density_area_signed_modes_and_direct_reference(chunk):
    old, op = tiny_operator(chunk)
    rng = np.random.default_rng(123)
    x = complex_random(rng, op.radial.input_shape)
    full = np.einsum("pm,mrzc->rpzc", op.transfer.angular, x)
    direct = direct_aidt_forward(old, full[..., 0], full[..., 1])
    np.testing.assert_allclose(op.forward(x), direct, atol=1e-12, rtol=1e-11)
    np.testing.assert_allclose(op.forward(x), old.forward(full[..., 0], full[..., 1]), atol=1e-12, rtol=1e-11)
    y = complex_random(rng, op.transfer.data_shape)
    full_adj = np.stack(direct_aidt_adjoint(old, y), axis=-1)
    expected = np.einsum("pm,rpzc->mrzc", op.transfer.angular.conj(), full_adj)
    np.testing.assert_allclose(op.adjoint(y), expected, atol=1e-12, rtol=1e-11)


@pytest.mark.parametrize("compress", [False, True])
@pytest.mark.parametrize("weighted", [False, True])
def test_dot_and_compiled_normal_keep_all_couplings(compress, weighted):
    _, op = tiny_operator(compress=compress)
    rng = np.random.default_rng(17)
    x = complex_random(rng, op.radial.input_shape)
    y = complex_random(rng, op.transfer.data_shape)
    np.testing.assert_allclose(np.vdot(op.forward(x), y), np.vdot(x, op.adjoint(y)), rtol=1e-12, atol=1e-12)
    w = rng.uniform(0.2, 1.8, size=y.shape) if weighted else None
    normal = op.transfer.compile_normal(w)
    composed = op.normal(x, w)
    np.testing.assert_allclose(op.compiled_normal(x, normal), composed, rtol=1e-11, atol=1e-12)
    np.testing.assert_allclose(normal.gram, normal.gram.conj().transpose(0, 2, 1), atol=1e-13)
    assert np.vdot(x, composed).real >= 0
    assert not normal.gram.flags.writeable


def test_diagonal_mode_normal_is_a_wrong_negative_control():
    _, op = tiny_operator()
    normal = op.transfer.compile_normal()
    q, m, z, c = op.radial.modal_shape
    g = normal.gram.reshape(q, m, z, c, m, z, c).copy()
    for a in range(m):
        for b in range(m):
            if a != b:
                g[:, a, :, :, b] = 0
    assert np.linalg.norm(g.reshape(normal.gram.shape)-normal.gram)/np.linalg.norm(normal.gram) > 0.1


def test_area_is_part_of_both_input_metric_and_adjoint():
    _, op = tiny_operator()
    wrong = ModalRadialMap.build(op.radial.modes, np.ones(7), op.radial.blocks, 3)
    rng = np.random.default_rng(18)
    x = complex_random(rng, op.radial.input_shape)
    assert np.linalg.norm(wrong.forward(x)-op.radial.forward(x))/np.linalg.norm(op.radial.forward(x)) > 0.1


def test_aliases_and_invalid_weights_rejected():
    old, op = tiny_operator()
    with pytest.raises(ValueError):
        PhysicalModalTransfer.build([0, 64], old.beta_centers, old.ptf, old.atf)
    with pytest.raises(ValueError):
        op.transfer.compile_normal(-np.ones(op.transfer.data_shape))
    with pytest.raises(ValueError):
        op.radial.forward(np.zeros((1, 1)))
    with pytest.raises(ValueError):
        ModalRadialMap.build([0], [0.0], {0: np.ones((2, 1))}, 1)
