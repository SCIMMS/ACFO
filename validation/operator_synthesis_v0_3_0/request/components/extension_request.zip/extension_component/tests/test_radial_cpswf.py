import numpy as np
import pytest
from scipy import linalg

from waxs_cake.finite_hankel import radial_jacobi_basis
from waxs_cake.radial_cpswf import (
    PreparedRadialProjection, prefix_error, radial_block, sampled_cpswf_basis,
    sampled_regular_jacobi, smallest_shared_prefix, weighted_families,
)


@pytest.mark.parametrize("order", [0, 4, 16, 64, 128])
def test_regular_sample_recurrence_and_measure_conversion(order):
    x = (np.arange(40)+0.5)/40
    expected = radial_jacobi_basis(order, 70, x)/np.sqrt(x[:, None])
    actual = sampled_regular_jacobi(order, 70, x)
    np.testing.assert_allclose(actual, expected, rtol=2e-10, atol=2e-11)


@pytest.mark.parametrize("order", [0, 4, 16])
def test_projection_shared_forward_adjoint_weighted_normal(order):
    r = (np.arange(48)+0.5)/48
    q = np.linspace(0.1, 24, 36)
    a = radial_block(q, r, order)
    w = [np.ones(q.size), np.linspace(0.3, 2, q.size)]
    blocks, _ = weighted_families(a, w)
    p, _ = sampled_cpswf_basis(r, 1, 24, order, 96)
    k, checked = smallest_shared_prefix(blocks, p, 1e-8)
    assert k is not None and k < 30
    assert max(checked[k]) <= 1e-8
    assert max(checked[k-1]) > 1e-8
    plan = PreparedRadialProjection.build(a, p[:, :k], w)
    ahat = plan.forward(np.eye(48))
    assert linalg.norm(ahat-a, 2)/linalg.norm(a, 2) < 1e-8
    rng = np.random.default_rng(5)
    x = rng.normal(size=48)+1j*rng.normal(size=48)
    y = rng.normal(size=36)+1j*rng.normal(size=36)
    np.testing.assert_allclose(np.vdot(plan.forward(x), y), np.vdot(x, plan.adjoint(y)), atol=1e-12)
    for j, weight in enumerate(w):
        expected = ahat.conj().T@(weight[:, None]*ahat)
        np.testing.assert_allclose(plan.normal(np.eye(48), j), expected, atol=1e-11)


def test_kernel_row_space_requires_dividing_by_sqrt_radius():
    # A strength coefficient is NOT an L2(dx) density sample.
    r = (np.arange(80)+0.5)/80
    q = np.linspace(0.1, 12, 45)
    a = radial_block(q, r, 0)
    p, _ = sampled_cpswf_basis(r, 1, 12, 0, 96)
    blocks, _ = weighted_families(a, [np.ones(45)])
    correct = prefix_error(blocks, p, 12)[0]
    wrong, _ = np.linalg.qr(np.sqrt(r[:, None])*p[:, :12])
    wrong_error = prefix_error(blocks, wrong, 12)[0]
    assert correct < 1e-9
    assert wrong_error > 1e-4


def test_unresolved_and_svd_minimality():
    a = np.diag([1.0, 0.1, 0.01, 0.001])
    k, _ = smallest_shared_prefix([a], np.eye(4), 0.02)
    assert k == 2
    missing, _ = smallest_shared_prefix([a], np.eye(4)[:, :1], 0.02)
    assert missing is None


def test_complex_geometry_rejected_and_cached_arrays_readonly():
    with pytest.raises(ValueError):
        PreparedRadialProjection.build(np.eye(3, dtype=complex), np.eye(3), [np.ones(3)])
    plan = PreparedRadialProjection.build(np.eye(3), np.eye(3), [np.ones(3)])
    assert not plan.basis.flags.writeable
    assert not plan.reduced.flags.writeable


@pytest.mark.parametrize("order,x", [(-1, [0.5]), (0, [0.0]), (0, [np.nan]), (1.5, [0.5])])
def test_bad_basis_arguments(order, x):
    with pytest.raises(ValueError):
        sampled_regular_jacobi(order, 8, np.array(x))
