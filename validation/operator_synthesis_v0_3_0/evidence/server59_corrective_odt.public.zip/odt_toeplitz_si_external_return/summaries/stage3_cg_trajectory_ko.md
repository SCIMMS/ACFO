# ODT Cartesian Toeplitz CG trajectory gate

- 판정: **PASS**
- geometry: production `banded_inner96_outer64`, q `3,469,312`개, `W=I`
- Cartesian grid: `[32, 32, 32]`, complex128
- solver: independent complex-CG `15` iterations
- common system: `A* A / M + 1.000e-03 I`

## 요약

- Toeplitz RHS vs direct RHS rel-L2: `8.740e-14`
- random-probe normal rel-L2: `2.753e-13`
- stacked solver-trajectory rel-L2: `1.550e-09`
- maximum per-iteration iterate rel-L2: `5.659e-09`
- maximum residual-norm / object-error scalar disagreement: `3.518e-11` / `1.394e-12`
- final solution rel-L2: `5.659e-09`
- maximum alpha / beta relative error: `1.516e-11` / `8.725e-11`
- final common-direct residual-vector rel-L2: `8.524e-06`
- final predicted-data rel-L2: `8.374e-09`

## Iteration trajectory

| iter | direct residual | Toeplitz residual | direct object err | Toeplitz object err | iterate rel-L2 | residual-vector rel-L2 | alpha rel | beta rel |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1.000e+00 | 1.000e+00 | 1.000e+00 | 1.000e+00 | 0.000e+00 | 0.000e+00 | n/a | n/a |
| 1 | 3.163e-01 | 3.163e-01 | 6.494e-01 | 6.494e-01 | 2.774e-15 | 2.475e-13 | 2.775e-15 | 4.910e-14 |
| 2 | 9.903e-02 | 9.903e-02 | 4.698e-01 | 4.698e-01 | 1.077e-13 | 7.769e-13 | 6.358e-15 | 3.866e-14 |
| 3 | 4.622e-02 | 4.622e-02 | 4.137e-01 | 4.137e-01 | 2.408e-13 | 1.654e-12 | 3.699e-14 | 1.361e-13 |
| 4 | 2.490e-02 | 2.490e-02 | 3.889e-01 | 3.889e-01 | 3.969e-13 | 3.051e-12 | 7.351e-14 | 4.243e-13 |
| 5 | 1.935e-02 | 1.935e-02 | 3.661e-01 | 3.661e-01 | 6.534e-13 | 3.951e-12 | 2.198e-13 | 4.658e-13 |
| 6 | 1.468e-02 | 1.468e-02 | 3.483e-01 | 3.483e-01 | 9.737e-13 | 5.570e-12 | 2.109e-13 | 2.730e-13 |
| 7 | 9.171e-03 | 9.171e-03 | 3.333e-01 | 3.333e-01 | 1.441e-12 | 1.514e-11 | 1.572e-14 | 9.199e-14 |
| 8 | 6.971e-03 | 6.971e-03 | 3.277e-01 | 3.277e-01 | 1.783e-12 | 5.425e-11 | 1.503e-13 | 6.172e-13 |
| 9 | 4.650e-03 | 4.650e-03 | 3.238e-01 | 3.238e-01 | 2.194e-12 | 2.085e-10 | 5.513e-13 | 1.652e-12 |
| 10 | 3.558e-03 | 3.558e-03 | 3.201e-01 | 3.201e-01 | 3.736e-12 | 1.319e-09 | 1.082e-12 | 2.356e-12 |
| 11 | 2.752e-03 | 2.752e-03 | 3.179e-01 | 3.179e-01 | 1.064e-11 | 6.586e-09 | 1.266e-12 | 2.737e-12 |
| 12 | 2.005e-03 | 2.005e-03 | 3.162e-01 | 3.162e-01 | 3.387e-11 | 2.995e-08 | 1.364e-12 | 3.879e-12 |
| 13 | 1.674e-03 | 1.674e-03 | 3.143e-01 | 3.143e-01 | 1.804e-10 | 1.922e-07 | 1.753e-12 | 3.729e-12 |
| 14 | 1.375e-03 | 1.375e-03 | 3.124e-01 | 3.124e-01 | 1.029e-09 | 1.337e-06 | 1.687e-12 | 4.435e-13 |
| 15 | 1.186e-03 | 1.186e-03 | 3.108e-01 | 3.108e-01 | 5.659e-09 | 8.524e-06 | 1.516e-11 | 8.725e-11 |

## 해석 경계

두 solver는 FINUFFT로 한 번 만든 완전히 동일한 RHS에서 시작한다. Toeplitz solver는 data를 다시 만들지 않으며 cached finite-grid symbol만 사용한다. Tikhonov 항은 두 backend에 동일하게 더했다.

이 실험은 uniform Cartesian state 내부의 solver trajectory 동등성을 검증한다. 현재 production unknown인 half-cell cylindrical coefficient와는 discretization, quadrature weight, boundary가 다르며 원래 cylindrical solver를 변경하지 않는다. Noiseless small-grid complex128 수치 gate이므로 physical missing-cone recovery나 full-scale reconstruction latency 주장이 아니다.
