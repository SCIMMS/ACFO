# ODT structured-weight Toeplitz rebuild validation

- overall: `PASS`
- q samples: `3469312`
- scope: positive axisymmetric detector x illumination separable weights

| N | profile | kernel rel-L2 | symbol rel-L2 | generic s | ACFO-derived s | speedup | verdict |
|---:|---|---:|---:|---:|---:|---:|---|
| 64 | unity | 1.552e-13 | 1.552e-13 | 1.345 | 0.104 | 12.930x | PASS |
| 64 | radial_apodized | 2.460e-13 | 2.460e-13 | 1.330 | 0.090 | 14.786x | PASS |
| 64 | source_and_band_reweighted | 1.801e-13 | 1.801e-13 | 1.333 | 0.091 | 14.710x | PASS |
| 128 | unity | 1.535e-13 | 1.535e-13 | 3.916 | 0.504 | 7.777x | PASS |
| 128 | radial_apodized | 2.429e-13 | 2.429e-13 | 3.787 | 0.505 | 7.503x | PASS |
| 128 | source_and_band_reweighted | 1.780e-13 | 1.780e-13 | 3.792 | 0.503 | 7.543x | PASS |

Arbitrary per-sample or nonseparable weights are outside this compiler gate and require the explicit operator or a generic Toeplitz rebuild.
