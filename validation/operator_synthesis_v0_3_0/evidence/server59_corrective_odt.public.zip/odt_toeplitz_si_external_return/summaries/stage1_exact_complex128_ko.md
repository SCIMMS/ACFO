# Production ODT Cartesian Toeplitz exact gate

- exact gate: **PASS**
- geometry: `banded_inner96_outer64`, actual ring+axis q count `3,469,312`
- reference: FINUFFT type-2 followed by its type-1 adjoint, with `W=I`
- candidate: signed-difference `(2N)^3` Toeplitz symbol and cropped FFT convolution

## Production q contract

| band | illumination | views | detector | q samples |
|---|---|---:|---:|---:|
| inner | ring | 120 | 96x128 | 1,474,560 |
| inner | axis | 1 | 96x128 | 12,288 |
| outer | ring | 120 | 64x256 | 1,966,080 |
| outer | axis | 1 | 64x256 | 16,384 |

## Complex128 exactness

- Cartesian / padded shape: `[32, 32, 32]` / `[64, 64, 64]`
- spacing: `[0.0625, 0.0625, 0.05]` micrometres
- Toeplitz vs FINUFFT normal rel-L2: `2.882e-13` / `2.507e-13`
- forward/adjoint dot error: `4.073e-15`
- FINUFFT / Toeplitz Hermitian error: `1.040e-14` / `6.815e-16`
- PSF Hermitian rel-L2: `0.000e+00`
- `<x,Nx>` vs `||Ax||^2` error: `1.081e-15`
- PSD energy imaginary fraction / nonnegative: `4.049e-16` / `True`

## CUDA status

GPU cases were explicitly skipped in this run. The script keeps physical-symbol 128^3/256^3 CUDA cases available for a separately scheduled run.

## Boundary

This is an exact normal for a new uniform Cartesian reconstruction state. The current production solver uses half-cell radial nodes, beta samples, cylindrical volume weights, and a different unknown vector. Therefore this result does not establish coefficient-by-coefficient equivalence to the cylindrical solver, and the original solver is not modified. A fair integration test must rebuild the Cartesian data right-hand side and compare reconstruction trajectories in the same Cartesian discretization.

The Toeplitz/FINUFFT comparison uses the complete production ring+axis q set and identical unit data weights. Symbol construction is setup work; hot apply excludes q generation, FINUFFT symbol build, data RHS construction, host transfer, regularization, and a converged reconstruction.
