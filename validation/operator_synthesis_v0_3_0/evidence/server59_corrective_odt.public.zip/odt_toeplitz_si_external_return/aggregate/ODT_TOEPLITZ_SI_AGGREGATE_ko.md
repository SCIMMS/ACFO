# ODT Toeplitz SI matched comparison

- scientific correctness: `PASS`
- Toeplitz hot advantage: `PASS`
- ACFO-derived setup advantage: `FAIL`
- disposition: `correct_but_performance_not_compelling`

| backend | setup s | hot normal ms | resident delta MiB |
|---|---:|---:|---:|
| cufinufft-normal | 0.219 | 42.307 | 2450.0 |
| cufinufft-toeplitz | 0.830 | 25.434 | 4106.0 |
| generic-toeplitz | 91.395 | 25.429 | 4148.0 |
| acfo-toeplitz | 1.043 | 25.437 | 4148.0 |

## Accuracy

- generic Toeplitz vs cuFINUFFT sampled rel-L2: `1.002e-05`
- ACFO Toeplitz vs cuFINUFFT sampled rel-L2: `3.757e-06`
- ACFO Toeplitz vs generic Toeplitz sampled rel-L2: `8.987e-06`

## Amortization

The weight-update table assumes the cuFINUFFT q plans are reusable while a cached Toeplitz symbol is rebuilt. The per-sample W multiplication cost is not included.

| total applies | rebuild interval | cuFINUFFT normal s | cuFINUFFT Toeplitz s | CPU-generic Toeplitz s | ACFO Toeplitz s | fastest |
|---:|---:|---:|---:|---:|---:|---|
| 1 | 1 | 0.261 | 0.855 | 91.421 | 1.069 | cufinufft-normal |
| 10 | 1 | 0.642 | 8.551 | 914.208 | 10.687 | cufinufft-normal |
| 10 | 10 | 0.642 | 1.084 | 91.650 | 1.298 | cufinufft-normal |
| 100 | 1 | 4.449 | 85.512 | 9142.076 | 106.870 | cufinufft-normal |
| 100 | 10 | 4.449 | 10.840 | 916.496 | 12.976 | cufinufft-normal |
| 100 | 100 | 4.449 | 3.373 | 93.938 | 3.587 | cufinufft-toeplitz |
| 1000 | 1 | 42.525 | 855.120 | 91420.763 | 1068.701 | cufinufft-normal |
| 1000 | 10 | 42.525 | 108.402 | 9164.962 | 129.764 | cufinufft-normal |
| 1000 | 100 | 42.525 | 33.731 | 939.382 | 35.870 | cufinufft-toeplitz |
| 1000 | 1000 | 42.525 | 26.264 | 116.824 | 26.480 | cufinufft-toeplitz |

Scope: fixed linear Cartesian normal, production q geometry, complex64 GPU timing, and W=I. The weighted CPU gate separately validates three positive axisymmetric separable W updates. Arbitrary nonseparable W and nonlinear operator changes remain on the explicit-operator track.
