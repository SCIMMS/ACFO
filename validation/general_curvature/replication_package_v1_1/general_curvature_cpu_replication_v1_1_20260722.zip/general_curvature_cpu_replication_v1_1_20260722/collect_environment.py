from __future__ import annotations

import argparse
from contextlib import redirect_stdout
from datetime import datetime, timezone
from io import StringIO
import json
import os
from pathlib import Path
import platform
import sys
import warnings

import numpy as np
import scipy


THREAD_VARIABLES = (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "BLIS_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    buffer = StringIO()
    with warnings.catch_warnings(), redirect_stdout(buffer):
        warnings.filterwarnings(
            "ignore",
            message=r"Install `pyyaml` for better output",
            category=UserWarning,
        )
        np.show_config()

    payload = {
        "schema": "acfo-general-curvature-cpu-environment-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": {
            "version": platform.python_version(),
            "implementation": platform.python_implementation(),
            "executable": sys.executable,
            "version_info": list(sys.version_info[:5]),
        },
        "packages": {
            "numpy": np.__version__,
            "scipy": scipy.__version__,
        },
        "host": {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "logical_cpu_count": os.cpu_count(),
        },
        "thread_environment": {
            name: os.environ.get(name) for name in THREAD_VARIABLES
        },
        "numpy_configuration": buffer.getvalue(),
        "gpu_used": False,
        "computation_contract": "NumPy complex128 CPU-only validation",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
