# ACFO Nature Computational Science 논문 작성 가이드

상태: 본문 구조와 claim contract 동결  
기준일: 2026-07-22  
대상 형식: Nature Computational Science Article  
주요 본문 순서: **Abstract → Introduction → Results and discussion → Conclusion**

이 문서는 기존의 `curved_ewald_operator_natcomputsci_article_draft.md`와 manuscript-preparation report에서 확정된 과학적 방향을 실제 집필 순서로 재구성한 가이드다. 이전 문서에서 Results와 Discussion을 분리한 구조는 사용하지 않는다. 각 결과 바로 뒤에서 의미, 비교, 한계와 다음 확장을 논의한다.

## 1. 동결된 manuscript contract

### 1.1 명칭과 중앙 claim

- 정식 명칭: **Axisymmetric Curved-Fourier Operator (ACFO)**
- 계산적 정체성: fixed axisymmetric Fourier-sampling geometry를 한 번 준비하고, object/source-dependent coefficients와 결합해 forward와 adjoint를 반복 적용하는 geometry-prepared harmonic operator
- 중앙 claim의 권장 문장:

> We introduce the Axisymmetric Curved-Fourier Operator (ACFO), a geometry-prepared harmonic forward–adjoint operator for finite axisymmetric curved Fourier-sampling surfaces. We validate ACFO in atomistic WAXS and demonstrate its extension to ODT/aIDT processing cores and nonspherical uniaxial nonlinear optics.

### 1.2 논문의 evidence spine

1. **WAXS — validation axis**  
   ACFO의 correctness, external performance replication, memory advantage와 detector-geometry 대응을 검증한다. WAXS 자체를 새로운 물리 extension으로 주장하지 않는다.
2. **ODT/aIDT — main extension 1**  
   동일한 prepared forward–adjoint contract가 fixed acquisition geometry의 inverse-processing core로 이어짐을 보인다.
3. **General curvature / uniaxial nonlinear optics — main extension 2**  
   sphere에 한정되지 않은 finite axisymmetric meridional curves와 nonspherical ordinary/extraordinary branches로 계산적·물리적 확장을 보인다.
4. **High-NA — prior-art bridge and Supplementary validation**  
   established harmonic reduction과의 관계 및 adaptive pupil-support의 제한된 stress test로 사용한다. Debye–Wolf의 보편적 대체나 main novelty로 주장하지 않는다.
5. **Differential equations — outlook only**  
   prepared Green-function 또는 spectral-PDE operator로의 가능성을 Conclusion 마지막에 짧게 언급할 수 있으나, 이미 일반 PDE solver를 달성했다고 쓰지 않는다.

### 1.3 수학적 범위

ACFO가 평가하는 sampling nodes는

\[
\mathbf q(u_j,\phi_\ell)
=\bigl(Q_\perp(u_j)\cos\phi_\ell,
       Q_\perp(u_j)\sin\phi_\ell,
       Q_z(u_j)\bigr)
\]

로 고정한다.

- 지원 범위: finite, axisymmetric, potentially nonspherical meridional Fourier-sampling curves
- 허용: nonmonotone curve, rotation-axis pole, repeated reciprocal-space node, caller-supplied quadrature/data weights
- 비주장 범위: arbitrary non-axisymmetric manifold, 임의 curve의 물리적 dispersion-surface 자동 인증, 모든 curved transform의 보편적 가속
- surface Jacobian은 point evaluation에 자동 적용되지 않으며, surface integral이 필요할 때 명시적으로 부여한다.

### 1.4 결과를 서술하는 공통 리듬

각 Results and discussion subsection은 아래 여섯 단계로 쓴다.

1. **Question** — 이 subsection이 답할 하나의 질문
2. **Construction** — 비교에 필요한 최소한의 계산 설정
3. **Evidence** — 핵심 수치와 Figure/Table 관측
4. **Interpretation** — 그 결과가 중앙 claim에 무엇을 추가하는지
5. **Boundary** — 결과가 말하지 않는 것
6. **Transition** — 다음 validation 또는 extension이 왜 필요한지

별도의 Discussion에서 해석을 반복하지 않는다. 수치 직후에 의미와 한계를 붙인다.

## 2. 전체 분량과 display-item 계획

| Section | 권장 분량 | 역할 |
|---|---:|---|
| Abstract | 130–150 words | 문제, 방법, 세 evidence axis와 범위를 한 단락에 압축 |
| Introduction | 600–700 words | 일반 문제, prior art, 미해결 gap, ACFO와 contribution 정의 |
| Results and discussion | 2,250–2,450 words | 방법 원리, WAXS validation, 두 main extensions, regime와 한계 |
| Conclusion | 180–230 words | 계산적 통찰과 세 evidence axis를 종합하고 bounded outlook 제시 |
| Main text total | 약 3,030–3,380 words | Abstract와 Online Methods 제외 기준으로 여유 확보 |

권장 display items는 **Figure 1–5와 Table 1**이다. High-NA 상세 결과, 확장 benchmark matrix와 구현 진단은 Supplementary Information으로 보낸다.

## 3. Abstract

### Section의 질문

왜 fixed, rotationally structured curved-Fourier geometry를 generic transform처럼 매번 다시 처리하지 않고 prepared forward–adjoint operator로 만들어야 하는가?

### 권장 문장 구성

1. **Problem:** scattering과 computational imaging에서 curved Fourier sampling이 반복되지만, generic direct/NUFFT 경로는 fixed geometry의 재사용 구조를 완전히 이용하지 않는다고 제시한다.
2. **Method:** ACFO가 object/source-dependent angular coefficients와 geometry-dependent meridional factors를 분리해 forward와 adjoint를 재사용한다고 정의한다.
3. **WAXS validation:** independently reproduced 1,001,000-atom workload에서 complex L2 `3.156×10⁻⁷`, paired-median speedup `27.447×`와 p05 `26.907×`를 보고한다.
4. **ODT/aIDT extension:** 256³ GPU-resident ODT processing core의 steady `17.947 Hz`, first-update `10.888 Hz`와 independent accuracy gate를 보고한다.
5. **General-curvature extension:** uniaxial nonlinear-optics oracle에서 same-bin ACFO/direct `≤4.591×10⁻¹⁵` 및 resolution-convergent analytic comparison을 제시한다.
6. **Meaning:** 이점은 curvature 자체가 아니라 axisymmetric structure, bounded harmonic support, target count와 geometry reuse의 결합에서 나온다고 결론낸다.

### Abstract에서 제외할 것

- High-NA 상세 수치
- matched-error `169.479×`처럼 긴 조건 설명이 필요한 비교
- histogram `1.810%`를 ACFO 연산오차처럼 보이게 하는 표현
- detector가 특정 EIGER geometry로 제한된다는 인상
- `first`, `universal`, `replaces NUFFT`, `end-to-end real time`

## 4. Introduction

최종 원고에서 heading을 노출할지는 저널 house style에 맞추되, 내부 집필에서는 아래 다섯 문단으로 관리한다.

### Paragraph 1 — 공통 계산 문제

- WAXS, diffraction tomography와 anisotropic wave optics가 서로 다른 물리 문제처럼 보이지만, 모두 Cartesian grid가 아닌 curved Fourier coordinates에서 반복 평가한다는 공통점을 제시한다.
- 실험 또는 inverse problem 동안 detector, illumination, dispersion geometry는 고정되고 source/object/residual만 바뀌는 경우가 많다는 점을 강조한다.
- 첫 문단에서는 성능 수치를 넣지 않는다.

### Paragraph 2 — 기존 방법과 남은 gap

- direct summation은 투명한 reference지만 source–target product scaling이 크다.
- FFT는 Cartesian structure에 강하지만 curved target에는 interpolation 또는 reformulation이 필요하다.
- NUFFT는 arbitrary nonuniform targets에 강한 generic baseline이지만, fixed axisymmetric geometry의 angular redundancy와 repeated reuse를 반드시 전용 factorization으로 바꾸지는 않는다.
- prepared/cached operator 자체는 선행 개념이므로 신규성으로 주장하지 않는다.

### Paragraph 3 — harmonic prior art와 High-NA의 위치

- Fourier–Bessel/circular-harmonic machinery와 Richards–Wolf/Debye–Wolf 계열의 rotational reduction을 간결히 소개한다.
- Boichenko의 problem-specific high-aperture reduction은 ACFO와 연결되는 선행 구조로 인용한다.
- 논문의 gap은 harmonic identity의 발견이 아니라, **finite axisymmetric curved Fourier surfaces에서 geometry preparation, reusable forward–adjoint, application-independent contract와 검증된 regime을 하나의 operator framework로 묶는 것**이라고 쓴다.

### Paragraph 4 — ACFO 정의

- ACFO의 full name을 처음 정의한다.
- fixed geometry `G`, prepared object `P_G`, forward `A_G`, adjoint `A_G*`, setup time, apply time와 cache memory를 소개한다.
- 유리한 regime은 curvature magnitude 하나가 아니라 structure, harmonic bandwidth, target count와 reuse count로 결정된다고 미리 명시한다.

### Paragraph 5 — contribution과 논문 흐름

문장형으로 다음 세 기여를 제시한다.

1. atomistic WAXS에서 direct/generic-transform correctness와 independently reproduced time/memory validation
2. fixed detector/illumination geometry를 재사용하는 ODT/aIDT forward–adjoint processing-core extension
3. multiple nonspherical curve families와 homogeneous uniaxial nonlinear optics에 대한 general-curvature extension

마지막 문장에서 High-NA는 prior-art/SI bridge이며 PDE는 outlook임을 짧게 경계 지어도 좋다.

## 5. Results and discussion

### 5.1 ACFO separates source coefficients from reusable curved geometry

#### 답할 질문

서로 다른 응용에서 반복되는 curved-Fourier evaluation을 어떤 하나의 forward–adjoint contract로 표현할 수 있는가?

#### 반드시 들어갈 내용

- `q(u, phi)` axisymmetric manifold contract
- angular expansion 뒤 source/object-dependent coefficients와 geometry-dependent factors가 분리되는 한 개의 대표 식
- prepared geometry `P_G`와 repeated `A_G`, `A_G*` application
- Euclidean 또는 weighted data-space inner product와 forward–adjoint dot-product consistency
- `T_setup`, `T_apply`, `M_cache`, reuse count와 break-even 정의

Break-even은 다음 형태로 정의한다.

\[
N_{\mathrm{break}}
=\left\lceil
\frac{T_{\mathrm{setup,ACFO}}-T_{\mathrm{setup,base}}}
{T_{\mathrm{apply,base}}-T_{\mathrm{apply,ACFO}}}
\right\rceil .
\]

#### Figure 1

- 왼쪽: source/object와 fixed meridional geometry
- 가운데: one-time geometry preparation과 harmonic factors
- 오른쪽: repeated forward/adjoint calls
- 아래: WAXS validation → ODT/aIDT extension 1 → general-curvature extension 2

Figure 1은 세 application을 병렬적인 동급 novelty로 보이게 하지 말고, **validation에서 두 extension으로 진행되는 증거 구조**를 보여야 한다.

#### 바로 뒤에 붙일 discussion

- ACFO는 새로운 Bessel identity가 아니라 known harmonic machinery를 reusable operator contract로 조직한 것이다.
- generic NUFFT와 경쟁하는 지점은 arbitrary-target generality가 아니라 repeated structured geometry다.
- supplied curve의 Fourier samples를 정확히 평가한다는 것과 그 curve가 실제 물리 dispersion relation이라는 것은 별개의 문제다.

#### 피할 표현

- “curvature causes the speedup”
- “ACFO is a universal replacement for NUFFT”
- “arbitrary curved manifolds”

### 5.2 Atomistic WAXS validates correctness, reuse performance and detector flexibility

#### 답할 질문

ACFO가 large atomistic curved-detector workload에서 independent reference와 일치하면서 실제 prepared-reuse 이점을 보이는가?

#### 권장 전개 순서

1. small/direct 및 exact-beta controls로 operator correctness를 먼저 확립한다.
2. external RTX 3090 package의 1M workload로 반복 성능을 제시한다.
3. detector-aware EIGER active-region workload로 time과 memory를 제시한다.
4. custom close/wide-q와 long-distance/narrow-q geometry로 detector/chamber coordinate freedom의 correctness를 보인다.
5. local high-q sweep은 regime trend로만 해석하고 causal 또는 universal headline으로 사용하지 않는다.

#### Main-text headline data

| Evidence | 핵심 수치 | 안전한 해석 |
|---|---:|---|
| Prepared 1M WAXS | `1,001,000` atoms, `393,216` targets | frozen structured repeated-crystal workload |
| Accuracy | ACFO–FINUFFT complex L2 `3.156×10⁻⁷`; prepared–legacy `4.811×10⁻¹⁴` | generic reference와 legacy factorization에 대한 두 층의 검증 |
| AB/BA performance | ACFO `0.6410 s`; FINUFFT `17.5773 s`; median `27.447×`; p05 `26.907×` | independent prepared-reuse result |
| Detector-aware workload | `1,015,326` active targets | synthetic EIGER2 X 4M active geometry |
| Detector time/memory | `2.468×`; peak RSS `114.09` vs `621.83 MiB`, `5.450×` reduction | tested active-region contract의 result |
| Custom wide-q geometry | `0.05–8.00 Å⁻¹`, complex L2 `3.548×10⁻⁷` | geometry correctness only |
| Custom narrow-q geometry | `0.05–1.20 Å⁻¹`, complex L2 `2.675×10⁻⁷` | geometry correctness only |

#### Figures 2–3

- **Figure 2:** WAXS mapping, direct/exact-beta correctness, amplitude/intensity error structure
- **Figure 3:** external 30-pair distribution, detector-aware time/memory, 선택적으로 custom geometry 또는 high-q regime inset

#### 바로 뒤에 붙일 discussion

- WAXS는 main extension이 아니라 가장 큰 independent validation axis다.
- EIGER active region은 하나의 tested geometry일 뿐이며, ACFO contract는 caller가 제공한 다른 valid detector/chamber coordinates도 수용한다.
- 실제 XFEL에서 accessible q range는 wavelength, chamber, distance, sensor layout와 mask 선택의 문제다. ACFO가 EIGER q range에 묶인다고 쓰지 않는다.
- custom-geometry probe의 timing은 hot-reuse 비교가 아니므로 성능 claim에 사용하지 않는다.
- high-q pilot은 q, `Nphi`, harmonic support와 target count가 함께 변하는 workload trend다. “high q alone”을 원인으로 쓰지 않는다.

#### Boundary sentence

> These results validate ACFO for the tested structured and repeated atomistic cake-map contracts; they do not imply an advantage for every dense-disorder or one-shot WAXS calculation.

### 5.3 Prepared forward–adjoint reuse extends to ODT/aIDT processing cores

#### 답할 질문

WAXS에서 검증한 prepared geometry separation이 inverse imaging의 repeated forward–adjoint update에서도 유효한가?

#### 반드시 들어갈 내용

- fixed illumination/detector sampling과 changing object/residual의 분리
- detector-cap과 illumination-side harmonic indices 또는 h/l factorization
- forward뿐 아니라 adjoint와 remap을 포함하는 processing-core contract
- correctness audit와 full-scale timing을 분리해 보고
- GPU-resident processing core와 end-to-end microscope를 명시적으로 구분

#### Main-text headline data

| Evidence | 핵심 수치 | 역할 |
|---|---:|---|
| H36/direct audit | worst operator L2 `9.033×10⁻⁷` | extension correctness |
| Remap reconstruction | difference `0.0959%` / `0.0915%` | inverse-output consistency |
| 256³ ODT | steady `55.719 ms = 17.947 Hz`; first `91.845 ms = 10.888 Hz` | full-scale processing-core rate |
| GPU memory | peak `1,996.36 MiB` | hardware feasibility |
| Same dtype | ACFO/cuFINUFFT pair `0.05102/1.79627 s`, `35.205×` | primary fair performance comparison |
| Matched error | `169.479×` | mixed-precision, separate-process secondary comparison |
| Public aIDT core | `97.002 ms = 10.309 Hz` | cross-architecture application evidence |

#### Figure 4

- panel a: fixed detector/illumination geometry와 changing object/residual
- panel b: forward–adjoint/remap correctness
- panel c: first versus steady 256³ latency
- panel d: same-dtype baseline과 선택적인 matched-error context
- panel e 또는 SI: temporal warm-start latency/error trade-off와 public aIDT core

#### 바로 뒤에 붙일 discussion

- extension의 핵심은 특정 ODT reconstruction architecture를 최종 선택하는 것이 아니라, fixed geometry의 prepared processing primitive가 forward–adjoint 반복에 들어갈 수 있다는 점이다.
- synchronized transfer, multi-GPU alternation, acquisition scheduling의 최적 구조는 해당 시스템 설계의 문제이며 ACFO core claim에서 제외한다.
- `17.947 Hz`는 acquisition, host transfer와 hologram demodulation을 제외한 GPU-resident core rate다.
- `169.479×`는 같은 setting 비교가 아니므로 main headline으로 쓰지 않는다. main comparison은 same-dtype `35.205×`로 둔다.

#### Boundary sentence

> The reported rates characterize the GPU-resident reconstruction processing core rather than an end-to-end microscope, whose acquisition and transfer architecture remains system dependent.

### 5.4 General curvature extends ACFO to nonspherical uniaxial nonlinear optics

#### 답할 질문

ACFO가 Ewald sphere와 ODT cap을 넘어, nonspherical axisymmetric curves와 physically instantiated uniaxial dispersion branches에서도 정확한가?

#### 두 단계로 전개

**A. Computational general-curvature gate**

- shifted, rotated anisotropic Gaussian mixture의 exact continuous Fourier transform 사용
- sphere, ellipsoid, paraboloid와 spline 네 curve family 비교
- ACFO operator error, histogram placement error와 voxel quadrature error를 분해
- finest level에서 operator L2가 약 `4.85–4.98×10⁻¹⁵`, total error가 `0.91–1.03%`이며 histogram placement가 지배적임을 제시
- curve family 자체는 supplied sampling geometry이며, 물리 dispersion surface 인증은 아님을 명시

**B. Uniaxial nonlinear-optics instantiation**

- prescribed anisotropic-Gaussian pump
- LiNbO3 3m `χ(2)` contraction
- exact continuous nonlinear-polarization Fourier transform
- homogeneous lossless simple-pole ordinary/extraordinary dyadic-Maxwell residue
- relative complex vector bulk field만 보고하고 absolute SH conversion efficiency는 제외

#### Accuracy hierarchy

| 단계 | 수치 | 원고에서의 의미 |
|---|---:|---|
| `χ(2)` pointwise factorization | L2 `1.319×10⁻¹⁶` | nonlinear source algebra gate |
| Same-bin scalar ACFO/direct | `≤4.585×10⁻¹⁵` | operator arithmetic correctness |
| Same-bin Green ACFO/direct | `≤4.591×10⁻¹⁵` | dyadic branch application correctness |
| Selected-mode voxel-direct/analytic Green | `7.141×10⁻¹³` | high-precision analytic oracle link |
| Finest histogram/analytic Green | `1.810%` | resolution-dependent binning/discretization diagnostic |
| Wrong-`d33` gain-aligned residual | `29.744%` | physical tensor sensitivity control |

`1.810%`는 **ACFO 연산오차가 아니다**. 동일 bin에서 ACFO와 direct가 machine precision으로 일치하고, analytic comparison은 resolution 증가에 따라 감소하므로 histogram/voxel representation의 discretization convergence로 설명한다.

#### Figure 5

- panel a: 네 general-curvature family와 analytic Gaussian result
- panel b: operator/histogram/voxel error decomposition 및 resolution convergence
- panel c: uniaxial ordinary/extraordinary dispersion branches
- panel d: analytic nonlinear-polarization → ACFO/direct → dyadic field chain
- panel e: correct tensor versus wrong-`d33` control

#### 바로 뒤에 붙일 discussion

- 이 subsection이 **두 번째 main extension**이며, 논문의 가장 넓은 geometric evidence다.
- 일반성은 sphere가 아닌 meridional curves를 동일 contract로 처리한다는 데 있다. arbitrary non-axisymmetric surface나 complete nonlinear-crystal device solver를 뜻하지 않는다.
- independent analytic oracle가 존재하므로 histogram-based solver의 해상도 오차를 ACFO 오류로 돌리지 않는다.
- FDTD가 포함되더라도 full complex-amplitude truth가 아니라 제한된 SI diagnostic으로만 둔다.

#### Boundary sentence

> The demonstrated nonlinear-optical extension concerns prescribed undepleted bulk polarization in homogeneous, lossless uniaxial media; interfaces, depletion, loss, periodic poling, position-dependent pump polarization and absolute conversion efficiency remain outside the present scope.

### 5.5 Regime boundaries and broader implications

#### 답할 질문

언제 ACFO가 자연스러운 선택이고, 언제 direct, FFT 또는 generic NUFFT가 더 적절한가?

#### Table 1의 권장 열

| Method | Target geometry | Setup | Reuse | Forward/adjoint | Natural regime | 주요 약점 |
|---|---|---|---|---|---|---|
| Direct sum | arbitrary | minimal | poor | transparent | small reference problems | source×target cost |
| Cartesian FFT/interpolation | Cartesian/near-grid | moderate | good | established | dense Cartesian volumes | curved-target interpolation |
| NUFFT | arbitrary nonuniform | package dependent | possible | established | irregular/general targets | structured angular redundancy를 전용으로 압축하지 않음 |
| ACFO | finite axisymmetric curves | geometry preparation | central | prepared pair | fixed, repeated, harmonic-bounded curved geometry | one-shot small or non-axisymmetric arbitrary targets |

#### 통합 discussion에 포함할 내용

- 속도 우위의 원인은 curvature가 아니라 axisymmetric ring structure, bounded harmonic support, target count와 reuse의 결합이다.
- external evidence와 local evidence를 구분한다.
  - WAXS/ODT headline: independent RTX 3090 package
  - WAXS high-q/custom geometry: local supporting evidence
  - general curvature: local exact analytic oracle, 별도 archive로 provenance 유지
- High-NA는 established prior-art correspondence와 adaptive cutoff safety를 보여주는 SI 항목이다. 특정 scalar structured-grid 영역에서 대체 가능하거나 경쟁적일 수 있으나 Debye–Wolf 전반의 대체를 주장하지 않는다.
- main limitations: axisymmetry, finite supplied curves, discretization, fixed-geometry reuse requirement, hardware-specific timings와 scoped bulk uniaxial physics
- 마지막 한두 문장만 prepared Green-function 또는 spectral-PDE operator 가능성에 할당한다. 구현된 general PDE solver처럼 쓰지 않는다.

## 6. Conclusion

Conclusion은 새로운 결과를 추가하지 않고 세 evidence axis를 하나의 계산적 통찰로 합친다. 3개 문단 또는 4–5개 문장이면 충분하다.

### 권장 구성

1. **Core contribution:** ACFO가 finite axisymmetric curved Fourier geometry를 reusable forward–adjoint operator로 준비한다.
2. **Evidence synthesis:** WAXS가 independent validation을, ODT/aIDT가 inverse-processing extension을, nonspherical uniaxial optics가 general-curvature extension을 제공한다.
3. **Regime insight:** 이점은 curvature 자체가 아니라 reusable structure와 harmonic bandwidth에서 나온다.
4. **Bounded outlook:** non-axisymmetric geometry 또는 prepared Green/spectral-PDE problems로의 확장은 별도 수학·물리 검증을 요구한다.

### 권장 conclusion skeleton

> ACFO recasts repeated Fourier evaluation on finite axisymmetric curved sampling surfaces as a geometry-prepared forward–adjoint operation. Its independently reproduced WAXS validation, inverse-processing extension in ODT/aIDT and analytic general-curvature validation in uniaxial nonlinear optics identify a common computational regime governed by rotational structure, harmonic bandwidth and geometry reuse rather than curvature alone. These results establish a reusable operator layer for the tested scattering and imaging workloads while retaining direct and generic transforms as the natural choices outside that regime. Extending the same principle to non-axisymmetric surfaces or broader Green-function and spectral-PDE operators will require new contracts and independent validation.

Conclusion에서는 새로운 benchmark 수치, High-NA 세부 결과 또는 `first` claim을 추가하지 않는다.

## 7. Figure와 Table의 최종 역할

| Item | 한 문장 메시지 | 본문 위치 |
|---|---|---|
| Figure 1 | Fixed geometry를 준비하면 changing source/object에 forward와 adjoint를 반복 적용할 수 있다 | 5.1 |
| Figure 2 | WAXS direct/legacy/reference agreement가 ACFO correctness를 검증한다 | 5.2 전반 |
| Figure 3 | External WAXS reuse와 detector-aware workload가 time/memory regime을 검증한다 | 5.2 후반 |
| Figure 4 | 동일 operator contract가 ODT/aIDT inverse processing core로 확장된다 | 5.3 |
| Figure 5 | Nonspherical curves와 uniaxial branches가 general-curvature extension을 검증한다 | 5.4 |
| Table 1 | ACFO, direct, FFT와 NUFFT의 자연스러운 regime이 다르다 | 5.5 |

각 caption은 계산 조건, 반복 횟수, hardware/evidence tier, error definition과 포함·제외 시간을 자체적으로 이해할 수 있게 작성한다.

## 8. Online Methods와 Supplementary Information

사용자가 선택한 네 개의 main narrative section 뒤에는 journal-required back matter를 둔다. 이는 main narrative의 별도 Discussion을 의미하지 않는다.

### Online Methods 권장 subsection

1. Axisymmetric sampling-manifold and weighting contract
2. ACFO geometry preparation and harmonic truncation
3. Forward–adjoint convention and dot-product tests
4. WAXS source representation, detector mapping and exact/direct references
5. AB/BA timing, setup/apply and memory protocol
6. ODT/aIDT forward, adjoint, remap and GPU-resident timing boundary
7. General-curvature analytic Gaussian-mixture validation
8. Uniaxial `χ(2)` nonlinear-polarization and dyadic-Maxwell oracle
9. Error metrics, resolution studies and statistical summaries
10. Software, hardware, archive and reproducibility

### Supplementary Information 권장 구성

- full mathematical derivation and notation table
- harmonic cutoff and adjoint validation matrix
- WAXS direct, high-q and custom-geometry extended tables
- ODT same-dtype/matched-error details, temporal warm start와 public aIDT probe
- general-curvature four-family resolution matrix와 nonlinear-oracle diagnostics
- High-NA prior-art correspondence, adaptive support failure/recovery와 제한된 competitive regimes
- FDTD는 존재할 경우 diagnostic boundary와 함께 배치
- full literature claim matrix와 exact-claim search log
- reproducibility commands, hashes and environment manifests

### Back matter

- Data availability
- Code availability
- Acknowledgements
- Author contributions
- Competing interests
- References

General-curvature archive는 v14 external package와 합치지 않고 provenance를 별도로 유지한다. 최종 release에서는 WAXS/ODT package와 general-curvature archive를 하나의 DOI collection 아래 연결한다.

## 9. Claim language guide

| 피할 표현 | 사용할 표현 |
|---|---|
| ACFO replaces NUFFT generally | ACFO is advantageous in the tested structured, fixed-geometry and repeated-use regimes |
| Curvature causes the speedup | Axisymmetric structure, harmonic support, target count and reuse jointly define the favorable regime |
| WAXS is 59× faster | The frozen external 1M workload achieved a `27.447×` paired-median speedup, with p05 `26.907×` |
| The EIGER geometry defines the accessible q range | EIGER is one validated active-region geometry; caller-supplied chamber/detector geometry can select different q ranges |
| ODT runs end-to-end at 17.947 Hz | The GPU-resident ODT processing core reached `17.947 Hz` steady and `10.888 Hz` on the first update |
| ACFO is 169.479× faster at the same setting | A mixed-precision, separate-process matched-error comparison measured `169.479×`; the same-dtype comparison measured `35.205×` |
| General curvature error is 1.810% | Same-bin ACFO/direct error is `≤4.591×10⁻¹⁵`; `1.810%` is the finest histogram-to-analytic discretization diagnostic |
| ACFO solves arbitrary nonlinear crystals | ACFO was validated for prescribed undepleted bulk polarization in homogeneous lossless uniaxial media |
| ACFO replaces Debye–Wolf | High-NA provides prior-art correspondence and a scoped adaptive-support validation |
| ACFO generalizes to differential equations | The results suggest a path toward prepared Green-function or spectral-PDE operators |

## 10. 실제 집필 순서

최종 독서 순서와 실제 집필 순서는 다르게 가져간다.

1. Section 5.1 ACFO operator contract
2. Section 5.3 ODT/aIDT extension 1
3. Section 5.4 general-curvature extension 2
4. Section 5.2 WAXS validation
5. Section 5.5 regime boundaries
6. Conclusion
7. Introduction
8. Abstract
9. Online Methods, captions와 Supplementary Information

이 순서를 따르면 중앙 claim과 두 extension을 먼저 안정시킨 뒤, WAXS를 그 claim의 validation으로 정확히 배치할 수 있다. Abstract는 Figure 1–5의 source-data와 본문 headline 수치가 모두 동결된 뒤 마지막에 쓴다.

## 11. Section 완료 체크리스트

각 subsection을 완료할 때 아래를 확인한다.

- 첫 문장이 답할 질문을 명확히 하는가?
- 사용한 수치가 frozen JSON/receipt 또는 analytic oracle로 추적 가능한가?
- result 직후에 해석과 claim boundary가 붙어 있는가?
- local evidence와 independent external evidence가 구분되어 있는가?
- setup-inclusive, prepared/hot apply와 end-to-end timing을 섞지 않았는가?
- same-bin operator error와 histogram/voxel discretization error를 분리했는가?
- WAXS를 validation, ODT/aIDT를 extension 1, general curvature를 extension 2로 유지했는가?
- High-NA와 PDE가 main novelty로 올라오지 않았는가?
- `first`, `universal`, `arbitrary`, `replacement`, `end-to-end` 같은 단어가 evidence 범위를 넘지 않는가?
- 다음 subsection으로 이동하는 이유가 마지막 문장에 드러나는가?
