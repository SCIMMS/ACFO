# Axisymmetric sampling-manifold contract (stage 1)

## Scope

`AxisymmetricManifold` is the geometry contract for evaluating a three-dimensional Fourier transform at

\[
\mathbf q(u_j,\phi_\ell)
=\bigl(Q_\perp(u_j)\cos\phi_\ell,
       Q_\perp(u_j)\sin\phi_\ell,
       Q_z(u_j)\bigr).
\]

The contract states which nodes are evaluated. It does not certify that an arbitrary curve is an Ewald surface or the dispersion surface of a physical wave equation. `interpretation="dispersion-derived"` records caller-supplied provenance only. Physical validation remains a later stage.

## Frozen meanings

- `u` is a finite, one-dimensional, strictly increasing sample label. It need not be uniform.
- `Q_perp` is finite and non-negative. Zeros at the rotation axis are valid.
- `Q_z` is finite and may be nonmonotone.
- Repeated `(Q_perp, Q_z)` nodes are permitted because repeated point measurements are mathematically valid. Deduplication is not implicit.
- `q_norm = sqrt(Q_perp**2 + Q_z**2)` is the magnitude passed to isotropic atomic form factors. `u` is never used as a form-factor argument.
- The circular backend uses a uniform periodic azimuth grid. `uniform_phi(n_phi)` reproduces the existing beta-bin-center convention.
- All geometry arrays are copied, converted to `float64`, and made read-only when the contract is created.

## Point evaluation and weights

The forward operator returns point samples. It does not multiply by a surface Jacobian.

`data_weights=None` means the Euclidean discrete data-space inner product. Explicit non-negative `data_weights[j]` define its radial factor:

\[
\langle a,b\rangle_D
=\sum_{j,\ell} w_j\,\overline{a_{j\ell}}b_{j\ell},
\]

up to an optional common azimuthal factor. A later adjoint must declare whether it is Euclidean or weighted and use the same convention in its dot-product test.

For an actual surface integral, the radial surface-measure weights can be constructed explicitly as

\[
w_j^{(S)}=w_j^{(u)}Q_\perp(u_j)
\sqrt{Q_\perp'(u_j)^2+Q_z'(u_j)^2}.
\]

`parameter_trapezoid_weights` creates only `w^(u)`. `surface_radial_weights` adds the caller-supplied derivatives and surface Jacobian. Neither is applied automatically.

## Current backend bridge

`prepare_axisymmetric_plan` adapts the contract to `PreparedCakePlan` without changing the established WAXS path. The current legacy constructor requires `q` and `wavelength`; the adapter supplies `q_norm` as `q`, explicit `Q_perp/Q_z`, and a dummy positive wavelength that is ignored when explicit geometry is present.

The adapter owns all geometry arguments. Callers may still provide form factors, precision, cache, block-size, and backend options.

## Stage-1 acceptance criteria

1. Invalid parameter ordering, shapes, non-finite values, and negative `Q_perp` are rejected.
2. Nonmonotone curves, poles, and repeated reciprocal-space nodes remain representable.
3. Callback, tabulated constructor, and Ewald-sphere factory share one contract.
4. `q_norm` remains the form-factor coordinate.
5. The adapter agrees bit-for-bit with direct explicit-geometry construction.
6. The Ewald-sphere factory agrees bit-for-bit with the existing WAXS constructor.

Correctness against independent exponent sums, analytic Gaussian phantoms, harmonic cutoff studies, and forward-adjoint implementation are deliberately reserved for subsequent stages.
