# General-curvature analytic nonlinear-polarization oracle

이 검증은 prescribed anisotropic-Gaussian pump, LiNbO3 3m contraction, exact continuous Fourier transform, dyadic anisotropic Maxwell residue를 하나의 pure-NumPy reference chain으로 연결한다. FDTD는 사용하지 않는다.

## Fourier and normalization contract

- ACFO convention: `integral P2(r) exp(+i q.r) dr`
- physical source convention: `integral P2(r) exp(-i k_out.r) dr`
- mapping: `q = -k_out`; analytic Gaussian argument: `2 k_pump - k_out`
- reported field: relative complex vector amplitude only; absolute SH efficiency is outside scope

## Exact algebra and operator gate

- chi2 pointwise factorization L2: `1.319e-16`
- reduced grid: `24^3`, cylindrical `36 x 24 x 72`

| branch | scalar ACFO/direct | Green ACFO/direct |
|---|---:|---:|
| ordinary | 3.959e-15 | 4.142e-15 |
| extraordinary | 4.585e-15 | 4.591e-15 |

## Continuous analytic-reference convergence

| Cartesian | cylindrical | full-ring targets | scalar total L2 | Green total L2 | elapsed s |
|---:|---:|---:|---:|---:|---:|
| 48^3 | 72 x 48 x 144 | 5184 | 3.646e-02 | 4.120e-02 | 3.48 |
| 64^3 | 96 x 64 x 192 | 6912 | 2.333e-02 | 2.562e-02 | 4.43 |
| 80^3 | 120 x 80 x 240 | 8640 | 1.685e-02 | 1.810e-02 | 5.92 |

- selected-mode finest voxel-direct/analytic Green L2: `7.141e-13`
- empirical resolution order: `1.610`
- wrong-d33 one-global-gain residual: `29.744%`

## Gates

| gate | pass |
|---|:---:|
| `chi2_factorization_l2_le_1e_13` | True |
| `maxwell_pole_residual_le_1e_12` | True |
| `resolvent_limit_l2_le_1e_5` | True |
| `resolvent_first_order_ge_0_8` | True |
| `operator_green_l2_le_1e_11` | True |
| `finest_voxel_green_l2_le_1e_8` | True |
| `finest_acfo_green_l2_le_2pct` | True |
| `acfo_green_error_strictly_decreases` | True |
| `empirical_resolution_order_ge_1` | True |
| `wrong_d33_gain_aligned_l2_ge_20pct` | True |

Overall pass: **True**

Supported claim: exact-source and discretization-converged relative complex vector bulk fields for this prescribed undepleted-pump LiNbO3 problem. FDTD, interfaces, depletion, loss, periodic poling, and absolute conversion efficiency are not claimed.

Reproduce with:

```powershell
.\.venv\Scripts\python.exe scripts\validate_general_curvature_analytic_nonlinear_oracle.py
```
