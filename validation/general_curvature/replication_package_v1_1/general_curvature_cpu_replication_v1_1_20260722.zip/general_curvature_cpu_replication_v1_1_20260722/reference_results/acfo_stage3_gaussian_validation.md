# ACFO stage-3 analytic Gaussian-mixture validation

A shifted, rotated, anisotropic three-component Gaussian mixture with complex coefficients is evaluated by its analytic Fourier transform, a Cartesian midpoint sum, a direct sum over cylindrical bin centers, and ACFO.

The reported decomposition is:

`total = operator + histogram placement + voxel quadrature`

where each term denotes a complex amplitude difference before norms are taken.

| level | family | operator L2 | histogram L2 | voxel L2 | object L2 | total L2 | total phase RMS |
|---|---|---:|---:|---:|---:|---:|---:|
| 12^3 / R24 / phi64 | sphere | 1.810e-15 | 5.122e-02 | 2.755e-03 | 5.099e-02 | 5.099e-02 | 1.587e-01 |
| 12^3 / R24 / phi64 | ellipsoid | 1.706e-15 | 5.630e-02 | 3.067e-03 | 5.600e-02 | 5.600e-02 | 2.031e-01 |
| 12^3 / R24 / phi64 | paraboloid | 1.813e-15 | 5.207e-02 | 2.830e-03 | 5.212e-02 | 5.212e-02 | 1.776e-01 |
| 12^3 / R24 / phi64 | spline | 1.741e-15 | 4.949e-02 | 3.192e-03 | 4.920e-02 | 4.920e-02 | 1.860e-01 |
| 18^3 / R36 / phi96 | sphere | 3.126e-15 | 2.146e-02 | 6.976e-07 | 2.146e-02 | 2.146e-02 | 7.349e-02 |
| 18^3 / R36 / phi96 | ellipsoid | 3.214e-15 | 2.348e-02 | 7.383e-07 | 2.348e-02 | 2.348e-02 | 6.168e-02 |
| 18^3 / R36 / phi96 | paraboloid | 3.153e-15 | 2.071e-02 | 1.091e-06 | 2.071e-02 | 2.071e-02 | 2.984e-02 |
| 18^3 / R36 / phi96 | spline | 3.300e-15 | 1.915e-02 | 9.658e-07 | 1.915e-02 | 1.915e-02 | 3.499e-02 |
| 24^3 / R48 / phi128 | sphere | 4.984e-15 | 9.338e-03 | 2.979e-08 | 9.338e-03 | 9.338e-03 | 3.149e-02 |
| 24^3 / R48 / phi128 | ellipsoid | 4.854e-15 | 1.026e-02 | 2.971e-08 | 1.026e-02 | 1.026e-02 | 4.932e-02 |
| 24^3 / R48 / phi128 | paraboloid | 4.964e-15 | 9.352e-03 | 2.944e-08 | 9.352e-03 | 9.352e-03 | 2.596e-02 |
| 24^3 / R48 / phi128 | spline | 4.943e-15 | 9.097e-03 | 2.958e-08 | 9.097e-03 | 9.097e-03 | 2.027e-02 |

Overall pass: **True**

Acceptance conditions:

- operator relative L2 and phase RMS <= `1.0e-12`
- decomposition closure relative L2 <= `1.0e-12`
- finest total relative L2 is lower than the coarsest value for every curvature family
- finest total relative L2 <= `0.02`

At the finest level, histogram placement is the dominant error for every curvature family; voxel quadrature and ACFO operator errors are already much smaller.

Reproduce with:

```powershell
.\.venv\Scripts\python.exe scripts\validate_axisymmetric_gaussian_mixture.py
```
