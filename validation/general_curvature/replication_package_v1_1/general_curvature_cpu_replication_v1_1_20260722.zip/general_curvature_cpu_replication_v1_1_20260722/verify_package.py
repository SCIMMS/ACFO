from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    package_root = args.package_root.resolve()
    checksums_path = package_root / "SHA256SUMS.txt"
    if not checksums_path.is_file():
        raise SystemExit(f"missing checksum manifest: {checksums_path}")

    rows = []
    passed = True
    for line in checksums_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        target = (package_root / relative).resolve()
        if package_root not in target.parents:
            raise SystemExit(f"checksum target escapes package root: {relative}")
        exists = target.is_file()
        actual = sha256(target) if exists else None
        match = exists and actual == expected
        passed = passed and match
        rows.append(
            {
                "path": relative,
                "exists": exists,
                "expected_sha256": expected,
                "actual_sha256": actual,
                "match": match,
            }
        )

    payload = {
        "schema": "acfo-general-curvature-package-verification-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "package_root": str(package_root),
        "file_count": len(rows),
        "passed": passed,
        "files": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "file_count": len(rows)}, indent=2))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

