[CmdletBinding()]
param(
    [string]$PythonPath = "",
    [string]$VenvPath = ".venv"
)

$ErrorActionPreference = "Stop"
$PackageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path

if ([System.IO.Path]::IsPathRooted($VenvPath)) {
    $ResolvedVenv = [System.IO.Path]::GetFullPath($VenvPath)
} else {
    $ResolvedVenv = [System.IO.Path]::GetFullPath((Join-Path $PackageRoot $VenvPath))
}

$LauncherArgs = @()
if ($PythonPath) {
    $BasePython = [System.IO.Path]::GetFullPath($PythonPath)
    if (-not (Test-Path -LiteralPath $BasePython -PathType Leaf)) {
        throw "Python executable not found: $BasePython"
    }
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    $BasePython = (Get-Command py).Source
    $LauncherArgs = @("-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $BasePython = (Get-Command python).Source
} else {
    throw "Python 3.11 or newer was not found. Install 64-bit Python and rerun."
}

& $BasePython @LauncherArgs -c "import sys; assert sys.version_info >= (3, 11), sys.version; print(sys.version)"
if ($LASTEXITCODE -ne 0) {
    throw "The selected Python is older than 3.11 or could not run."
}

if (Test-Path -LiteralPath $ResolvedVenv) {
    throw "Refusing to overwrite existing environment: $ResolvedVenv"
}

& $BasePython @LauncherArgs -m venv $ResolvedVenv
if ($LASTEXITCODE -ne 0) {
    throw "Failed to create virtual environment at $ResolvedVenv"
}

$VenvPython = Join-Path $ResolvedVenv "Scripts\python.exe"
if (-not (Test-Path -LiteralPath $VenvPython -PathType Leaf)) {
    throw "Virtual environment Python was not created: $VenvPython"
}

& $VenvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) {
    throw "Failed to upgrade pip."
}
& $VenvPython -m pip install -r (Join-Path $PackageRoot "requirements-lock.txt")
if ($LASTEXITCODE -ne 0) {
    throw "Failed to install locked CPU dependencies."
}

& $VenvPython -c "import numpy, scipy, sys; print(sys.version); print('numpy', numpy.__version__); print('scipy', scipy.__version__)"
if ($LASTEXITCODE -ne 0) {
    throw "Installed environment failed its import check."
}

Write-Host "CPU replication environment is ready: $VenvPython"
Write-Host "Next command: .\run_replication.ps1"

