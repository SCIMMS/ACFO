from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
from typing import Any


GAUSSIAN_SCHEMA = "acfo-stage3-gaussian-validation-v1"
NONLINEAR_SCHEMA = "general-curvature-analytic-nonlinear-oracle-v1"
CURVE_FAMILIES = {"sphere", "ellipsoid", "paraboloid", "spline"}


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def finite(value: Any) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"non-finite metric: {value!r}")
    return result


def gaussian_checks(payload: dict[str, Any]) -> tuple[dict[str, bool], dict[str, Any]]:
    checks: dict[str, bool] = {
        "schema": payload.get("schema") == GAUSSIAN_SCHEMA,
        "overall_passed": payload.get("passed") is True,
        "three_levels": len(payload.get("levels", [])) == 3,
    }
    levels = payload.get("levels", [])
    family_sets = [set(level.get("families", {})) for level in levels]
    checks["four_curve_families"] = bool(family_sets) and all(
        names == CURVE_FAMILIES for names in family_sets
    )

    max_operator_l2 = 0.0
    max_operator_phase = 0.0
    max_closure = 0.0
    finest_totals: dict[str, float] = {}
    decreasing: dict[str, bool] = {}
    if checks["three_levels"] and checks["four_curve_families"]:
        for level in levels:
            for family, row in level["families"].items():
                max_operator_l2 = max(
                    max_operator_l2, finite(row["operator"]["relative_l2"])
                )
                max_operator_phase = max(
                    max_operator_phase, finite(row["operator"]["phase_rms_rad"])
                )
                max_closure = max(
                    max_closure, finite(row["decomposition_closure_relative_l2"])
                )
        for family in sorted(CURVE_FAMILIES):
            values = [
                finite(level["families"][family]["total"]["relative_l2"])
                for level in levels
            ]
            finest_totals[family] = values[-1]
            decreasing[family] = values[-1] < values[0]

    checks.update(
        {
            "operator_l2_le_1e_12": max_operator_l2 <= 1e-12,
            "operator_phase_le_1e_12": max_operator_phase <= 1e-12,
            "closure_le_1e_12": max_closure <= 1e-12,
            "finest_total_le_2pct": bool(finest_totals)
            and max(finest_totals.values()) <= 0.02,
            "all_families_converge": bool(decreasing) and all(decreasing.values()),
        }
    )
    metrics = {
        "max_operator_relative_l2": max_operator_l2,
        "max_operator_phase_rms_rad": max_operator_phase,
        "max_decomposition_closure_relative_l2": max_closure,
        "finest_total_relative_l2_by_family": finest_totals,
        "finest_below_coarsest_by_family": decreasing,
    }
    return checks, metrics


def nonlinear_checks(payload: dict[str, Any]) -> tuple[dict[str, bool], dict[str, Any]]:
    gates = payload.get("gates", {})
    operator_branches = payload.get("operator_level", {}).get("branches", {})
    max_green_operator_l2 = max(
        (
            finite(row["green_acfo_vs_binned_direct"]["relative_l2"])
            for row in operator_branches.values()
        ),
        default=float("inf"),
    )
    levels = payload.get("convergence_levels", [])
    finest_green = (
        finite(levels[-1]["green_acfo_vs_analytic_relative_l2"])
        if levels
        else float("inf")
    )
    selected = finite(
        payload.get("selected_mode_voxel_reference", {}).get(
            "green_voxel_vs_analytic_relative_l2", float("inf")
        )
    )
    wrong_d33 = finite(
        payload.get("wrong_tensor_control", {}).get(
            "gain_aligned_relative_l2", float("-inf")
        )
    )
    checks = {
        "schema": payload.get("schema") == NONLINEAR_SCHEMA,
        "overall_passed": payload.get("passed") is True,
        "all_frozen_gates_pass": len(gates) == 10 and all(gates.values()),
        "green_operator_l2_le_1e_11": max_green_operator_l2 <= 1e-11,
        "selected_voxel_analytic_l2_le_1e_8": selected <= 1e-8,
        "finest_histogram_analytic_l2_le_2pct": finest_green <= 0.02,
        "wrong_d33_residual_ge_20pct": wrong_d33 >= 0.20,
    }
    metrics = {
        "chi2_factorization_relative_l2": finite(
            payload.get("chi2_factorization_relative_l2", float("inf"))
        ),
        "max_green_acfo_vs_binned_direct_relative_l2": max_green_operator_l2,
        "selected_mode_voxel_vs_analytic_green_relative_l2": selected,
        "finest_acfo_vs_analytic_green_relative_l2": finest_green,
        "wrong_d33_gain_aligned_relative_l2": wrong_d33,
        "empirical_resolution_order": finite(
            payload.get("convergence", {}).get(
                "empirical_resolution_order", float("-inf")
            )
        ),
    }
    return checks, metrics


def numeric_drift(current: Any, reference: Any) -> Any:
    if isinstance(current, dict) and isinstance(reference, dict):
        return {
            key: numeric_drift(current[key], reference[key])
            for key in current.keys() & reference.keys()
        }
    if isinstance(current, (int, float)) and isinstance(reference, (int, float)):
        current_value = float(current)
        reference_value = float(reference)
        absolute = abs(current_value - reference_value)
        denominator = max(abs(reference_value), 1e-300)
        return {"absolute": absolute, "relative": absolute / denominator}
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gaussian", type=Path, required=True)
    parser.add_argument("--nonlinear", type=Path, required=True)
    parser.add_argument("--environment", type=Path, required=True)
    parser.add_argument("--reference-gaussian", type=Path, required=True)
    parser.add_argument("--reference-nonlinear", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    gaussian = load_json(args.gaussian)
    nonlinear = load_json(args.nonlinear)
    environment = load_json(args.environment)
    reference_gaussian = load_json(args.reference_gaussian)
    reference_nonlinear = load_json(args.reference_nonlinear)

    gaussian_gate, gaussian_metrics = gaussian_checks(gaussian)
    nonlinear_gate, nonlinear_metrics = nonlinear_checks(nonlinear)
    passed = all(gaussian_gate.values()) and all(nonlinear_gate.values())
    payload = {
        "schema": "acfo-general-curvature-cpu-replication-summary-v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": passed,
        "gpu_required": False,
        "gpu_used": environment.get("gpu_used", False),
        "claim_role": "general-curvature correctness and physical-extension replication; no performance claim",
        "gaussian_validation": {
            "checks": gaussian_gate,
            "metrics": gaussian_metrics,
            "reference_metric_drift": numeric_drift(
                gaussian_metrics,
                gaussian_checks(reference_gaussian)[1],
            ),
        },
        "nonlinear_oracle": {
            "checks": nonlinear_gate,
            "metrics": nonlinear_metrics,
            "reference_metric_drift": numeric_drift(
                nonlinear_metrics,
                nonlinear_checks(reference_nonlinear)[1],
            ),
        },
        "claim_boundary": {
            "supported": (
                "CPU-independent correctness for the tested finite axisymmetric curve "
                "families and prescribed homogeneous-bulk undepleted LiNbO3 problem"
            ),
            "not_supported": [
                "GPU performance or scalability",
                "arbitrary non-axisymmetric manifolds",
                "interfaces, loss, depletion, periodic poling, or absolute efficiency",
                "FDTD agreement",
                "general differential-equation solvers",
            ],
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "summary": str(args.output)}, indent=2))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

