# ACFO general-curvature CPU 독립 재현 패키지

Runner revision: **v1.1**. Windows PowerShell 5.1이 exit code 0인 native-process warning을 `NativeCommandError`로 변환하는 경우에도 warning은 log에 보존하고 실제 process exit code로 성공 여부를 판단한다.

이 패키지는 **Axisymmetric Curved-Fourier Operator (ACFO)**의 general-curvature extension을 NVIDIA GPU 없이 독립적으로 재현한다. 검증 대상은 GPU 성능이 아니라 다음 두 correctness claim이다.

1. sphere, ellipsoid, paraboloid와 spline으로 주어진 finite axisymmetric meridional curves에서 analytic Gaussian-mixture Fourier transform과 ACFO가 일치한다.
2. prescribed undepleted Gaussian pump를 갖는 homogeneous lossless LiNbO3 문제에서 `chi(2)` source factorization, ordinary/extraordinary dyadic-Maxwell residue와 analytic nonlinear-polarization oracle가 일치한다.

Radeon 또는 integrated graphics의 종류는 결과에 영향을 주지 않는다. 모든 production validation path는 NumPy `complex128` CPU 연산을 사용하며 CUDA, PyTorch, CuPy, ROCm, OpenCL과 FDTD를 사용하지 않는다.

## 요구 사항

- Windows PowerShell 5.1 이상
- 64-bit Python 3.11 이상
- 인터넷 연결: 새 virtual environment에 NumPy와 SciPy를 처음 설치할 때만 필요
- 권장 RAM: 8 GB 이상

## 가장 간단한 실행

PowerShell에서 압축을 푼 package root로 이동한 뒤 실행한다.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup_environment.ps1
.\run_replication.ps1
```

이미 NumPy와 SciPy가 설치된 Python을 사용하려면 environment 설치를 생략할 수 있다.

```powershell
.\run_replication.ps1 -PythonPath "C:\path\to\python.exe"
```

기본 BLAS/OpenMP thread 수는 `1`이다. correctness 재현이 목적이므로 thread scheduling에 따른 reduction-order 차이를 줄이기 위한 설정이다. thread 수를 바꾸려면 다음처럼 지정한다.

```powershell
.\run_replication.ps1 -Threads 6
```

thread 수를 바꾼 실행 시간은 성능 claim으로 사용하지 않는다.

## 생성되는 receipt

각 실행은 기존 결과를 덮어쓰지 않고 `receipts/run_<UTC timestamp>/`를 새로 만든다.

- `environment.json`: Python, NumPy/SciPy, OS, CPU count, BLAS configuration과 thread variables
- `hardware_windows.json`: Windows가 보고한 CPU, RAM과 display-controller metadata
- `package_verification.json`: packaged source SHA-256 확인 결과
- `gaussian_validation.json` / `.md` / `.log`: 네 curve-family 검증
- `nonlinear_oracle.json` / `.md` / `.log`: LiNbO3 analytic nonlinear oracle
- `replication_summary.json`: gate, headline metric과 reference drift 요약
- `run_receipt.json`: 시작·종료 시각, 명령과 exit status

## 합격 기준

### Curve-family validation

- schema: `acfo-stage3-gaussian-validation-v1`
- overall `passed=true`
- 모든 curve family의 operator relative L2와 phase RMS `<=1e-12`
- decomposition closure relative L2 `<=1e-12`
- finest total relative L2 `<=2%`
- 모든 family에서 resolution 증가 시 total error 감소

### Nonlinear analytic oracle

- schema: `general-curvature-analytic-nonlinear-oracle-v1`
- overall `passed=true`
- frozen gate 10개 모두 통과
- same-bin Green ACFO/direct `<=1e-11`
- finest selected-mode voxel-direct/analytic Green L2 `<=1e-8`
- finest histogram/analytic Green L2 `<=2%`
- wrong-`d33` gain-aligned residual `>=20%`

Reference JSON과의 수치 drift도 기록하지만, near-machine-precision 값의 bitwise 동일성은 요구하지 않는다. 논문의 정확도 claim은 gate 통과와 error hierarchy에 근거한다.

## 해석 경계

지원되는 claim:

> CPU-independent correctness and discretization-converged relative complex vector bulk fields for the tested finite axisymmetric curve families and prescribed homogeneous-bulk undepleted LiNbO3 problem.

지원되지 않는 claim:

- general-curvature GPU speedup 또는 GPU scalability
- arbitrary non-axisymmetric manifolds
- finite-crystal interfaces, loss, pump depletion, periodic poling 또는 absolute conversion efficiency
- FDTD agreement
- general differential-equation solver

## Archive 방침

이 package와 반환 receipt는 기존 WAXS/ODT v14 external package 또는 기존 local general-curvature evidence를 수정하지 않는다. 별도 provenance로 보존하고, 논문 release 시 하나의 DOI collection 아래 연결한다.
