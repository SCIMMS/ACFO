# ACFO general-curvature CPU replication

Runner revision: **v1.1**. Native-process warnings are logged without being treated as failures when the process returns exit code zero, including under Windows PowerShell 5.1.

This package independently reproduces the correctness evidence for the general-curvature extension of the **Axisymmetric Curved-Fourier Operator (ACFO)**. It uses NumPy `complex128` CPU paths only; CUDA, PyTorch, CuPy, ROCm, OpenCL and FDTD are not used.

On Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup_environment.ps1
.\run_replication.ps1
```

Or use an existing Python 3.11+ environment containing the locked NumPy and SciPy versions:

```powershell
.\run_replication.ps1 -PythonPath "C:\path\to\python.exe"
```

Each run creates a new `receipts/run_<UTC timestamp>/` directory and never overwrites the frozen reference results. The pass criterion is the complete set of analytic, operator and convergence gates, not bitwise equality of near-machine-precision values across BLAS implementations.

See `README_KO.md` for the complete evidence contract and claim boundaries.
