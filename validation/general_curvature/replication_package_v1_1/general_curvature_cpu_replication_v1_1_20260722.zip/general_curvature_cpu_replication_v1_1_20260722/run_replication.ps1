[CmdletBinding()]
param(
    [string]$PythonPath = "",
    [int]$Threads = 1,
    [string]$OutputRoot = ""
)

$ErrorActionPreference = "Stop"
if ($Threads -lt 1) {
    throw "Threads must be at least one."
}

$PackageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if ($PythonPath) {
    $Python = [System.IO.Path]::GetFullPath($PythonPath)
} else {
    $Python = Join-Path $PackageRoot ".venv\Scripts\python.exe"
}
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) {
    throw "Python executable not found: $Python. Run .\setup_environment.ps1 first or pass -PythonPath."
}

if ($OutputRoot) {
    $ReceiptsRoot = [System.IO.Path]::GetFullPath($OutputRoot)
} else {
    $ReceiptsRoot = Join-Path $PackageRoot "receipts"
}
New-Item -ItemType Directory -Force -Path $ReceiptsRoot | Out-Null

$RunId = "run_{0}_{1}" -f ([DateTime]::UtcNow.ToString("yyyyMMddTHHmmssZ")), $PID
$RunDirectory = Join-Path $ReceiptsRoot $RunId
if (Test-Path -LiteralPath $RunDirectory) {
    throw "Refusing to overwrite existing run directory: $RunDirectory"
}
New-Item -ItemType Directory -Path $RunDirectory | Out-Null

$env:PYTHONPATH = Join-Path $PackageRoot "src"
$env:OMP_NUM_THREADS = [string]$Threads
$env:OPENBLAS_NUM_THREADS = [string]$Threads
$env:MKL_NUM_THREADS = [string]$Threads
$env:BLIS_NUM_THREADS = [string]$Threads
$env:VECLIB_MAXIMUM_THREADS = [string]$Threads
$env:NUMEXPR_NUM_THREADS = [string]$Threads

$StartedUtc = [DateTime]::UtcNow
$Steps = New-Object System.Collections.ArrayList

function Invoke-PythonStep {
    param(
        [string]$Name,
        [string[]]$Arguments,
        [string]$LogName
    )
    $StepStarted = [DateTime]::UtcNow
    $LogPath = Join-Path $RunDirectory $LogName
    $PreviousErrorActionPreference = $ErrorActionPreference
    try {
        # Windows PowerShell 5.1 converts any native-process stderr text into
        # NativeCommandError records. Scientific Python packages may emit a
        # harmless warning on stderr while returning exit code zero, so record
        # both streams and use the native exit code as the success contract.
        $ErrorActionPreference = "Continue"
        & $Python @Arguments *> $LogPath
        $ExitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $PreviousErrorActionPreference
    }
    $StepEnded = [DateTime]::UtcNow
    Get-Content -LiteralPath $LogPath
    [void]$Steps.Add([ordered]@{
        name = $Name
        started_at_utc = $StepStarted.ToString("o")
        ended_at_utc = $StepEnded.ToString("o")
        elapsed_seconds = ($StepEnded - $StepStarted).TotalSeconds
        exit_code = $ExitCode
        log = $LogName
    })
    if ($ExitCode -ne 0) {
        throw "Step '$Name' failed with exit code $ExitCode. See $LogPath"
    }
}

$Passed = $false
try {
    Invoke-PythonStep -Name "package_verification" -LogName "package_verification.log" -Arguments @(
        (Join-Path $PackageRoot "verify_package.py"),
        "--package-root", $PackageRoot,
        "--output", (Join-Path $RunDirectory "package_verification.json")
    )

    Invoke-PythonStep -Name "environment_collection" -LogName "environment.log" -Arguments @(
        (Join-Path $PackageRoot "collect_environment.py"),
        "--output", (Join-Path $RunDirectory "environment.json")
    )

    $HardwarePath = Join-Path $RunDirectory "hardware_windows.json"
    try {
        $Hardware = [ordered]@{
            schema = "acfo-general-curvature-windows-hardware-v1"
            generated_at_utc = [DateTime]::UtcNow.ToString("o")
            cpu = @(Get-CimInstance Win32_Processor | Select-Object Name, Manufacturer, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed)
            computer = @(Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer, Model, TotalPhysicalMemory)
            operating_system = @(Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture, BuildNumber)
            display_controllers_metadata_only = @(Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion)
            gpu_used = $false
        }
    } catch {
        $Hardware = [ordered]@{
            schema = "acfo-general-curvature-windows-hardware-v1"
            generated_at_utc = [DateTime]::UtcNow.ToString("o")
            collection_error = $_.Exception.Message
            gpu_used = $false
        }
    }
    $Hardware | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $HardwarePath -Encoding UTF8

    Invoke-PythonStep -Name "curve_family_validation" -LogName "gaussian_validation.log" -Arguments @(
        (Join-Path $PackageRoot "scripts\validate_axisymmetric_gaussian_mixture.py"),
        "--json-output", (Join-Path $RunDirectory "gaussian_validation.json"),
        "--markdown-output", (Join-Path $RunDirectory "gaussian_validation.md")
    )

    Invoke-PythonStep -Name "nonlinear_analytic_oracle" -LogName "nonlinear_oracle.log" -Arguments @(
        (Join-Path $PackageRoot "scripts\validate_general_curvature_analytic_nonlinear_oracle.py"),
        "--json-output", (Join-Path $RunDirectory "nonlinear_oracle.json"),
        "--markdown-output", (Join-Path $RunDirectory "nonlinear_oracle.md")
    )

    Invoke-PythonStep -Name "replication_gate_verification" -LogName "replication_verification.log" -Arguments @(
        (Join-Path $PackageRoot "verify_replication.py"),
        "--gaussian", (Join-Path $RunDirectory "gaussian_validation.json"),
        "--nonlinear", (Join-Path $RunDirectory "nonlinear_oracle.json"),
        "--environment", (Join-Path $RunDirectory "environment.json"),
        "--reference-gaussian", (Join-Path $PackageRoot "reference_results\acfo_stage3_gaussian_validation.json"),
        "--reference-nonlinear", (Join-Path $PackageRoot "reference_results\general_curvature_analytic_nonlinear_oracle_20260722.json"),
        "--output", (Join-Path $RunDirectory "replication_summary.json")
    )
    $Passed = $true
} finally {
    $EndedUtc = [DateTime]::UtcNow
    $Receipt = [ordered]@{
        schema = "acfo-general-curvature-cpu-run-receipt-v1"
        package_id = "general-curvature-cpu-replication-v1.1"
        run_id = $RunId
        started_at_utc = $StartedUtc.ToString("o")
        ended_at_utc = $EndedUtc.ToString("o")
        elapsed_seconds = ($EndedUtc - $StartedUtc).TotalSeconds
        passed = $Passed
        python = $Python
        threads = $Threads
        output_directory = $RunDirectory
        gpu_required = $false
        gpu_used = $false
        steps = $Steps
    }
    $Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $RunDirectory "run_receipt.json") -Encoding UTF8
}

if (-not $Passed) {
    throw "Replication failed. Partial receipts were preserved at $RunDirectory"
}

$ReturnZip = Join-Path $ReceiptsRoot ($RunId + "_return_bundle.zip")
Compress-Archive -Path (Join-Path $RunDirectory "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $ReturnZip).Hash.ToLowerInvariant()
"$ReturnHash  $([System.IO.Path]::GetFileName($ReturnZip))" | Set-Content -LiteralPath ($ReturnZip + ".sha256") -Encoding ASCII

Write-Host "Replication PASSED"
Write-Host "Receipt directory: $RunDirectory"
Write-Host "Return bundle: $ReturnZip"
Write-Host "Return bundle SHA-256: $ReturnHash"
